"""Figure 1 of Paper A: the frontier of Theorem 3.4 against Yuma's honest equilibria (running example).

Running example: n = 3, p = 3/4, V = M, free evaluation. Frontier: Theorem 1. Yuma with continuous
weights and bond memory off: extreme reports up to K^Y = 1/108 (Theorem 2), then the softer-weight
family of Proposition 2, whose ownership tolerance C(l) rises to 8/51 while quality falls to 1/2.
"""
import sys
from pathlib import Path
from fractions import Fraction as F
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[4]))
import hz_figstyle as hz
import matplotlib.pyplot as plt

hz.apply()
QMAJ, K, KY, KEND = 27/32, 2/9, 1/108, 8/51

def frontier(w):
    return 0.5 + (QMAJ - 0.5) * np.minimum(1.0, K / np.maximum(w, 1e-12))

def tolerance(l):   # C(l) at p = 3/4, V = M
    return 2 * (28*l**2 + 56*l + 1) / (3 * (28*l**3 + 56*l**2 + 127*l + 72))

def yuma_quality(l):  # Q^Y(l) at p = 3/4
    t = 3/16
    return 0.5 + 0.5 * (0.5 - l) * (1 - t + 3*t / (1 + l))

w = np.linspace(0.0, 0.45, 901)
ls = np.linspace(0.0, 0.4999, 600)

fig, ax = plt.subplots(figsize=(3.3, 2.15))
ax.plot(w, frontier(w), color=hz.INK, lw=1.4, label="best possible rule", zorder=3)
yw = np.concatenate([[0.0, KY], tolerance(ls)])
yq = np.concatenate([[QMAJ, QMAJ], yuma_quality(ls)])
ax.plot(yw, yq, color=hz.INK, lw=1.1, ls=(0, (4, 2)), label="Yuma, split weights", zorder=4)
ax.plot([K], [QMAJ], "o", ms=4.5, mfc="white", mec=hz.INK, mew=0.9, zorder=5,
        label="Yuma, all-or-nothing weights")
ax.plot([KY], [QMAJ], "s", ms=3.6, mfc=hz.INK, mec=hz.INK, zorder=5)
ax.plot([tolerance(0.4999)], [yuma_quality(0.4999)], "s", ms=3.6, mfc=hz.INK, mec=hz.INK, zorder=5)
ax.axhline(0.5, color=hz.GUIDE, lw=0.6, zorder=1)
ax.annotate(r"$1/108\approx1\%$", xy=(KY, QMAJ), xytext=(0.03, 0.868), fontsize=7.5,
            color="0.15", arrowprops=dict(arrowstyle="-", color="0.45", lw=0.5))
ax.annotate(r"$8/51\approx16\%$", xy=(tolerance(0.4999), 0.5), xytext=(0.035, 0.535), fontsize=7.5,
            color="0.15", arrowprops=dict(arrowstyle="-", color="0.45", lw=0.5))
ax.annotate(r"$2/9\approx22\%$", xy=(K, QMAJ), xytext=(0.245, 0.868), fontsize=7.5,
            color="0.15", arrowprops=dict(arrowstyle="-", color="0.45", lw=0.5))
ax.set_xlim(0, 0.45); ax.set_ylim(0.47, 0.90)
ax.set_xlabel("largest share of a miner a validator may own")
ax.set_ylabel("quality")
ax.text(0.445, 0.488, "even split", ha="right", va="top", fontsize=7, color="0.35")
ax.legend(loc="lower right", bbox_to_anchor=(1.0, 0.13), fontsize=6.8, frameon=False, handlelength=2.2, borderaxespad=0.2)
hz.style_ticklabels(ax)
hz.save(fig, Path(__file__).with_name("frontier.pdf"))
print("tolerance(0)=", tolerance(0.0), " tolerance(1/2)=", tolerance(0.5), " Q^Y(0)=", yuma_quality(0.0))
