"""Figure 2 of Paper A: allocation shapes and where influence sits (seven validators, p = 3/4).

Panel (a): miner 1's share a_k against the number k of reports for miner 1, for the majority rule,
Yuma's allocation under 1/5-honest weights (bond memory off; Lemma 6 formula), and the damped
majority rule whose influence equals Yuma's. Panel (b): the contribution of each count j of other
reports to the influence H(a) = sum_j C(n-1,j) p^j q^(n-1-j) (a_{j+1} - a_j) (equation (4)).
Exact arithmetic for the numbers quoted in the caption.
"""
import sys
from pathlib import Path
from fractions import Fraction as F
from math import comb
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[4]))
import hz_figstyle as hz
import matplotlib.pyplot as plt

n, p, ell = 7, F(3, 4), F(1, 5)
q, m = 1 - p, n // 2

def yuma_alloc(k):
    if k > m:
        return (k * (1 - ell) + (n - k) * ell) / (k + 2 * ell * (n - k))
    return 1 - yuma_alloc(n - k)

def influence_terms(a):
    return [comb(n - 1, j) * p**j * q**(n - 1 - j) * (a[j + 1] - a[j]) for j in range(n)]

def quality(a):
    return sum(comb(n, k) * p**k * q**(n - k) * a[k] for k in range(n + 1))

a_y = [yuma_alloc(k) for k in range(n + 1)]
b = comb(2 * m, m) * (p * q)**m
H_y = sum(influence_terms(a_y))
lam = H_y / b
a_d = [(1 - lam) / 2 + lam * (1 if k > m else 0) for k in range(n + 1)]
a_m = [F(1) if k > m else F(0) for k in range(n + 1)]
Q_y, Q_d, Q_m = quality(a_y), quality(a_d), quality(a_m)
print(f"H_Y={float(H_y):.4f} b={float(b):.4f} lambda={float(lam):.4f} "
      f"Q_Y={float(Q_y):.4f} Q_damped={float(Q_d):.4f} Q_maj={float(Q_m):.4f}")

hz.apply()
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6.9, 2.25))
ks = np.arange(n + 1)
ax1.plot(ks, [float(x) for x in a_m], color=hz.INK, lw=1.0, drawstyle="steps-mid", label="majority rule")
ax1.plot(ks, [float(x) for x in a_d], color=hz.INK, lw=1.4, ls=(0, (1.2, 1.4)), drawstyle="steps-mid",
         label=rf"damped majority, $\lambda={float(lam):.2f}$")
ax1.plot(ks, [float(x) for x in a_y], "o-", color=hz.WHISK, lw=1.0, ms=3.4, mfc="white", mec=hz.INK,
         mew=0.8, label=r"Yuma, $\ell=1/5$")
ax1.set_xlabel(r"reports for miner 1, $k$")
ax1.set_ylabel(r"miner 1's share $a_k$")
ax1.set_xticks(ks); ax1.set_ylim(-0.03, 1.03)
ax1.legend(loc="upper left", fontsize=6.8, frameon=False, handlelength=2.4)
hz.tag(ax1, "(a)")

js = np.arange(n)
w = 0.38
ax2.bar(js - w / 2, [float(x) for x in influence_terms(a_d)], width=w, color=hz.INK, label="damped majority")
ax2.bar(js + w / 2, [float(x) for x in influence_terms(a_y)], width=w, color="0.72", edgecolor=hz.INK,
        linewidth=0.5, label=r"Yuma, $\ell=1/5$")
ax2.set_xlabel(r"other reports for miner 1, $j$")
ax2.set_ylabel("contribution to influence")
ax2.set_xticks(js)
ax2.legend(loc="upper left", fontsize=6.8, frameon=False)
hz.tag(ax2, "(b)")
for ax in (ax1, ax2):
    hz.style_ticklabels(ax)
fig.tight_layout(w_pad=2.0)
hz.save(fig, Path(__file__).with_name("influence.pdf"))
