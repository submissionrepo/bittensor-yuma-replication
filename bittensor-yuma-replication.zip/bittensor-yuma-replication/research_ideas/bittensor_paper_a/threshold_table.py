"""Finite, exact evaluations of the existing odd-n threshold formulas.

The twelve old Yuma thresholds are read from their saved 2026-09-29 record.
Only n >= 11 points are newly evaluated; no old verification suite is run.
This checks finite substitutions, not the general equilibrium theorem.
"""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import csv
import re
import sys

ROOT = Path(__file__).resolve().parent
PROBES = ROOT.parent / "probes" / "bittensor"
sys.path.insert(0, str(PROBES))


def thresholds(n, p):
    q = 1 - p
    m = n // 2
    a = sum(F(comb(n, k)) * p**k * q**(n-k) for k in range(m+1, n+1))
    b = F(comb(n-1, m)) * (p*q)**m
    k_static = (2*p-1) * (a-p) / (n*p*q*b)
    if n < 11:
        return k_static, OLD[n, p]
    w = [F(comb(n-1, k)) * (p**(n-k)*q**k + q**(n-k)*p**k)
         for k in range(n)]
    s = sum(w[k] * F(n-k-1, (n-k)**2) for k in range(m))
    s -= sum(w[k] / k for k in range(m+1, n))
    # Independent exact recomputation of the newly added substitutions only.
    from yuma_continuous_theory import general_s
    import sympy as sp
    s_ref, b_ref = general_s(n, sp.Rational(p.numerator, p.denominator))
    assert sp.Rational(s.numerator, s.denominator) == s_ref
    assert sp.Rational(b.numerator, b.denominator) == b_ref
    assert s/b < k_static
    return k_static, s/b


OLD = {}
for line in (PROBES / "yuma_continuous_theory.md").read_text(encoding="utf-8").splitlines():
    match = re.match(r"\| (\d+) \| (\d+/\d+) \| (-?\d+/\d+) \|", line)
    if match:
        n, p, value = match.groups()
        OLD[int(n), F(p)] = F(value)


def main():
    ps = [F(3, 5), F(3, 4), F(9, 10)]
    rows = []
    for n in range(3, 52, 2):
        for p in ps:
            k, ky = thresholds(n, p)
            rows.append(dict(n=n, p=str(p), K_exact=str(k), KY_exact=str(ky),
                             ratio_exact=str(ky/k), K=float(k), KY=float(ky), ratio=float(ky/k),
                             both_at_least_one=k >= 1 and ky >= 1,
                             static_feasible_cap=float(min(F(1), k)),
                             yuma_feasible_cap="none" if ky < 0 else float(min(F(1), ky)),
                             source="saved 20260929 exact point" if n < 11 else "new exact substitution"))
    with (ROOT / "threshold_table.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lookup = {(r['n'], r['p']): r for r in rows}
    selected = [3, 5, 7, 9, 11, 13, 15, 31, 51]
    tex = [r"\begin{tabular}{@{}rrrr@{}}", r"\toprule",
           r"$n$ & $p=3/5$ & $p=3/4$ & $p=9/10$ \\", r"\midrule"]
    for n in selected:
        cells = []
        for p in ps:
            r = lookup[n, str(p)]
            marker = r"^{\dagger}" if r['both_at_least_one'] else ""
            cells.append(f"${r['ratio']:.3f}{marker}$")
        tex.append(str(n) + " & " + " & ".join(cells) + r" \\")
    tex += [r"\bottomrule", r"\end{tabular}"]
    (ROOT / "tex" / "tables").mkdir(exist_ok=True)
    (ROOT / "tex" / "tables" / "thresholds.tex").write_text("\n".join(tex)+"\n", encoding="utf-8")
    md = ["# 一般人数阈值：新增有限精确代入", "", "2026-09-30。用于获授权的正文修改，非一般定理的新证明。", "",
          "范围：经典实数 Yuma，alpha=1，等 stake、条件独立二元信号，eta=0、V=M。",
          "旧的 n=3,5,7,9 共12个 KY 值从既有 MD/ledger 读取，未重跑旧验证；新增 n=11,13,...,51 共63个点，用 Fraction 与原 general_s 的 SymPy 实现对齐。",
          "K 和 KY 是未截断代数阈值。KY<0 表示零持股下全押信号报告就有获利连续偏离；不表示所有策略或所有人数都失败。若两者均>=1，合法 ownership∈[0,1] 下都能支持全押报告，原始阈值比不能当作可行持股份额的损失。", "",
          "| n | p | K | KY | KY/K | 两阈值均≥1 |", "|---:|---:|---:|---:|---:|:---:|"]
    for r in rows:
        md.append(f"| {r['n']} | {r['p']} | {r['K']:.9g} | {r['KY']:.9g} | {r['ratio']:.9g} | {'是' if r['both_at_least_one'] else '否'} |")
    md += ["", "## 关键有限结论", ""]
    for p in ps:
        neg = [r['n'] for r in rows if r['p']==str(p) and r['KY']<0]
        both = [r['n'] for r in rows if r['p']==str(p) and r['both_at_least_one']]
        line = f"- p={p}：所算人数里 KY<0 的 n={neg}；两阈值首次同时≥1 的所算人数为 {both[0] if both else '无'}。"
        md.append(line)
        print(line)
    md += ["", "精确分数见 threshold_table.csv；表格由同一脚本生成。63个新增点均与独立符号实现相等，且 KY<K。有限取值不证明符号单调性或渐近结论。"]
    (ROOT / "threshold_table.md").write_text("\n".join(md)+"\n", encoding="utf-8")
    print("12 saved KY points reused; 63 new rational points matched; 75 rows exported.")
    for n in selected:
        print(n, [(str(p), round(lookup[n, str(p)]['KY'],6), round(lookup[n, str(p)]['ratio'],6)) for p in ps])


if __name__ == "__main__":
    main()
