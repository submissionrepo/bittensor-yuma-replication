"""Render the preselected main table and complete data table from saved draws.

No simulations or model checks are rerun. All values have the same CSV source.
"""
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT.parent / "probes" / "bittensor" / "numerics"
TABLES = ROOT / "tex" / "tables"
GAIN = "delta_income_nominal_validator_budget"


def stake_label(row):
    n = int(row['n_validators'])
    s = float(row['stake0_requested'])
    return f"1/{n}" if abs(s-1/n) < 1e-10 else f"{s:g}"


def ci(row):
    mean = 1000*float(row[GAIN])
    low = 1000*float(row[GAIN+'_ci95_low'])
    high = 1000*float(row[GAIN+'_ci95_high'])
    return f"${mean:.3f}\\,[{low:.3f},{high:.3f}]$"


def quality(row):
    return f"${1000*float(row['delta_quality']):.3f}$"


def main():
    with (DATA/'single_hedge_results.csv').open(newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 36 and {r['samples'] for r in rows} == {'2048'}
    main_rows = [r for r in rows if r['policy']=='softmax' and float(r['h'])==.1
                 and (stake_label(r).startswith('1/') or float(r['stake0_requested'])==.4)]
    assert len(main_rows) == 8
    out = [r"\begin{tabular}{@{}rrrcr@{}}", r"\toprule",
           r"$n$ & $J$ & $s_0$ & $\Delta v/V$ [95\% CI] & $\Delta Q$ \\", r"\midrule"]
    for row in main_rows:
        out.append(f"{row['n_validators']} & {row['miners']} & ${stake_label(row)}$ & "
                   + ci(row) + ' & ' + quality(row) + r" \\")
    out += [r"\bottomrule", r"\end{tabular}"]
    TABLES.mkdir(exist_ok=True)
    (TABLES/'single_hedge_main.tex').write_text('\n'.join(out)+'\n', encoding='utf-8')

    groups = {}
    for row in rows:
        key = tuple(row[k] for k in ['policy','n_validators','miners','stake0_requested'])
        groups.setdefault(key, {})[float(row['h'])] = row
    out = [r"\begin{tabular}{@{}lrrrcrcr@{}}", r"\toprule",
           r"& & & & \multicolumn{2}{c}{$h=0.1$} & \multicolumn{2}{c}{$h=0.25$} \\",
           r"Signal weights & $n$ & $J$ & $s_0$ & $\Delta v/V$ [95\% CI] & $\Delta Q$ & $\Delta v/V$ [95\% CI] & $\Delta Q$ \\",
           r"\midrule"]
    last_policy = None
    for (policy,n,j,s), values in groups.items():
        if last_policy is not None and policy != last_policy:
            out.append(r"\midrule")
        lo,hi = values[.1],values[.25]
        name = 'Softmax' if policy=='softmax' else 'All-or-nothing'
        out.append(f"{name} & {n} & {j} & ${stake_label(lo)}$ & " + ci(lo) + ' & '
                   + quality(lo) + ' & ' + ci(hi) + ' & ' + quality(hi) + r" \\")
        last_policy=policy
    out += [r"\bottomrule", r"\end{tabular}"]
    (TABLES/'single_hedge_full.tex').write_text('\n'.join(out)+'\n', encoding='utf-8')
    print('Rendered 8 preselected main rows and all 36 outcomes in 18 full-table rows.')


if __name__ == '__main__':
    main()
