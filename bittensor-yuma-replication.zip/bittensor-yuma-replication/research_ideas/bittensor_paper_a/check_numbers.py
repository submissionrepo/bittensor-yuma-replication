"""Recompute quoted numbers from the paper formulas and saved experimental data.
These finite substitutions do not prove the general formulas.
"""
from fractions import Fraction as F
from math import comb

def q_maj(n, p):
    m = n // 2
    return sum(comb(n, k) * p**k * (1 - p)**(n - k) for k in range(m + 1, n + 1))

def pivot(n, p):
    m = n // 2
    return comb(2 * m, m) * (p * (1 - p))**m

def premium_max(n, p, V):
    q = 1 - p
    return V * (2*p - 1) * (q_maj(n, p) - p) / (2 * n * p * q)

def threshold(n, p, V, M):
    return 2 * premium_max(n, p, V) / (M * pivot(n, p))

def frontier(n, p, V, M, w):
    return F(1, 2) + (q_maj(n, p) - F(1, 2)) * min(F(1), threshold(n, p, V, M) / w)

def yuma_threshold_n3(p, V, M):
    t = p * (1 - p)
    return (V / M) * (4 - 21 * t) / (36 * t)

def yuma_soft_quality_n3(p, e):
    t = p * (1 - p); d = 2*p - 1
    return F(1, 2) + d * (F(1, 2) - e) * (1 - t + 3*t / (1 + e))

def soft_tolerance_n3_p34(e):  # C_C(e) at p = 3/4 (completion note, Sec. 2)
    return 2 * (28*e**2 + 56*e + 1) / (3 * (28*e**3 + 56*e**2 + 127*e + 72))

def persistence_threshold(n, p):  # rho_c; stay probability is (1 + rho_c)/2
    q = 1 - p; d = 2*p - 1
    return d * (p**(n+1) + q**(n+1)) / (p**(n+1) - q**(n+1))

checks = []
def check(label, got, want):
    ok = (got == want)
    checks.append(ok)
    print(f"{'OK ' if ok else 'BAD'} {label}: {got} ({float(got):.6f}) expected {want}")

p, V, M, n = F(3, 4), F(1), F(1), 3
check("Q_maj(3,3/4)", q_maj(n, p), F(27, 32))
check("pivot b(3,3/4)", pivot(n, p), F(3, 8))
check("G* (3,3/4), V=1", premium_max(n, p, V), F(1, 24))
check("K (3,3/4), V=M", threshold(n, p, V, M), F(2, 9))
check("Q*(omega=1)", frontier(n, p, V, M, F(1)), F(83, 144))
check("K^Y (3,3/4), V=M", yuma_threshold_n3(p, V, M), F(1, 108))
check("K^Y (3,3/5), V=M", yuma_threshold_n3(F(3, 5), V, M), F(-13, 108))
check("soft tolerance at l=0", soft_tolerance_n3_p34(F(0)), F(1, 108))
check("soft tolerance at l=1/2", soft_tolerance_n3_p34(F(1, 2)), F(8, 51))
check("Yuma quality l=0", yuma_soft_quality_n3(p, F(0)), F(27, 32))
check("Yuma quality l=49/100", yuma_soft_quality_n3(p, F(49, 100)), F(241237, 476800))
rc = persistence_threshold(n, p)
check("rho_c (3,3/4)", rc, F(41, 80))
check("stay probability at rho_c", (1 + rc) / 2, F(121, 160))
print("Yuma quality at l=2/5:", float(yuma_soft_quality_n3(p, F(2, 5))))
print("K as percent:", float(F(2, 9)) * 100, " K^Y as percent:", float(F(1, 108)) * 100)
print("all checks passed" if all(checks) else "SOME CHECKS FAILED")

# Section 4: general-n Yuma threshold K^Y = V S_n(p)/(M b) against the n = 3 closed form and K.
def yuma_threshold(n, p, V, M):
    m = n // 2; q = 1 - p
    w = [comb(2*m, k) * (p**(2*m - k + 1) * q**k + q**(2*m - k + 1) * p**k) for k in range(2*m + 1)]
    S = sum(w[k] * F(n - k - 1, (n - k)**2) for k in range(m)) - sum(w[k] / k for k in range(m + 1, 2*m + 1))
    return V * S / (M * pivot(n, p))

for pp in (F(3, 5), F(3, 4), F(9, 10)):
    check(f"K^Y general formula n=3 p={pp}", yuma_threshold(3, pp, V, M), yuma_threshold_n3(pp, V, M))
for nn in (3, 5, 7, 9):
    for pp in (F(3, 5), F(3, 4), F(9, 10)):
        ky, kk = yuma_threshold(nn, pp, V, M), threshold(nn, pp, V, M)
        checks.append(ky < kk)
        print(f"n={nn} p={pp}: K^Y={float(ky):.6f} < K={float(kk):.6f}: {ky < kk}")
print("all checks passed" if all(checks) else "SOME CHECKS FAILED")

# Worked example (Section 4.1 table): n = 3, validator C hedges with weight 1/5 while A and B split.
wA, wB, wC = F(1), F(0), F(1, 5)                     # weights on miner 1; weight on miner 0 is 1 - w
med1 = sorted([wA, wB, wC])[1]; med0 = sorted([1 - wA, 1 - wB, 1 - wC])[1]
c1 = [min(w, med1) for w in (wA, wB, wC)]; c0 = [min(1 - w, med0) for w in (wA, wB, wC)]
a = sum(c1) / (sum(c1) + sum(c0))
pay = [(c1[i] / sum(c1)) * a + (c0[i] / sum(c0)) * (1 - a) for i in range(3)]
check("worked example: miner 1 share", a, F(1, 5))
check("worked example: pay A", pay[0], F(1, 10)); check("worked example: pay B", pay[1], F(2, 5)); check("worked example: pay C", pay[2], F(1, 2))

# Bond lean along honest play (Section 4.2): d_* = 2(1-2l)/(3(2-l)).
dstar = lambda l: 2 * (1 - 2 * l) / (3 * (2 - l))
check("d_* at l=0", dstar(F(0)), F(1, 3)); check("d_* at l=49/100", dstar(F(49, 100)), F(4, 453))

# Unequal stake (Section 5.1): Yuma-type payments with stakes (3/5,1/5,1/5), p = 3/4, V = 1.
pp, qq = F(3, 4), F(1, 4)
honest = F(7, 16) * F(3, 5) + F(6, 16) * F(3, 4) + F(3, 16) * 1
blind = F(5, 16) * F(3, 5) + F(6, 16) * F(3, 4) + F(5, 16) * 1
check("60% validator premium (units of V)", honest - blind, F(-1, 20))
check("capacity C_1 = V d^2/2 (n=3, p=3/4)", (2 * pp - 1)**2 / 2, F(1, 8))
tt = pp * qq
check("dominant quality 1/2 + d(1+t)/2", F(1, 2) + (2 * pp - 1) * (1 + tt) / 2, F(51, 64))
check("dominant threshold d^2/(1/2+3t)", (2 * pp - 1)**2 / (F(1, 2) + 3 * tt), F(4, 17))
print("all checks passed" if all(checks) else "SOME CHECKS FAILED")

# Revision of 2026-09-30 (abstract, Section 1 "The deployed rule", Table 3, Section 6).
# Abstract: at p = 3/5 zero-ownership hedging pays for every odd n up to 13, and not at n = 15.
for nn in range(3, 16, 2):
    ky = yuma_threshold(nn, F(3, 5), V, M)
    checks.append((ky < 0) == (nn <= 13))
    print(f"p=3/5 n={nn}: K^Y={float(ky):.6f} negative={ky < 0} (expected {nn <= 13})")
# Table 3, new row n = 13: rounded K^Y/K and the dagger (K, K^Y >= 1).
for pp, shown, dagger in ((F(3, 5), "-0.012", False), (F(3, 4), "0.782", False), (F(9, 10), "0.891", True)):
    ky, kk = yuma_threshold(13, pp, V, M), threshold(13, pp, V, M)
    ok = f"{float(ky / kk):.3f}" == shown and ((ky >= 1 and kk >= 1) == dagger)
    checks.append(ok)
    print(f"{'OK ' if ok else 'BAD'} Table 3 n=13 p={pp}: {float(ky / kk):.3f} dagger={ky >= 1 and kk >= 1}")

# Section 1 and Section 6: single-validator hedge, recomputed from the saved 2048-draw data.
import csv
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "probes" / "bittensor" / "numerics" / "single_hedge_2048.csv"
rows = [r for r in csv.DictReader(DATA.open(encoding="utf-8")) if r["policy"] == "softmax"]
checks.append(len(rows) == 32)
every = all(float(r["delta_income_nominal_validator_budget_ci95_low"]) > 0
            and float(r["delta_quality_ci95_high"]) < 0 for r in rows)
checks.append(every)
print(f"{'OK ' if every else 'BAD'} all {len(rows)} softmax comparisons: gain interval > 0 and quality interval < 0")
h01 = [r for r in rows if r["h"] == "0.1"]
rel = lambda r: 100 * float(r["delta_income_nominal_validator_budget"]) / float(r["baseline_income_nominal_validator_budget"])
equal = lambda r: abs(float(r["stake0_requested"]) - 1 / int(r["n_validators"])) < 1e-12
big = lambda r: abs(float(r["stake0_requested"]) - 0.4) < 1e-12
eq11 = [rel(r) for r in h01 if equal(r) and r["n_validators"] == "11"]
eq31 = [rel(r) for r in h01 if equal(r) and r["n_validators"] == "31"]
big_rel = [rel(r) for r in h01 if big(r)]
big_dq = [-100 * float(r["delta_quality"]) for r in h01 if big(r)]
for label, got, want in (("equal stake, n=11, own-pay gain %", (round(min(eq11), 1), round(max(eq11), 1)), (1.8, 4.8)),
                         ("equal stake, n=31, own-pay gain %", (round(eq31[0], 1),), (4.5,)),
                         ("40% holder, own-pay gain %", (round(min(big_rel), 1), round(max(big_rel), 1)), (0.3, 0.6)),
                         ("40% holder, quality loss (pp)", (round(min(big_dq), 1), round(max(big_dq), 1)), (1.1, 1.6))):
    checks.append(got == want)
    print(f"{'OK ' if got == want else 'BAD'} {label}: {got} expected {want}")
print("all checks passed" if all(checks) else "SOME CHECKS FAILED")

if not all(checks):
    raise SystemExit("A quoted-number check failed")
