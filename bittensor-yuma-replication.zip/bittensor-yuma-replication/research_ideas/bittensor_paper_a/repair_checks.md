# Algebra for the manuscript repairs

Exact symbolic checks of clipping, reflection, affine continuation, and the soft-weight threshold.

- pooling allocation displacement
- favored fresh share
- unfavored fresh deficit
- maximum fresh deficit
- reflection payoff difference, sign 1
- reflection payoff difference, sign -1
- reflection signs
- oriented gain reduction
- affine honest continuation Bellman identity
- Bayes expectation for an arbitrary binary observation channel
- affine continuation does not depend on observation channel
- right derivative enforces the threshold before sufficiency
- tau <= 8/51 < 1
- threshold derivative slope positive

These computations do not establish strategy implementability, the filtering information set, or the full infinite-horizon comparison. Those steps are proved in the manuscript and reviewed separately.
