"""Exact algebra supporting the manuscript's boundary and dynamic repairs.

The universal strategy and filtration arguments remain natural-language proofs.
This script checks their displayed algebra, not those semantic reductions.
"""
from pathlib import Path
import json
import sympy as sp

R = sp.Rational
checks = []


def identity(name, left, right=0):
    residual = sp.factor(sp.cancel(left - right))
    if residual != 0:
        raise AssertionError((name, residual))
    checks.append({"name": name, "residual": "0"})


def main():
    n, h, u = sp.symbols("n h u", positive=True)
    alpha, delta, rho = sp.symbols("alpha delta rho", nonnegative=True)
    V, M, beta = sp.symbols("V M beta", nonnegative=True)
    c = 4 * (n - 1) / n
    report = R(1, 2) + h
    # Direct clipping with n-1 reports equal to 1/2 and report >= 1/2.
    rank_one = n / 2
    rank_zero = (n - 1) / 2 + 1 - report
    allocation = rank_one / (rank_one + rank_zero)
    share_one = R(1, 2) / rank_one
    share_zero = (1 - report) / rank_zero
    identity("pooling allocation displacement", allocation - R(1, 2), h / (2 * (n - h)))
    identity("favored fresh share", share_one, 1 / n)
    deficit = (1 / n - share_zero).subs(h, 2 * n * u / (1 + 2 * u))
    identity("unfavored fresh deficit", deficit, c * u / (1 - 2 * u))
    identity("maximum fresh deficit", (c * u / (1 - 2 * u)).subs(u, 1 / (4 * n - 2)), 1 / n)

    e1, e0 = sp.symbols("e1 e0", nonnegative=True)
    total = e1 + e0
    reflected = -V * total * (R(1, 2) - u) + beta * M * u
    for orientation in (1, -1):
        original = -V * (total / 2 + orientation * u * (e1 - e0)) + beta * M * orientation * u
        expected = 2 * V * u * e1 if orientation == 1 else 2 * u * (V * e0 + beta * M)
        identity(f"reflection payoff difference, sign {orientation}", reflected - original, expected)
    # Each expression on the right is nonnegative on the declared domain.
    checks.append({"name": "reflection signs", "domain": "V,M,beta,u,e0,e1 >= 0",
                   "certificates": ["2*V*u*e1", "2*u*(V*e0+beta*M)"]})
    D = sp.symbols("D", nonnegative=True)
    next_deficit = (1 - alpha) * D + alpha * c * u / (1 - 2 * u)
    direct_gain = beta * M * u - V * next_deficit * (R(1, 2) - u)
    reduced_gain = (beta * M - alpha * V * c / 2) * u - V * (1 - alpha) * D * (R(1, 2) - u)
    identity("oriented gain reduction", direct_gain, reduced_gain)

    pi, eta, Q = sp.symbols("pi eta Q", real=True)
    center = V / n - eta + beta * M / 2
    slope = beta * M * (2 * Q - 1)
    value = center / (1 - delta) + slope * (pi - R(1, 2)) / (1 - delta * rho)
    current = center + slope * (pi - R(1, 2))
    predicted = (1 - rho) / 2 + rho * pi
    identity("affine honest continuation Bellman identity", current + delta * value.subs(pi, predicted), value)
    a, b = sp.symbols("a b", positive=True)
    probability = pi * a + (1 - pi) * b
    posterior_one = pi * a / probability
    posterior_zero = pi * (1 - a) / (1 - probability)
    mean_posterior = probability * posterior_one + (1 - probability) * posterior_zero
    identity("Bayes expectation for an arbitrary binary observation channel", mean_posterior, pi)
    mean_value = probability * value.subs(pi, (1 - rho) / 2 + rho * posterior_one)
    mean_value += (1 - probability) * value.subs(pi, (1 - rho) / 2 + rho * posterior_zero)
    identity("affine continuation does not depend on observation channel", mean_value, value.subs(pi, predicted))

    ell, x, omega = sp.symbols("ell x omega", nonnegative=True)
    t, weight = R(3, 16), R(7, 16)
    tau = 2 * (28 * ell**2 + 56 * ell + 1) / (3 * (28 * ell**3 + 56 * ell**2 + 127 * ell + 72))
    derivative = weight * (-2 + 3 * omega * ell) / (3 - x + ell)**2
    derivative += t * (2 + 3 * omega * ell) / (2 + ell + x)**2 + 2 * omega * t / (1 + ell)
    slope_omega = sp.factor(sp.diff(derivative.subs(x, ell), omega))
    identity("right derivative enforces the threshold before sufficiency", derivative.subs(x, ell), slope_omega * (omega - tau))
    gap = sp.factor(R(8, 51) - tau)
    numerator, denominator = sp.fraction(sp.cancel(gap / (1 - 2 * ell)))
    z = sp.symbols("z")
    polynomial = sp.Poly(numerator.subs(ell, z / 2), z)
    degree = polynomial.degree()
    bernstein = [sum(polynomial.nth(k) * sp.binomial(j, k) / sp.binomial(degree, k)
                     for k in range(j + 1)) for j in range(degree + 1)]
    assert all(v > 0 for v in bernstein)
    assert all(v > 0 for v in sp.Poly(denominator, ell).all_coeffs())
    checks.append({"name": "tau <= 8/51 < 1", "domain": "0 <= ell <= 1/2",
                   "gap": str(gap), "positive_quotient": str(sp.factor(gap / (1 - 2 * ell))),
                   "numerator_Bernstein_coefficients_on_ell_0_to_half": [str(v) for v in bernstein]})
    for polynomial in sp.fraction(slope_omega):
        poly = sp.Poly(polynomial, ell)
        assert all(v >= 0 for v in poly.all_coeffs()) and poly.nth(0) > 0
    checks.append({"name": "threshold derivative slope positive", "coefficient": str(slope_omega)})

    out = Path(__file__).with_suffix(".json")
    out.write_text(json.dumps({"scope": __doc__, "checks": checks}, indent=2) + "\n", encoding="utf-8")
    Path(__file__).with_suffix(".md").write_text(
        "# Algebra for the manuscript repairs\n\n"
        "Exact symbolic checks of clipping, reflection, affine continuation, and the soft-weight threshold.\n\n"
        + "\n".join("- " + item["name"] for item in checks)
        + "\n\nThese computations do not establish strategy implementability, the filtering information set, or the full infinite-horizon comparison. Those steps are proved in the manuscript and reviewed separately.\n",
        encoding="utf-8")
    print(f"Passed {len(checks)} exact identities/sign records; saved {out.name}.")


if __name__ == "__main__":
    main()
