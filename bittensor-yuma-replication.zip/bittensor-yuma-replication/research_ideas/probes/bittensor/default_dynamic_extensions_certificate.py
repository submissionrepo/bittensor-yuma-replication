"""New exact checks: allocation Lipschitz, hard-report exclusion, finite witness."""
from pathlib import Path
from fractions import Fraction as F
import json
import sympy as s
from default_dynamic_probe import e,x,D,profiles,score,alpha,r,delta,z,w
from default_dynamic_certificate import rational_certificate,ELL
from yuma_endpoint_probe import step

R=s.Rational

def main():
    certs=[]
    intervals={'L':(R(0),ELL),'C':(ELL,1-ELL),'R':(1-ELL,R(1))}
    for key,(lo,hi) in intervals.items():
      for kk,row in enumerate(profiles[key]):
        derivative=s.diff(row[0],x).subs(e,ELL)
        for name,expr in (('nonnegative',derivative),('at_most_one',1-derivative)):
            certs.append({'claim':'allocation_derivative','branch':key,'k':kk,'bound':name,**rational_certificate(expr,lo,hi)})
    dmax=2*(1-2*e)/(3*(2-e))
    slope=s.factor(s.diff(score['C'],x).subs(x,e).subs(D,dmax))
    cleaned=s.cancel(e*slope).subs(e,x)
    hard=rational_certificate(cleaned,R(0),R(2,5))
    assert all(min(R(q) for q in piece['bernstein'])>0 for piece in hard['numerator_cover'])
    certs.append({'claim':'hard_report_boundary_slope','range':'0 < ell <= 2/5','expression':str(slope),**hard})
    # A finite, actually reachable default-alpha strict deviation at ell=2/5.
    ell=R(2,5);action=R(401,1000)
    for time in range(101):
        bond_difference=(1-r**time)*dmax.subs(e,ell)
        difference=s.cancel((score['C'].subs({e:ell,D:bond_difference,x:action})-score['C'].subs({e:ell,D:bond_difference,x:ell}))/2)
        if difference>0:break
    assert time<=100
    old=[[F(1,3),F(1,3)] for _ in range(3)]
    for _ in range(time):
        old=step([F(1,3)]*3,[F(1-ell),F(ell),F(ell)],old,F(alpha))[2]
    assert R(old[0][0]-old[0][1])==bond_difference
    exact=F(0)
    for kk,ww in enumerate(w):
        tail=[F(ell)]*(2-kk)+[F(1-ell)]*kk
        ref=step([F(1,3)]*3,[F(ell),*tail],old,F(alpha))
        dev=step([F(1,3)]*3,[F(action),*tail],old,F(alpha))
        shock=sum(dev[2][0])-sum(ref[2][0])
        full=dev[1][0]-ref[1][0]+F(R(1,2)*z/(2*(1-z)))*shock
        exact+=F(ww)*full
    assert R(exact)==difference and exact>0
    ownership=R(1,2000);margin=R(1,1000)-ownership
    eta=R(1,2)*margin*(1-2*ELL)/2
    assert eta==R(1,400000)
    data={'certificates':certs,'finite_witness':{'ell':str(ell),'history_length':time,'history_each_round':[str(1-ell),str(ell),str(ell)],'next_signal':0,'deviation':str(action),'full_discounted_conditional_gain':str(exact),'old_bond_difference':str(bond_difference)},'ownership_cap':str(ownership),'eta_max':str(eta)}
    Path(__file__).with_suffix('.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
    lines=['# Default dynamic extensions: exact algebra','','2026-09-30.',
           '- 18 rational interval inequalities prove 0 <= dI/dx <= 1 for ell=49/100, all three report branches and outsider counts.',
           '- One strictly positive rational interval certificate proves the right report derivative at the honest limiting maximum D is positive for every 0 < ell <= 2/5.',
           f'- Finite ell=2/5 witness: {time} repeated honest report profiles (3/5,2/5,2/5), then signal zero and report {action}; conditional full discounted gain={exact}>0.',
           '- The finite witness is independently replayed with the exact epoch routine and the exact positive-column geometric tail.',
           f'- Existing potential extends to ownership omega <= {ownership}, information cost eta <= {eta}; the normalized report margin is then at least {margin}.',
           '', 'Only the algebra and finite witness receive an exact/sympy credential; the general finite-history implication and multistage equilibrium proof are in the research note.','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print('\n'.join(lines),flush=True)

if __name__=='__main__':main()
