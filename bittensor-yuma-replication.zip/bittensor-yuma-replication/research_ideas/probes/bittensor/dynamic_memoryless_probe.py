"""Discovery for a genuinely dynamic, history-independent mechanism class.

The prior endpoint is supplied exactly.  Floats below are discovery only.
Symbolic and finite rational checks have separate, explicitly limited scope.
"""
from pathlib import Path
from math import comb
import json
import sys
import numpy as np
import sympy as sp
from scipy.optimize import linprog
from binary_mechanism_lp import build

R = sp.Rational


def model(n, p, omega, endpoint):
    p, omega, endpoint = map(R, (p, omega, endpoint))
    base = build(n, p, omega)
    index = {key: i for i, key in enumerate(base.names)}
    # The original builder puts count monotonicity first.  Replace all its
    # uniform-prior incentive inequalities by the two endpoint experiments.
    base.ub = base.ub[:n]
    base.ub_rhs = base.ub_rhs[:n]
    for prior in sorted({endpoint, 1-endpoint}):
        for beta in sorted({-omega, omega}):
            truth = [R(0)] * len(base.names)
            constants = [[R(0)] * len(base.names) for _ in range(2)]
            for theta in (0, 1):
                wt = prior if theta else 1-prior
                pt = p if theta else 1-p
                for k in range(n):
                    peer = R(comb(n-1, k))*pt**k*(1-pt)**(n-1-k)
                    for z in (0, 1):
                        prob = wt * peer * (pt if z else 1-pt)
                        truth[index[f'v{z}_{k+z}']] += prob
                        truth[index[f'a_{k+z}']] += prob*beta/2
                        for r in (0, 1):
                            constants[r][index[f'v{r}_{k+r}']] += prob
                            constants[r][index[f'a_{k+r}']] += prob*beta/2
            for noinfo in constants:
                row = [sp.cancel(y-x) for x, y in zip(truth, noinfo)]
                row[-1] += 1
                base.ub.append(row)
                base.ub_rhs.append(R(0))
    return base


def predict3(p, endpoint, eta, omega):
    p, endpoint, eta, omega = map(R, (p, endpoint, eta, omega))
    t=p*(1-p); d=2*p-1; V=M=R(1,2)
    rent=V*d*(p-endpoint)/3
    if eta > rent:
        return None
    lam = min(R(1), (rent-eta)/(2*omega*M*t*(p-d*endpoint))) if omega else R(1)
    A=3*p*p-2*p**3
    return sp.factor(R(1,2)+(A-R(1,2))*lam)


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    rows=[]
    for p in (R(3,5), R(3,4), R(9,10)):
        for frac in (R(0), R(1,3), R(2,3), R(9,10)):
            endpoint=R(1,2)+frac*(p-R(1,2))
            rent=R(1,2)*(2*p-1)*(p-endpoint)/3
            for cost_fraction in (R(1,4), R(3,4)):
                eta=cost_fraction*rent
                for omega in (R(0),R(1,10), R(1,2), R(1)):
                    answer=model(3,p,omega,endpoint).solve(cost=eta)
                    candidate=predict3(p,endpoint,eta,omega)
                    assert answer['success'], answer
                    residual=abs(answer['quality']-float(candidate))
                    assert residual < 2e-9, (p,endpoint,eta,omega,answer,candidate)
                    rows.append(dict(n=3,p=str(p),endpoint=str(endpoint),eta=str(eta),
                                     omega=str(omega),quality=answer['quality'],
                                     formula=str(candidate),error=residual))
    # Above the posterior separation boundary, no positive cost survives.
    impossible=[]
    for p in (R(3,5),R(3,4),R(9,10)):
        for endpoint in (p,(1+p)/2):
            result=model(3,p,R(0),endpoint).solve(cost=R(1,10000))
            assert not result['success'], (p,endpoint,result)
            impossible.append(dict(p=str(p),endpoint=str(endpoint),status=result['status']))
    # Genuine symbolic identities, distinct from the numerical discovery.
    p,P,V,u=sp.symbols('p P V u', real=True)
    q=1-p; d=2*p-1;t=p*q
    fixed1=P*(q*q*u+2*p*q*(V-u)/2+p*p*V/3)+(1-P)*(p*p*u+2*p*q*(V-u)/2+q*q*V/3)
    assert sp.factor(V/3-fixed1-d*(V/3-u)*(p-P))==0
    crit=(p**4+q**4)/(1-2*t)
    post_at_p=p**4/(p**4+q**4)
    assert sp.factor((1-crit)/2+crit*post_at_p-p)==0
    A=3*p*p-2*p**3
    Ae=p**3+R(3,2)*t
    efficiency=sp.factor((A-R(1,2))*(1-2*t)/2-(Ae-R(1,2))*2*t)
    assert sp.factor(efficiency-d*(1-4*t)/4)==0
    p0=R(3,4); endpoint=R(2,3)
    posterior=endpoint*p0**3/(endpoint*p0**3+(1-endpoint)*(1-p0)**3)
    rho=sp.factor((endpoint-R(1,2))/(posterior-R(1,2)))
    assert rho==R(55,159)
    assert sp.factor(crit.subs(p,p0))==R(41,80)
    example=predict3(p0,endpoint,R(1,288),R(1,4))
    assert example==R(101,180)
    output=dict(discovery=rows,positive_cost_infeasibility=impossible,
                symbolic=dict(constant_report_rent='d*(V/3-u)*(p-P)',
                              majority_efficiency=str(efficiency),
                              example_rho=str(rho),example_quality=str(example)))
    Path(__file__).with_suffix('.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    lines=['# 持续状态、历史无关机制：动态前沿探针','',
           '2026-09-29。数值LP只用于发现；符号恒等式不代替一般历史归约。', '',
           f'- {len(rows)} 个三人端点LP与候选闭式一致，最大误差 {max(row["error"] for row in rows):.3g}。',
           f'- {len(impossible)} 个后验端点达到或越过p的环境，正成本LP不可行（浮点发现）。',
           '- 符号重算：诚实验证收入减恒报1收入 = d(V/3-u)(p-P)。',
           '- 符号重算：多数与极端门槛的质量/影响力交叉差 = d(1-4pq)/4 >= 0。',
           '- 符号重算：后验端点P=p的持续性临界值rho=(p^4+q^4)/(1-2pq)。',
           '- p=3/4时临界rho=41/80；rho=55/159对应端点P=2/3。',
           f'- p=3/4,rho=55/159,V=M=1/2,eta=1/288,omega=1/4时闭式Q={example}。', '',
           '候选范围：每期报告、分配、支付仅依赖当期二元报告；策略必须抵御任意历史依赖的个体偏离。',
           '不是对所有有记忆机制的上界；也不是alpha<1的Yuma均衡。','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print(f'{len(rows)} discovery LPs; {len(impossible)} infeasibility probes; symbolic identities; example Q={example}.')


if __name__=='__main__':
    main()
