"""Classic Yuma: matched static quality metric and exact continuation sums.

Real-arithmetic, fixed stake, positive columns, beta=1, fixed future policy.
This is not a dynamic equilibrium solver or a current-chain parity test.
"""
from itertools import product
from math import comb
from fractions import Fraction as F
from pathlib import Path
import sys
import sympy as sp
from one_epoch_information import epoch
from static_frontier_probe import primitives

R=sp.Rational


def yuma_profile(n,k,alpha,ell=R(1,5),V=R(1,2)):
    high=1-ell
    if k<=n//2:
        a,v1,v0=yuma_profile(n,n-k,alpha,ell,V)
        return 1-a,v0,v1
    total=k+2*ell*(n-k)
    a=(k*high+(n-k)*ell)/total
    major=V*((1-alpha)/n+alpha/total)
    minor=V*((1-alpha)/n+alpha*2*ell/total)
    return a,minor,major


def metrics(n,p,alpha):
    rows=[yuma_profile(n,k,alpha) for k in range(n+1)]
    Q=sum(comb(n,k)*p**k*(1-p)**(n-k)*rows[k][0] for k in range(n+1))
    H=sum(comb(n-1,k)*p**k*(1-p)**(n-1-k)*(rows[k+1][0]-rows[k][0]) for k in range(n))
    noinfo=sum(R(1,2)*comb(n-1,k)*(p**k*(1-p)**(n-1-k)+(1-p)**k*p**(n-1-k))*rows[k+1][2] for k in range(n))
    G=R(1,2*n)-noinfo
    return tuple(map(sp.cancel,(Q,H,G,4*G/H)))


def details(reports,alpha):
    n=len(reports)
    rows=[(x,1-x) for x in reports]
    cap=[sorted(row[j] for row in rows)[n//2] for j in range(2)]
    clip=[[min(row[j],cap[j]) for j in range(2)] for row in rows]
    rank=[sum(row[j] for row in clip)/n for j in range(2)]
    assert all(z>0 for z in rank)
    incentive=[x/sum(rank) for x in rank]
    delta=[clip[0][j]/(n*rank[j]) for j in range(2)]
    dividend=sum(((1-alpha)/n+alpha*delta[j])*incentive[j] for j in range(2))/2
    return dividend,incentive[0]/2,delta


def conditional_pv(p,alpha,discount,rho,signal,report,n=3):
    truth=R(4,5) if signal else R(1,5)
    e=metrics(n,p,alpha)[0]-R(1,2)
    z=discount*(1-alpha)
    out=[sp.S.Zero]*2
    for theta in (0,1):
        posterior=p if theta==signal else 1-p
        for others in product((0,1),repeat=n-1):
            prob=posterior
            for s in others:
                prob*=p if s==theta else 1-p
            tail=[R(4,5) if s else R(1,5) for s in others]
            dev=details([report]+tail,alpha)
            ref=details([truth]+tail,alpha)
            diff=[a-b for a,b in zip(dev[2],ref[2])]
            future=alpha/2*(z/(1-z)*sum(diff)/2 + e*z*rho/(1-z*rho)*(2*theta-1)*(diff[0]-diff[1]))
            out[0]+=prob*(dev[0]-ref[0]+future)
            out[1]+=prob*(dev[1]-ref[1])
    return tuple(map(sp.cancel,out))


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    lines=['# Yuma 距离机制边界与 bonds 动态探针', '',
           '2026-09-29。研究记录。经典 Yuma 理想有理数路径；源码版本沿用 c004cebf。固定等 stake、beta=1、初始两列 bonds 均为 stake，报告候选为 1/5 或 4/5。不是 liquid-alpha/Yuma3 或当前链实现等价性结论。', '',
           '## 同一 Q 指标下的静态差距', '',
           'omega_Y=4G_Y/H_Y 是限制在两种报告内的 eta=0 个体所有权阈值；连续报告只会使阈值更低，故这里给上限。Q*_at_Y 是一般匿名二元机制在同一非负 omega_Y、eta=0 下的最优质量。负 G_Y 表示原信号报告已经不能提供信息激励。', '',
           '| n | p | alpha | Q_Y | G_Y | H_Y | omega_Y | Q*_at_Y | Q*−Q_Y |',
           '|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for n in (3,5,7):
        for p in (R(3,5),R(3,4),R(9,10)):
            for alpha in (R(1,10),R(1)):
                Q,H,G,w=metrics(n,p,alpha)
                A,b,Gmax,K=primitives(n,p)
                qstar=R(1,2)+(A-R(1,2))*min(1,K/w) if w>0 else A
                for k in range(n+1):
                    reports=[F(4,5)]*k+[F(1,5)]*(n-k)
                    actual=epoch((F(1,n),)*n,reports,F(alpha))
                    a,v0,v1=yuma_profile(n,k,alpha)
                    focal=v1 if k else v0
                    assert R(actual[0])==focal and R(actual[2])==a
                lines.append(f'| {n} | {p} | {alpha} | {Q} | {G} | {H} | {w} | {qstar if G>=0 else "truth not IC"} | {qstar-Q if G>=0 else "n/a"} |')
    lines += ['', '## 无限期继续价值的精确求和（固定继续策略）', '',
              '质量状态满足 P(theta_(t+1)=theta_t)=(1+rho)/2；delta 为折现率。当前改变报告，此后所有人回到仅按当轮信号报告。初始 bonds 相同；只保留一次偏离造成的 bonds 差，未来股权与 stake 固定。', '',
              '令 z=delta(1-alpha)，e=Q_Y−1/2，Delta_j 是当前偏离导致的归一化新 bond 差。未来验证收益差恰为 alpha V [z/(1-z) E[(Delta_0+Delta_1)/2] + e z rho/(1-z rho) E[(2theta_0−1)(Delta_1−Delta_0)]]。当前项另按真实 Yuma 归一化计算。', '',
              '表中枚举 report∈{0,1/20,...,1}，列出两种当前信号中的最大偏离收益；普通与拥有 miner 1 全部收入的情形分开。正值即可否定该固定继续策略下的当前真实报告最优性；未发现正值不证明连续最优，也不证明动态均衡。', '',
              '| p | alpha | delta | rho | 最大普通偏离收益 | 最大 owner 偏离收益 | owner 最优 (signal,report) |',
              '|---:|---:|---:|---:|---:|---:|---|']
    cases=0
    for p in (R(3,5),R(3,4),R(9,10)):
        for alpha in (R(1,10),R(1)):
            for discount in (R(9,10),R(99,100)):
                for rho in (R(0),R(4,5),R(49,50)):
                    values=[(conditional_pv(p,alpha,discount,rho,s,R(j,20)),s,R(j,20)) for s in (0,1) for j in range(21)]
                    plain=max((val[0],s,r) for val,s,r in values)
                    owner=max((sum(val),s,r) for val,s,r in values)
                    lines.append(f'| {p} | {alpha} | {discount} | {rho} | {float(plain[0]):.9g} | {float(owner[0]):.9g} | ({owner[1]},{owner[2]}) |')
                    cases+=1
    lines += ['', '## 不能从这个计算声称的事', '',
              '这里没有把历史信号带来的额外信息价值纳入最优继续策略。rho>0 时，历史会改变后验；仅按当轮信号报告可能忽略有价值信息。因此不能用表格声称已求出马尔可夫完美均衡、完整动态机制最优边界或真实协议被持续捕获。', '',
              '具体排除：把 alpha 直接当作长期信息激励的线性折损是不对的；继续价值包含两个不同分母 1−delta(1−alpha) 和 1−delta(1−alpha)rho。质量持续性通过第二项进入，符号也取决于 bond 差与真实状态的相关性。', '']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print(f'18 static rows independently replayed by epoch routine; {cases} infinite-horizon fixed-continuation environments, 42 exact report actions each.')


if __name__=='__main__':
    main()
