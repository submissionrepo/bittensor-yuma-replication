"""Exact small-coalition discovery: all signal acquisition/report policies.

Three validators, coalition of two; transferable rewards, pooled observations.
The theorem's arbitrary-p proof is in the Markdown research notebook.
"""
from itertools import product, combinations
from math import comb
from pathlib import Path
import sys
import sympy as sp
from static_frontier_probe import primitives

R = sp.Rational


def outcome(p, lam, r, x, acquired, policy, V=R(1,2)):
    """Unconditional quality, coalition validation reward, miner-1 share."""
    allocation = [(1-lam)/2-r,(1-lam)/2,(1+lam)/2,(1+lam)/2+r]
    out = [sp.S.Zero]*3
    for theta in (0,1):
        one = p if theta else 1-p
        for s in range(acquired+1):
            for other in (0,1):
                prob = R(1,2)*comb(acquired,s)*one**s*(1-one)**(acquired-s)
                prob *= one if other else 1-one
                j = policy[s]
                k = j+other
                if k in (0,3):
                    reward = 2*V/3
                else:
                    v1,v0 = (V-2*x,x) if k==1 else (x,V-2*x)
                    reward = j*v1+(2-j)*v0
                a = allocation[k]
                terms = (a if theta else 1-a,reward,a)
                out = [v+prob*z for v,z in zip(out,terms)]
    return tuple(map(sp.cancel,out))


def frontier_vertices(p, eta, omega, damage, V=R(1,2), M=R(1,2)):
    """Exact finite formula: feasible intersections of the six bounding lines."""
    A,b,G,K=primitives(3,p,V,M)
    t,d = p*(1-p),2*p-1
    # rows: a*lambda+b*r <= c
    rows = [(-1,0,0),(0,-1,0),(1,2,1),
            (omega*M*t,omega*M*(1-2*t)/2,G-eta),
            (d*(1+t),d*(1-t),damage),(d,d,damage)]
    candidates = []
    for i,j in combinations(range(len(rows)),2):
        a,b,c = rows[i]
        e,f,g = rows[j]
        det = a*f-b*e
        if not det:
            continue
        lam,r = sp.cancel((c*f-b*g)/det),sp.cancel((a*g-c*e)/det)
        if all(a*lam+b*r<=c for a,b,c in rows):
            quality = R(1,2)+d*((R(1,2)+t)*lam+(1-t)*r)
            candidates.append((quality,lam,r,i,j))
    return max(candidates) if candidates else None


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    lines = ['# 两人联盟：三人机制类的精确探针', '',
             '2026-09-29。研究记录。联盟可转移收益、共享两个信号、随机化、选择购买零/一/两个信号。外部第三人真实报告。', '',
             '分配 a=((1-lambda)/2-r,(1-lambda)/2,(1+lambda)/2,(1+lambda)/2+r)，lambda,r≥0，lambda+2r≤1。split profile 的多数人各付 x，少数人付 V-2x；一致时各付 V/3。', '',
             '候选最坏可盈利损害 D=(2p-1) max{(1+p(1-p))lambda+(1-p(1-p))r,lambda+r}。适用正信息租 G(v)=(2p-1)^2(x-V/3)>0。', '']
    checks=0
    for p in (R(3,5),R(3,4),R(9,10)):
        t,d=p*(1-p),2*p-1
        for lam_num in range(9):
            for r_num in range((8-lam_num)//2+1):
                lam,r=R(lam_num,8),R(r_num,8)
                x=R(1,4)
                truth=outcome(p,lam,r,x,2,(0,1,2))
                best_quality=min(outcome(p,lam,r,x,k,policy)[0]
                                 for k in (0,1,2) for policy in product(range(3),repeat=k+1))
                predicted=d*max((1+t)*lam+(1-t)*r,lam+r)
                assert truth[0]-best_quality==predicted
                if r>=lam:
                    attack=outcome(p,lam,r,x,2,(2,1,0))
                else:
                    left=outcome(p,lam,r,x,2,(2,0,0))
                    right=outcome(p,lam,r,x,2,(2,2,0))
                    attack=tuple((a+b)/2 for a,b in zip(left,right))
                assert attack[0]==best_quality
                assert attack[1]>truth[1]
                assert attack[2]==truth[2]==R(1,2)
                checks+=1
        lines.append(f'- p={p}: cumulative allocation checks {checks}; each enumerates 3+9+27=39 deterministic policies, with the explicit symmetric attack also checked exactly.')
    lines += ['', '## 联盟损害约束与个体所有权约束同时存在时', '',
              '下面是二维可行多边形全部交点的精确比较；不是一般 n 的结论。eta=G/4，Dbar 为容许联盟额外损害。', '',
              '| p | omega | Dbar | 最优 Q | lambda | r |', '|---:|---:|---:|---:|---:|---:|']
    for p in (R(3,5),R(3,4),R(9,10)):
        G=primitives(3,p)[2]
        for omega in (R(0),R(1,4),R(1)):
            for damage in (R(1,20),R(1,5),R(2,5)):
                ans=frontier_vertices(p,G/4,omega,damage)
                assert ans is not None
                quality,lam,r,_,_=ans
                lines.append(f'| {p} | {omega} | {damage} | {quality} | {lam} | {r} |')
    lines += ['', '## 发现的失败路线', '',
              '单人最优的压扁多数规则（r=0）并不同时优化联盟损害。在没有所有权约束且容许损害很小时，最优机制先只奖励全体一致的证据（lambda=0），随后才逐渐增加多数信号的分配作用。', '',
              '正信息租下，两人联盟的质量最差策略本身严格赚钱，且对 miner 1 的无条件期望分配仍为 1/2。故这个最坏策略的可盈利性对联盟持有任意一边 miner 的固定份额均成立；不是把纯粹恶意者假装成逐利者。', '',
              '原始目标若要求 D=0 且 Q>1/2，则在本三人类、正信息租、可转移联盟收益下不可行。固定分配达到 Q=1/2；此处“匹配”只解释边界，不将其包装为实用机制。', '']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print(f'{checks} exact allocation cases, {checks*39} complete policy evaluations; 27 exact design-frontier points.')


if __name__=='__main__':
    main()
