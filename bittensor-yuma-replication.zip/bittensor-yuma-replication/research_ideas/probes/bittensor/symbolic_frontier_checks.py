"""Symbolic identities and Bernstein certificates; no natural-language audit."""
from math import comb
from pathlib import Path
import sys
import sympy as sp
from coalition_frontier_probe import outcome, frontier_vertices
from static_frontier_probe import primitives
from itertools import product

R=sp.Rational


def bernstein(poly,var):
    poly=sp.Poly(sp.expand(poly),var)
    if poly.is_zero:return [sp.S.Zero]
    degree=poly.degree()
    return [sum(poly.nth(j)*R(comb(k,j),comb(degree,j)) for j in range(k+1)) for k in range(degree+1)]


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    p=sp.Symbol('p',real=True)
    lam,r,x,V=sp.symbols('lambda r x V',real=True)
    t=p*(1-p); d=2*p-1
    truth=outcome(p,lam,r,x,2,(0,1,2),V)
    assert sp.factor(truth[0]-(R(1,2)+d*((R(1,2)+t)*lam+(1-t)*r)))==0
    attack_split=outcome(p,lam,r,x,2,(2,1,0),V)
    end0=outcome(p,lam,r,x,2,(2,0,0),V)
    end1=outcome(p,lam,r,x,2,(2,2,0),V)
    attack_same=tuple(sp.cancel((a+b)/2) for a,b in zip(end0,end1))
    assert sp.factor(attack_split[1]-truth[1]-2*d**2*(x-V/3))==0
    assert sp.factor(attack_same[1]-truth[1]-2*(1-2*t)*(x-V/3))==0
    assert attack_split[2]==attack_same[2]==truth[2]==R(1,2)
    z,e,base=sp.symbols('z e base',real=True)
    certificates=[]
    for branch,attack,sub in (
        ('r>=lambda',attack_split,{lam:base,r:base+e,p:(1+z)/2}),
        ('lambda>=r',attack_same,{lam:base+e,r:base,p:(1+z)/2})):
        for k in (0,1,2):
            for policy in product(range(3),repeat=k+1):
                diff=sp.expand((outcome(p,lam,r,x,k,policy,V)[0]-attack[0]).subs(sub))
                assert sp.expand(diff-diff.coeff(base)*base-diff.coeff(e)*e)==0
                coefs=[bernstein(diff.coeff(v),z) for v in (base,e)]
                assert all(c>=0 for row in coefs for c in row),(branch,k,policy,diff,coefs)
                certificates.append((branch,k,policy,coefs))
    # Four-piece coalition design: global supporting linear inequalities.
    first=sp.factor((1-t)*(lam+r)-((R(1,2)+t)*lam+(1-t)*r))
    assert first==sp.factor((R(1,2)-2*t)*lam)
    assert sp.factor((R(1,2)+t)*lam+(1-t)*r-(R(1,2)-2*t)*(lam+2*r)-3*t*(lam+r))==0
    assert sp.factor((R(1,2)+t)*lam+(1-t)*r-(1-t)/(2*(1+3*t))*(lam+2*r)-3*t/(1+3*t)*((1+t)*lam+(1-t)*r))==0
    checks=0
    for n in range(3,24,2):
        m=n//2;q=1-p
        A=sum(comb(n,k)*p**k*q**(n-k) for k in range(m+1,n+1))
        b=comb(n-1,m)*(p*q)**m
        assert sp.expand(sp.diff(A,p)-n*b)==0
        noinfo=sum(R(1,2)*comb(n-1,k-1)*(p**(k-1)*q**(n-k)+q**(k-1)*p**(n-k))/k for k in range(m+1,n+1))
        assert sp.cancel(noinfo-(A/p+(1-A)/q)/(2*n))==0
        checks+=2
    delta,alpha,rho=sp.symbols('delta alpha rho',real=True)
    zed=delta*(1-alpha)
    P=sp.Matrix([[(1+rho)/2,(1-rho)/2],[(1-rho)/2,(1+rho)/2]])
    resolvent=zed*P*(sp.eye(2)-zed*P).inv()
    c0=zed/(1-zed);c1=zed*rho/(1-zed*rho)
    target=sp.Matrix([[(c0+c1)/2,(c0-c1)/2],[(c0-c1)/2,(c0+c1)/2]])
    assert all(sp.cancel(v)==0 for v in resolvent-target)
    lines=['# 符号重算与非负证书', '',
           '2026-09-29。第一层计算；不替代第二层对模型、量词、经济学归约及整段证明的独立核查。', '',
           '## 三人联盟全参数质量比较', '',
           'p=(1+z)/2，z∈[0,1]。在 r≥lambda 分支取 r=base+e、lambda=base；另一分支交换。base,e≥0。',
           '对每个确定性零/一/二信号策略，Q_policy−Q_attack=base P(z)+e R(z)。下列每个多项式的 Bernstein 系数非负，因此在整个区间非负；不是 p 网格。', '']
    for branch,k,policy,coefs in certificates:
        lines.append(f'- {branch}; acquired={k}; policy={policy}; Bernstein(base,e)={coefs}.')
    lines += ['', '## 其他恒等式', '',
              '- 三人真实质量、两种攻击的质量与精确利润差、期望 miner 分配均由独立枚举式作符号相消。攻击利润分别为 2(2p−1)^2(x−V/3) 和 2(1−2p(1−p))(x−V/3)。',
              '- 三人无所有权设计的三条全局支撑不等式：两条恒等式精确相消，第一条差为 (1/2−2p(1−p))lambda≥0。',
              f'- n=3,5,...,23 的二项导数与无信息支付尾和共 {checks} 个多项式/有理函数恒等式精确为零；这是有限 n 的符号范围，不认证任意 n 的证明。',
              '- 动态项：2×2 Markov 矩阵的 zP(I−zP)^(-1) 与两个特征通道 z/(1−z)、z rho/(1−z rho) 的矩阵表达逐项精确相等。z=delta(1−alpha)。收敛范围仍由假设 0≤delta<1,0<alpha≤1,0≤rho≤1 保证。', '']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print(f'{len(certificates)} all-p policy inequalities with nonnegative Bernstein certificates; {checks} finite-n binomial identities; coalition support identities; dynamic resolvent identity.')


if __name__=='__main__':main()
