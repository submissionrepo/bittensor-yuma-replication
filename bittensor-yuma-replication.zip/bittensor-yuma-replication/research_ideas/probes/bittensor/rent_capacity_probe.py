"""First-layer probe for the individual information-rent capacity theorem."""
from itertools import product,combinations
from fractions import Fraction as F
from math import comb
from pathlib import Path
import sys
import numpy as np
from scipy.optimize import linprog
import sympy as sp
from stake_extension_probe import design as full_design


def probs(bits,p):
    k=sum(bits);n=len(bits)
    return (p**k*(1-p)**(n-k)+(1-p)**k*p**(n-k))/2


def resources(n,p,V=F(1,2)):
    m=n//2;d=2*p-1
    weight={j:V*d*(p**(j-1)*(1-p)**(n-j)-(1-p)**(j-1)*p**(n-j))/2 for j in range(m+2,n+1)}
    cap=[sum((comb(n,j)-(comb(n-k,j) if n-k>=j else 0))*r for j,r in weight.items()) for k in range(n+1)]
    return weight,cap


def threshold_columns(stakes,p):
    n=len(stakes);bits=list(product((0,1),repeat=n));scores={r:sum(s*b for s,b in zip(stakes,r)) for r in bits}
    thresholds=sorted({v for v in scores.values() if v>F(1,2)})
    quality=[];influence=[]
    for threshold in thresholds:
        alloc={r:(F(1) if score>=threshold else F(0) if score<=1-threshold else F(1,2)) for r,score in scores.items()}
        Q=sum(p**sum(r)*(1-p)**(n-sum(r))*alloc[r] for r in bits)
        H=[]
        for i in range(n):
            value=F(0)
            for tail in product((0,1),repeat=n-1):
                low=tail[:i]+(0,)+tail[i:];high=tail[:i]+(1,)+tail[i:]
                value+=p**sum(tail)*(1-p)**(n-1-sum(tail))*(alloc[high]-alloc[low])
            H.append(value)
        quality.append(Q);influence.append(H)
    return thresholds,quality,influence


def reduced_design(stakes,p,omega,eta=F(0),V=F(1,2),M=F(1,2)):
    n=len(stakes);thresholds,Q,H=threshold_columns(stakes,p);_,cap=resources(n,p,V)
    A=[[1]*len(Q)];b=[F(1)]
    for size in range(1,n+1):
        for subset in combinations(range(n),size):
            A.append([omega*M*sum(col[i] for i in subset)/2 for col in H]);b.append(cap[size]-size*eta)
    obj=[F(1,2)-v for v in Q]
    ans=linprog(np.array(obj,float),A_ub=np.array(A,float),b_ub=np.array(b,float),bounds=(0,None),method='highs')
    assert ans.success,ans.message
    return .5-ans.fun,dict(thresholds=thresholds,Q=Q,H=H,A=A,b=b,obj=obj,x=ans.x)


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    lines=['# 信息租金容量：任意 stake 设计的新探针','',
           '2026-09-29。新候选：允许按身份支付但要求标签对称、逐 profile 固定预算时，非负租金要求g_i的可行性等价于每个子集T满足sum_T g_i<=C_|T|。资源只分给严格超过最小多数的胜方；最小多数的租金系数为零。','',
           'R_j=V(2p-1)/2·[p^(j-1)(1-p)^(n-j)-(1-p)^(j-1)p^(n-j)]，j≥(n+3)/2；C_k=sum_j [C(n,j)-C(n-k,j)] R_j。','',
           '## 精确支持函数比对','']
    count=0
    for n in (3,5,7):
        for p in (F(3,5),F(3,4),F(9,10)):
            weights,cap=resources(n,p)
            for prices in ([F(1)]*n,[F(i+1,n) for i in range(n)],[F(1)]+[F(0)]*(n-1)):
                direct=F(0)
                for bits in product((0,1),repeat=n):
                    cs=[]
                    for i in range(n):
                        tail=bits[:i]+bits[i+1:]
                        cs.append(prices[i]*(probs(bits,p)-probs(tail,p)/2))
                    direct+=F(1,2)*max(cs)
                via=sum(weight*max(prices[i] for i in subset) for j,weight in weights.items() for subset in combinations(range(n),j))
                assert direct==via
                sorted_prices=sorted(prices,reverse=True)+[F(0)]
                cut=sum((sorted_prices[k-1]-sorted_prices[k])*cap[k] for k in range(1,n+1))
                assert via==cut
                count+=1
            lines.append(f'- n={n},p={p}: C={list(map(str,cap))}.')
    lines += ['',f'共{count}个有理价格向量：完整profile支付优化的支持函数、资源分配表达式、排序子集容量表达式三者精确相等。有限点不认证一般凸分离论证。','',
              '## 新容量 LP 与完整支付 LP 的比对（浮点）','',
              '| stakes | p | omega | capacity Q | full Q |','|---|---:|---:|---:|---:|']
    cases=[(F(1,3),)*3,(F(49,100),F(26,100),F(1,4)),(F(3,5),F(1,5),F(1,5)),
           (F(1,5),)*5,(F(2,5),)+(F(3,20),)*4,(F(3,5),)+(F(1,10),)*4]
    for stakes in cases:
        for p,omega in ((F(3,5),F(1,4)),(F(3,4),F(1,2)),(F(9,10),F(1))):
            reduced,_=reduced_design(stakes,p,omega)
            full=full_design(stakes,p,omega)
            assert abs(reduced-full)<1e-8
            lines.append(f'| {tuple(map(str,stakes))} | {p} | {omega} | {reduced:.12g} | {full:.12g} |')
    lines += ['', '以上18个新参数点用于检查新归约，不重复旧凭证中的最优性陈述。一般支付容量定理及匹配流分配构造另写在研究推导中。','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print(f'{count} exact support identities; 18 new reduced-vs-full LP matches.')


if __name__=='__main__':main()
