"""Finite anonymous report-only mechanism design, as a discovery LP.

This is a ONE-ROUND binary-report class, not the full dynamic target class.
All coefficients are rational; floating-point LP results are not certificates.
"""

from dataclasses import dataclass
from math import comb
from pathlib import Path
import sys

import numpy as np
from scipy.optimize import linprog
import sympy as sp


R = sp.Rational


@dataclass
class Model:
    n: int
    precision: sp.Rational
    ownership: sp.Rational
    names: list
    eq: list
    eq_rhs: list
    ub: list
    ub_rhs: list
    quality: list
    bounds: list

    def solve(self, *, cost=None, quality_floor=None):
        count = len(self.names)
        obj = np.zeros(count)
        if cost is None:
            obj[-1] = -1  # maximize affordable information cost
        else:
            obj = -np.array(self.quality, dtype=float)
        ub, rhs = list(self.ub), list(self.ub_rhs)
        bounds = list(self.bounds)
        if cost is not None:
            bounds[-1] = (float(cost), float(cost))
        if quality_floor is not None:
            ub.append([-v for v in self.quality])
            rhs.append(R(1, 2) - quality_floor)
        result = linprog(obj, A_ub=np.array(ub, dtype=float), b_ub=np.array(rhs, dtype=float),
                         A_eq=np.array(self.eq, dtype=float), b_eq=np.array(self.eq_rhs, dtype=float),
                         bounds=bounds, method='highs')
        if not result.success:
            return dict(status=result.message, success=False)
        eq_resid = max(abs(np.array(self.eq, dtype=float) @ result.x - np.array(self.eq_rhs, dtype=float)))
        min_slack = min(np.array(rhs, dtype=float) - np.array(ub, dtype=float) @ result.x)
        return dict(success=True, status=result.message, cost=float(result.x[-1]),
                    quality=float(R(1, 2) + np.dot(np.array(self.quality, dtype=float), result.x)),
                    x=result.x, eq_resid=float(eq_resid), min_slack=float(min_slack),
                    dual_eq=result.eqlin.marginals, dual_ub=result.ineqlin.marginals,
                    dual_lower=result.lower.marginals, dual_upper=result.upper.marginals)


def build(n, precision, ownership):
    p, omega = R(precision), R(ownership)
    names = [f'a_{k}' for k in range(n + 1)]
    names += [f'v0_{k}' for k in range(n)] + [f'v1_{k}' for k in range(1, n + 1)]
    names += ['eta']
    index = {name: i for i, name in enumerate(names)}
    zero = lambda: [sp.S.Zero] * len(names)
    eq, eq_rhs, ub, ub_rhs = [], [], [], []

    def conditional(signal, report, stake_in_miner):
        vec = zero()
        for theta in (0, 1):
            posterior = p if theta == signal else 1 - p
            prob_one = p if theta else 1 - p
            for other_ones in range(n):
                prob = posterior * comb(n - 1, other_ones) * prob_one ** other_ones * (1 - prob_one) ** (n - 1 - other_ones)
                k = other_ones + report
                vec[index[f'v{report}_{k}']] += prob
                # Sign +/- represents ownership of miner 1/0; the latter's
                # constant omega/2 cancels from every incentive difference.
                vec[index[f'a_{k}']] += prob * stake_in_miner / 2
        return vec

    def geq(vec, rhs=0):
        ub.append([-sp.cancel(v) for v in vec])
        ub_rhs.append(-R(rhs))

    # Exact ex-post validation budget 1/2; the other 1/2 goes to miners.
    for k in range(n + 1):
        vec = zero()
        if k < n:
            vec[index[f'v0_{k}']] = n - k
        if k:
            vec[index[f'v1_{k}']] = k
        eq.append(vec)
        eq_rhs.append(R(1, 2))
    # Relabeling symmetry between miners and anonymity among validators.
    for k in range((n + 1) // 2):
        vec = zero()
        vec[index[f'a_{k}']] = 1
        vec[index[f'a_{n-k}']] = 1
        eq.append(vec)
        eq_rhs.append(1)
    for k in range(n):
        vec = zero()
        vec[index[f'v0_{k}']] = 1
        vec[index[f'v1_{n-k}']] = -1
        eq.append(vec)
        eq_rhs.append(0)
    # More reports for miner 1 cannot reduce its share in this probe class.
    for k in range(n):
        vec = zero()
        vec[index[f'a_{k+1}']] = 1
        vec[index[f'a_{k}']] = -1
        geq(vec)
    # The same mechanism must work for an ordinary validator and a validator
    # owning up to omega of either miner. Other validators remain ordinary.
    for owner in sorted({-omega, sp.S.Zero, omega}):
        cond = {(z, r): conditional(z, r, owner) for z in (0, 1) for r in (0, 1)}
        for z in (0, 1):
            geq([a - b for a, b in zip(cond[z, z], cond[z, 1 - z])])
        truthful = [(a + b) / 2 for a, b in zip(cond[0, 0], cond[1, 1])]
        for r in (0, 1):
            noinfo = [(a + b) / 2 for a, b in zip(cond[0, r], cond[1, r])]
            margin = [a - b for a, b in zip(truthful, noinfo)]
            margin[-1] -= 1
            geq(margin)
    quality = zero()
    for k in range(n + 1):
        prob_high = R(comb(n, k)) * p**k * (1-p)**(n-k)
        prob_low = R(comb(n, k)) * (1-p)**k * p**(n-k)
        quality[index[f'a_{k}']] = (prob_high - prob_low) / 2
    bounds = [(0, 1)] * (n + 1) + [(0, R(1, 2))] * (2 * n) + [(0, R(1, 2))]
    return Model(n, p, omega, names, eq, eq_rhs, ub, ub_rhs, quality, bounds)


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    lines = ['# 二元报告机制类：信息成本与所有权稳健性 LP 探针', '',
             '日期：2026-09-29。研究探索记录；HiGHS 浮点最优值不作为通用定理或机器凭证。', '',
             '## 机制类与约束', '',
             '单轮，n 个等 stake 验证者，两个 miner；真实优劣 θ 的先验各半，每个付费信号条件独立且准确率 p。报告为 0/1，候选信息策略为付费观察并报告信号。', '',
             '机制变量：k 个报告为 1 时，miner 1 取得矿工预算的 a_k；报告 r 的每个验证者取得 v_{r,k}。每个报告剖面下 validator 总支付恰为 1/2，miner 总支付恰为 1/2；支付非负。验证者匿名、两 miner 标签对称，a_k 单调。机制不观察真值或所有权。', '',
             '约束：其他验证者按信号报告时，焦点验证者无论仅拿验证收益，还是拥有至多 omega 的任一 miner 收益，都没有条件于信号的虚报收益；付费观察并报告相对任一不观察的固定报告，毛收益差至少 eta。随机不观察报告是固定报告的凸组合；两种信号下的虚报约束覆盖所有单人报告映射。', '',
             '质量指标为奖励到较优 miner 的期望份额，Q = E[a_K | θ=1]/2 + E[1-a_K | θ=0]/2。它与 one_epoch_information.md 中的平方误差不同，数值不能直接并列比较。', '',
             '第一组最大化 Q，固定 eta=0；第二组在 Q≥3/4 下最大化 eta。eta=0 的点可能只有弱激励，不能据此宣称有正成本信息生产。这个类只处理一个矿工所有者的单人偏离，未处理多验证者联盟、动态 bonds 或持续捕获。', '',
             '## LP 发现', '',
             '| n | p | omega | eta=0 时最大 Q | Q≥3/4 时最大 eta |',
             '|---:|---:|---:|---:|---:|']
    selected = []
    for n in (3, 5):
        for p in (R(3, 5), R(3, 4), R(9, 10)):
            for omega in (R(0), R(1, 4), R(1, 2), R(1)):
                model = build(n, p, omega)
                q = model.solve(cost=0)
                c = model.solve(quality_floor=R(3, 4))
                qtext = f"{q['quality']:.10f}" if q['success'] else 'infeasible/solver failure'
                ctext = f"{c['cost']:.10f}" if c['success'] else 'infeasible/solver failure'
                lines.append(f'| {n} | {p} | {omega} | {qtext} | {ctext} |')
                if n == 3 and p == R(3, 4):
                    selected.append((model, q, c))
    lines += ['', '## 选定点的解与残差（浮点）', '']
    for model, q, c in selected:
        lines.append(f'### n={model.n}, p={model.precision}, omega={model.ownership}')
        lines.append('')
        for label, result in [('max_Q_at_zero_cost', q), ('max_eta_at_Q_3over4', c)]:
            if not result['success']:
                lines.append(f"- {label}: {result['status']}")
                continue
            candidate = ', '.join(f'{name}={R(float(value)).limit_denominator(100000)}'
                                  for name, value in zip(model.names, result['x']))
            lines.append(f"- {label}: Q={result['quality']:.12g}; eta={result['cost']:.12g}; max equality residual={result['eq_resid']:.3g}; min inequality slack={result['min_slack']:.3g}.")
            lines.append(f'- Rational reconstruction candidate (not yet certified): {candidate}.')
        lines.append('')
    lines += ['## 解释边界', '',
              '“有解”说明这一个有限机制类中的候选激励要求在数值上兼容；不等于 Yuma 本身满足要求。',
              '“无解”只涉及上述匿名、对称、单调、固定 1/2–1/2 支付、单轮二元报告机制类；不能升级为一般 peer prediction 或动态评价机制的不可能性。',
              '后续若抽出候选边界，须把有理构造精确回代，并独立证明上界；LP 返回 optimal 本身不替代这两步。', '']
    out = Path(__file__).with_suffix('.md')
    out.write_text('\n'.join(lines), encoding='utf-8')
    print(f'Wrote {out}; 24 environments, 48 LP solves.')
    for model, q, c in selected:
        print(dict(n=model.n, p=str(model.precision), ownership=str(model.ownership),
                   max_quality=q.get('quality'), max_cost_at_quality_075=c.get('cost')))


if __name__ == '__main__':
    main()
