"""One validator's fixed hedge against a specified Gaussian report policy.

Finite paired Monte Carlo under the integer production epoch port. Neither an
equilibrium search nor a best response. Main policy: temperature-.3 softmax;
deviator 0 replaces w by (1-h)w+h uniform, h fixed at .1 or .25.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import copy
import csv
import json
import math
import sys
import time

import numpy as np
from scipy.stats import t as student_t

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "protocol"))
from python_epoch import epoch
from differential import rust_batch, first_difference

SOURCE_COMMIT = "c004cebf360f4088187ee49d851dfb1a1eaaf710"
SEED = 20260930
EMISSION = 1_000_000_000
TEMPERATURE = .3
SIGMA = .3
GAP = .3
HEDGES = (.1, .25)
V_NOMINAL = .5


def seed_for(nv, miners):
    # Stakes and h do not change the random sequence within each (nv,miners).
    return SEED + 100000 * nv + 1000 * miners


def signals(nv, miners, samples):
    rng = np.random.default_rng(seed_for(nv, miners))
    # Draw sample by sample so the 512 pilot is the prefix of the 2048 run.
    best = np.empty(samples, dtype=int)
    values = np.empty((samples, nv, miners))
    for r in range(samples):
        best[r] = rng.integers(miners)
        means = np.ones(miners)
        means[best[r]] += GAP
        values[r] = means + SIGMA * rng.standard_normal((nv, miners))
    return best, values


def probabilities(values, policy):
    if policy == "onehot":
        rows = np.zeros_like(values)
        rows[np.arange(len(rows)), np.argmax(values, axis=1)] = 1.
        return rows
    unnormalised = np.exp((values - values.max(axis=1, keepdims=True)) / TEMPERATURE)
    return unnormalised / unnormalised.sum(axis=1, keepdims=True)


def encode(rows):
    # Same u16 maxscale/nearest convention as robustness_probe.encode.
    return np.rint(65535 * rows / rows.max(axis=1, keepdims=True)).astype(int)


def input_state(nv, miners, stake0):
    stakes = np.rint(np.array([stake0] + [(1-stake0)/(nv-1)]*(nv-1))*10**9).astype(int).tolist()
    size = nv + miners
    return dict(stakes=stakes+[0]*miners, weights_sparse=[[] for _ in range(size)],
                bonds_sparse=[[] for _ in range(size)], permits=[i<nv for i in range(size)],
                max_validators=nv,current_block=110,last_update=[100]*size,registration=[0]*size,
                yuma3=False,liquid=False,moving_average=0,bonds_penalty=65535,kappa=32767,
                emission=EMISSION)


def with_report(state, raw, nv, miners):
    out = state.copy()
    # Explicit zeros retained, matching the existing robustness state adapter.
    out["weights_sparse"] = [[[nv+j,int(v)] for j,v in enumerate(row)] for row in raw] + [[] for _ in range(miners)]
    return out


def outcomes(result, nv, miners, best):
    terms = result["terms"]
    validator = [t["validator_emission"] for t in terms[:nv]]
    miner = [t["server_emission"] for t in terms[nv:nv+miners]]
    vp, mp = sum(validator), sum(miner)
    income = validator[0] / EMISSION
    quality = miner[best]/mp if mp else 0.
    return np.array([income, income/V_NOMINAL, validator[0]/vp if vp else 0.,
                     quality, miner[best]/EMISSION, float(mp == 0), vp/EMISSION])


METRICS = ["income_epoch", "income_nominal_validator_budget", "share_actual_validator_pool",
           "quality", "best_miner_emission_epoch", "zero_miner_emission", "validator_pool_epoch"]


def ci(values):
    count = len(values)
    mean = float(np.mean(values))
    se = float(np.std(values, ddof=1)/math.sqrt(count))
    critical = float(student_t.ppf(.975,count-1))
    return mean, se, mean-critical*se, mean+critical*se


def run_environment(nv, miners, stake0, policy, samples, fixtures):
    state = input_state(nv,miners,stake0)
    best, values = signals(nv,miners,samples)
    baseline = np.empty((samples,len(METRICS)))
    deviated = {h:np.empty_like(baseline) for h in HEDGES}
    for r in range(samples):
        prescribed = probabilities(values[r],policy)
        initial = with_report(state,encode(prescribed),nv,miners)
        baseline[r] = outcomes(epoch(initial),nv,miners,int(best[r]))
        # New source comparisons are chosen by fixed configuration/sample index,
        # before inspecting any income or quality result.
        keep_fixture = r == 0 and ((nv==11 and stake0==.4) or (nv==31 and miners==5 and stake0==.4))
        if keep_fixture:
            fixtures.append(dict(policy=policy,n_validators=nv,miners=miners,stake0=stake0,
                                 sample_index=r,kind="baseline",h=0.,input=initial))
        for h in HEDGES:
            changed = prescribed.copy()
            changed[0] = (1-h)*prescribed[0]+h/miners
            attacked = with_report(state,encode(changed),nv,miners)
            deviated[h][r] = outcomes(epoch(attacked),nv,miners,int(best[r]))
            if keep_fixture:
                fixtures.append(dict(policy=policy,n_validators=nv,miners=miners,stake0=stake0,
                                     sample_index=r,kind="hedge",h=h,input=attacked))
    results=[]
    for h in HEDGES:
        delta = deviated[h]-baseline
        row=dict(policy=policy,n_validators=nv,miners=miners,stake0_requested=stake0,
                 stake0_effective=state["stakes"][0]/sum(state["stakes"]),h=h,samples=samples,
                 seed=seed_for(nv,miners),ownership=0,signal_mean_gap=GAP,noise_sigma=SIGMA,
                 noise_corr=0,temperature=TEMPERATURE,alpha=1,nominal_validator_budget=V_NOMINAL,
                 source_commit=SOURCE_COMMIT)
        for j,metric in enumerate(METRICS):
            row["baseline_"+metric]=float(baseline[:,j].mean())
            row["hedge_"+metric]=float(deviated[h][:,j].mean())
            mean,se,lo,hi=ci(delta[:,j])
            for suffix,value in [("",mean),("_se",se),("_ci95_low",lo),("_ci95_high",hi)]:
                row["delta_"+metric+suffix]=value
        row["positive_income_samples"]=int(np.sum(delta[:,0]>0))
        row["negative_income_samples"]=int(np.sum(delta[:,0]<0))
        row["zero_income_samples"]=int(np.sum(delta[:,0]==0))
        results.append(row)
    return results


def write_csv(path,rows):
    with path.open("w",newline="",encoding="utf-8") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


def write_report(rows,summary):
    lines=["# 单 validator 固定对冲策略：源码定点测量", "", "这是研究计算记录；不是均衡、最佳响应或通用不可能性证明。", "",
           "## 设计与事前修订", "",
           "初始分工拟用按最高信号全押的报告作为主基准。在计算任何收益结果之前，检查真实协议零列规则发现：多 miner 全押时所有列可能均未达到多数支持，源 epoch 会把排放全部回退给 validator。主线程据此明确将主网格改为温度 0.3 的连续 softmax，沿用已有 robustness 的报告规则。全押只保留 n=11、stake0=0.4、miner数2与5的两组控制。本修订不依据观测收益挑选策略。", "",
           "主网格为 n=11、miner数2/5/10、stake0=1/11、0.1、0.25、0.4；及 n=31、miner数5、stake0=1/31、0.1、0.25、0.4，共16个环境。所有环境事前固定 h=0.1、0.25，报告所有正负结果。只允许 validator 0 的报告变化，其余报告完全保持；双方购买同样的评估，成本相消，持股 omega=0。", "",
           "每个样本先均匀选择一个真实最佳 miner，其质量均值为1.3，其余为1；各 validator×miner 加独立 N(0,0.3²) 噪声。主报告 w=softmax(signal/0.3)，偏离报告 w'=(1-h)w+h/m；控制报告为 onehot(argmax signal)，偏离仍施加相同固定混合。策略只读取自身信号，不能读取其他报告或真实质量。", "",
           "采用完整 n+m 个 UID 的稀疏 epoch，validator 与 miner UID 分离，miner stake 为零。stake 按总量10^9就近取整，CSV同时给出请求份额与实际份额。每行报告按最大值放大到65535并用 numpy.rint 编成u16，显式零项保留；所有 miner 一并参与列裁剪和全局归一化。", "",
           "只测 classic legacy、moving_average=0，即 alpha=1；liquid与Yuma3关闭。这是当期旧bonds权重为零的设定，**不是 delta→1 的耐心极限**。所有偏离都使用同一个协议版本和真实定点舍入。", "",
           "## 统计口径", "",
           f"当前每个环境使用 {summary['samples']} 个配对样本。基种子 {SEED}，具体seed=基种子+100000*n+1000*m。同一(n,m)的stake设置共享信号流，baseline与两个h逐样本共享信号和真实最佳miner。各置信区间是配对差值的均值±t_(R-1,0.975)×样本标准误，为逐点近似95% Monte Carlo区间，不是多重比较后的同时区间。", "",
           "已先统一运行512样本预试；随后主线程明确要求主网格及两个控制统一扩大到2048样本作为正文采用结果，以缩小区间，不再根据显著性追加。2048流的前512项与预试相同，两档不是独立证据。512结果保留为运行记录。", "",
           "收入以真实 validator_emission 整数计算。delta_income_epoch 是 validator0 收入变化除以总epoch排放10^9；delta_income_nominal_validator_budget 再除以名义validator预算V=1/2，故等于前者两倍。实际validator池在零权重回退时可能占全部排放，因此另报实际池内份额变化，不能把这个可变分母指标当作收入。", "",
           "quality 是实际miner排放中分给真实最佳miner的比例；没有miner排放时依已有robustness约定记0，并单独报告零miner排放率。delta_quality=对冲后减基准，负值表示此口径下降；另报最佳miner所得占总epoch排放的变化。", "",
           "## 结果", "", "| 基准 | n | miner数 | stake0 | h | Δ收入/总epoch（95% MC区间） | Δ收入/名义V | Δ质量（95% MC区间） | 零miner排放率：前→后 |",
           "| --- | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |"]
    for r in rows:
        lines.append(f"| {r['policy']} | {r['n_validators']} | {r['miners']} | {r['stake0_requested']:.6g} | {r['h']} | {r['delta_income_epoch']:.7f} [{r['delta_income_epoch_ci95_low']:.7f}, {r['delta_income_epoch_ci95_high']:.7f}] | {r['delta_income_nominal_validator_budget']:.7f} | {r['delta_quality']:.7f} [{r['delta_quality_ci95_low']:.7f}, {r['delta_quality_ci95_high']:.7f}] | {r['baseline_zero_miner_emission']:.4f}→{r['hedge_zero_miner_emission']:.4f} |")
    main=[r for r in rows if r['policy']=='softmax']
    positive=sum(r['delta_income_epoch_ci95_low']>0 for r in main)
    negative=sum(r['delta_income_epoch_ci95_high']<0 for r in main)
    inconclusive=len(main)-positive-negative
    lines += ["", f"32个主网格点中，收入区间完全为正 {positive} 个、完全为负 {negative} 个、覆盖零 {inconclusive} 个。不能据此断言全参数的均衡或所有偏离方向。", "",
              "## 源码差分与执行记录", "",
              f"源 commit：`{SOURCE_COMMIT}`。新实验的事前指定首样本抽取 {summary['rust_inputs']} 个输入，与原Rust函数比较全部EpochTerms、bond pairs和7项raw traces；差异数 {summary['rust_failures']}。没有重新运行旧协议测试。", "",
              "执行批次分别为 `python single_hedge_probe.py --samples 512` 和 `python single_hedge_probe.py --samples 2048`，解释器是 `python`。512批次执行27,666次Python epoch，其中27,648次为配对测量、18次为Rust差分所需的Python回放；2048批次执行110,610次，其中110,592次为配对测量、18次为差分回放。110,610是2048单个批次的数量，不是两个批次之和。", "",
              "两批Rust比较都选相同配置的首样本，因此输入完全相同：总共只有18个不同的新实验输入，第二批是工程重放，不增加独立验证证据。2048的前512个MC样本也复用预试，不把两批当独立统计证据。没有早期执行失败或失败后调参。", "",
              f"此次总运行 {summary['epoch_calls']} 次Python epoch，耗时 {summary['elapsed_seconds']:.2f} 秒。命令、每环境进度及异常保存在single_hedge_run.log；本轮异常数 {summary['run_failures']}。", "",
              "## 文件与列说明", "",
              "single_hedge_512.csv／single_hedge_2048.csv按实际运行保留各样本数结果；single_hedge_results.csv是当前采用的完整36行结果；single_hedge_main_table.csv是正文事前选定的8行（h=.1、equal或stake0=.4），不依赖收益符号。single_hedge_summary.json保存配置、计数与差分摘要。single_hedge_fixtures.json保留新差分输入，属于本地计算材料。", "",
              "各指标使用baseline_与hedge_前缀给出样本均值；delta_前缀给出配对变化，_se为标准误，_ci95_low/high为上述逐点区间。positive/negative/zero_income_samples统计单样本收入变化符号。share_actual_validator_pool采用当期实际分红池分母；best_miner_emission_epoch采用固定总epoch分母；validator_pool_epoch记录当期实际分红池。", "",
              "所有策略和h在测量前固定。高斯信号模型、固定softmax策略、一个epoch和合成stake是本实验的范围；一次指定偏离有利可图不等于求得最佳响应，也不构成对如实均衡的检验。MC结果不进入定理凭证。"]
    (ROOT/"single_hedge_results.md").write_text("\n".join(lines)+"\n",encoding="utf-8")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--samples",type=int,default=512)
    args=parser.parse_args()
    started=time.perf_counter();rows=[];fixtures=[]
    jobs=[(11,m,s,"softmax") for m in [2,5,10] for s in [1/11,.1,.25,.4]]
    jobs += [(31,5,s,"softmax") for s in [1/31,.1,.25,.4]]
    jobs += [(11,m,.4,"onehot") for m in [2,5]]
    logpath=ROOT/"single_hedge_run.log"
    with logpath.open("a",encoding="utf-8") as log:
        log.write(json.dumps(dict(event="start",timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),samples=args.samples,seed=SEED,policy="softmax-main-before-results",source_commit=SOURCE_COMMIT))+"\n")
    try:
        for i,(nv,m,s,p) in enumerate(jobs):
            result=run_environment(nv,m,s,p,args.samples,fixtures)
            rows.extend(result)
            progress=dict(event="case",case=i+1,total=len(jobs),n=nv,miners=m,stake=s,policy=p,samples=args.samples,
                          income_deltas=[r["delta_income_epoch"] for r in result],elapsed_seconds=round(time.perf_counter()-started,2))
            print(json.dumps(progress),flush=True)
            with logpath.open("a",encoding="utf-8") as log:log.write(json.dumps(progress)+"\n")
        rust=rust_batch([f["input"] for f in fixtures])
        comparisons=[]
        for fixture,reference in zip(fixtures,rust):
            difference=first_difference(reference,epoch(fixture["input"]))
            comparisons.append({k:v for k,v in fixture.items() if k!="input"}|dict(equal=difference is None,difference=difference))
        failures=[c for c in comparisons if not c["equal"]]
        write_csv(ROOT/f"single_hedge_{args.samples}.csv",rows)
        write_csv(ROOT/"single_hedge_results.csv",rows)
        main_table=[r for r in rows if r["policy"]=="softmax" and r["h"]==.1
                    and (r["stake0_requested"]==.4 or abs(r["stake0_requested"]-1/r["n_validators"])<1e-12)]
        write_csv(ROOT/"single_hedge_main_table.csv",main_table)
        summary=dict(samples=args.samples,main_environments=16,control_environments=2,rows=len(rows),seed=SEED,
                     source_commit=SOURCE_COMMIT,h_values=list(HEDGES),alpha=1,ownership=0,
                     source_path="legacy",temperature=TEMPERATURE,noise_sigma=SIGMA,mean_gap=GAP,noise_corr=0,
                     sample_plan="512 pilot then all 18 environments at 2048; pilot is prefix, not independent evidence; no further significance-based extension",
                     epoch_calls=len(jobs)*args.samples*3+len(fixtures),elapsed_seconds=time.perf_counter()-started,
                     rust_inputs=len(fixtures),rust_failures=len(failures),run_failures=0,
                     pilot_epoch_calls=27666,final_epoch_calls=110610,
                     unique_rust_inputs_across_batches=18,repeated_rust_comparison_is_engineering_replay=True,
                     rust_comparisons=comparisons,claim="fixed-policy paired Monte Carlo, not equilibrium or best response")
        (ROOT/"single_hedge_summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
        (ROOT/"single_hedge_fixtures.json").write_text(json.dumps(fixtures,indent=2)+"\n",encoding="utf-8")
        write_report(rows,summary)
        with logpath.open("a",encoding="utf-8") as log:log.write(json.dumps(dict(event="completed",samples=args.samples,rust_failures=len(failures),elapsed_seconds=summary['elapsed_seconds']))+"\n")
        print(json.dumps({k:v for k,v in summary.items() if k!='rust_comparisons'}),flush=True)
        if failures:raise AssertionError(f"New Rust differences: {failures}")
    except Exception as exc:
        with logpath.open("a",encoding="utf-8") as log:log.write(json.dumps(dict(event="failure",samples=args.samples,error=repr(exc),completed_rows=len(rows)))+"\n")
        if rows:write_csv(ROOT/f"single_hedge_{args.samples}_partial.csv",rows)
        raise


if __name__=="__main__":main()
