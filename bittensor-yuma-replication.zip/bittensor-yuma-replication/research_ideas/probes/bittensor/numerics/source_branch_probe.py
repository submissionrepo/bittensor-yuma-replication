"""Finite integer-weight deviations near the ideal alpha=1 information branch.

This is a diagnostic on a specified finite report grid. It does not establish
best responses over all u16 pairs, or equilibria of the fixed-point protocol.
"""
from pathlib import Path
import csv
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'protocol'))
from python_epoch import epoch
from differential import rust_batch,first_difference


def state(x,ell,k):
    reports=[x]+[65535-ell]*k+[ell]*(2-k)
    return dict(stakes=[1,1,1,0,0],permits=[True]*3+[False]*2,max_validators=3,
                weights_sparse=[[[3,65535-r],[4,r]] for r in reports]+[[],[]],
                moving_average=0,yuma3=False,bonds_penalty=65535,emission=10**12)


def main():
    rows=[];fixtures=[];evaluations=0
    for ell in [0,6554,13107,26214,32112]:
        grid=set(np.rint(np.linspace(0,65535,1025)).astype(int).tolist())
        for endpoint in [ell,65535-ell]:
            grid.update(endpoint+sign*d for sign in [-1,1] for d in [0,1,2,4,16,64]
                        if 0<=endpoint+sign*d<=65535)
        grid=sorted(grid);pay=[];quality_by_profile={}
        for x in grid:
            outcomes=[]
            for k in range(3):
                inp=state(x,ell,k);out=epoch(inp);evaluations+=1
                ts=out['terms'];outcomes.append([ts[0]['validator_emission'],ts[3]['server_emission'],ts[4]['server_emission']])
                if x in [ell,65535-ell]:
                    quality_by_profile[(x,k)]=ts[4]['server_emission']/(ts[3]['server_emission']+ts[4]['server_emission'])
                if x in {ell,min(ell+1,65535)} and k in {0,2}:
                    fixtures.append(dict(input=inp,output=out))
            pay.append(np.asarray(outcomes,dtype=float)/10**12)
        pay=np.asarray(pay);minimum=(float('inf'),None,None,None)
        max_zero_owner_gain=0.
        for signal,prob in [(0,np.array([7,6,3])/16),(1,np.array([3,6,7])/16)]:
            expected=np.einsum('k,rkj->rj',prob,pay)
            honest=grid.index(ell if signal==0 else 65535-ell)
            loss=expected[honest,0]-expected[:,0]
            max_zero_owner_gain=max(max_zero_owner_gain,float(-loss.min()))
            for miner in [0,1]:
                gain=expected[:,1+miner]-expected[honest,1+miner]
                for i in np.flatnonzero(gain>1e-12):
                    ratio=float(loss[i]/gain[i])
                    if ratio<minimum[0]:minimum=(ratio,signal,miner,grid[i])
        # Conditional on theta=1, all signals independently equal 1 with p=.75.
        q=0.
        from math import comb
        for sig in [0,1]:
            for k in range(3):
                prob=(.75 if sig else .25)*comb(2,k)*.75**k*.25**(2-k)
                q+=prob*quality_by_profile[(65535-ell if sig else ell,k)]
        e=ell/65535
        ideal_cap=2*(28*e**2+56*e+1)/(3*(28*e**3+56*e**2+127*e+72))
        ideal_q=.5+.5*(.5-e)*(13/16+9/(16*(1+e)))
        rows.append(dict(ell_units=ell,ell=e,grid_reports=len(grid),ideal_cap=ideal_cap,
                         grid_cap=minimum[0],binding_signal=minimum[1],owned_miner=minimum[2],deviation_units=minimum[3],
                         source_quality=q,ideal_quality=ideal_q,quality_error=q-ideal_q,
                         max_zero_owner_gain=max_zero_owner_gain))
        print(ell,len(grid),'cap',minimum[0],'ideal',ideal_cap,'Q',q,flush=True)
    reference=rust_batch([f['input'] for f in fixtures])
    for i,(f,r) in enumerate(zip(fixtures,reference)):
        assert first_difference(f['output'],r) is None,(i,first_difference(f['output'],r))
    with (ROOT/'source_branch_probe.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (ROOT/'source_branch_probe.json').write_text(json.dumps(dict(
        epochs=evaluations,rust_comparisons=len(fixtures),rows=rows,
        scope='alpha=1 legacy; finite grid of fixed-sum u16 weight pairs; no all-report equilibrium certificate'),indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':main()
