# 理论闭合：新增恒等式与区间代数证书

2026-09-29。只认证下列代数部件，通用机制归约与均衡穷尽仍是研究证明。

- 左、中、右分支导数及右接口导数跳跃：五个恒等式归零。
- 接口跳跃 = `-t*(12*ell**3*w + 18*ell**2*w + 8*ell**2 + 45*ell*w + 34*ell + 12*w + 17)/(18*(ell + 1)**2)`。
- CM_increases: 区间[0,1/2] Bernstein系数 `[7810, 8790, 9798, 10638, 11016]`。
- CL_denominator_positive: 区间[0,1/2] Bernstein系数 `[64, 421/6, 74, 72]`。
- half_minus_CM_numerator: 区间[0,1/2] Bernstein系数 `[212, 1429/6, 269, 315]`。
- CM = `2*(28*ell**2 + 56*ell + 1)/(3*(28*ell**3 + 56*ell**2 + 127*ell + 72))`；CL−CM = `-2*(1568*ell**5 + 7000*ell**4 + 12572*ell**3 + 16742*ell**2 + 14713*ell + 5840)/(3*(28*ell**3 + 28*ell**2 - 37*ell - 64)*(28*ell**3 + 56*ell**2 + 127*ell + 72))`。
- 因而p=3/4时，0≤ell<1/2的完整软报告阈值由CM给出，其端点为1/108与8/51。
- 21个有理条件期望与独立经典Yuma epoch枚举精确相等。
- dominant3 vertex 0: ratio gap=0, Bernstein=[0].
- dominant3 vertex 1: ratio gap=1/4 - t, Bernstein=[1/4, 0].
- dominant3 vertex 2: ratio gap=0, Bernstein=[0].
- dominant3 vertex 3: ratio gap=1/2 - 2*t, Bernstein=[1/2, 0].
- dominant3闭式与9个新容量LP比对通过；此条是浮点一致性探针，不是全称凭证。
