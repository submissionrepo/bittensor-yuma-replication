# Default-alpha Yuma: exact potential certificate

2026-09-30. Rational algebra, no optimizer.

- ell=49/100, alpha=1/10, delta=99/100, p=3/4, V=M=1/2, ownership=0.
- Potential H(D)=1/20 max(|D|-1/20,0). Uniform conditional report margin=1/1000.
- 324 exact rational inequalities, each denominator strictly positive; numerator Bernstein covers have 324 leaves.
- 84 independent exact epoch comparisons, including all three outsider profiles, report boundaries and four bond-difference corners.
- The expectation identities E[v_fresh|signal]=1/3 and E[Delta_1+Delta_0|signal]=2/3 hold exactly.
- Positive information costs eta <= 1/200000; quality Q=241237/476800.

These certificates cover the algebraic Bellman inequalities. The state reduction, convexity in D, and infinite-horizon comparison are supplied by the paper proof and are not established by these algebraic certificates.
