# Default dynamic extensions: exact algebra

2026-09-30.
- 18 rational interval inequalities prove 0 <= dI/dx <= 1 for ell=49/100, all three report branches and outsider counts.
- One strictly positive rational interval certificate proves the right report derivative at the honest limiting maximum D is positive for every 0 < ell <= 2/5.
- Finite ell=2/5 witness: 10 repeated honest report profiles (3/5,2/5,2/5), then signal zero and report 401/1000; conditional full discounted gain=1346965493913734921202558254069/4862851903431954529117440000000000000>0.
- The finite witness is independently replayed with the exact epoch routine and the exact positive-column geometric tail.
- Existing potential extends to ownership omega <= 1/2000, information cost eta <= 1/400000; the normalized report margin is then at least 1/2000.

Only the algebra and finite witness receive an exact/sympy credential; the general finite-history implication and multistage equilibrium proof are in the research note.
