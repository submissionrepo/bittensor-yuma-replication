"""Exact classic-Yuma endpoint probe; fixed future policy, not an equilibrium solver.

Keeps post-EMA column normalization, including zero fresh-bond columns.
Existing positive-column probes and their certificates are not modified.
"""
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path
import sys
import sympy as sp
from static_frontier_probe import primitives
from yuma_dynamic_probe import yuma_profile


def step(stakes, reports, old, alpha, V=F(1, 2)):
    rows = [(x, 1-x) for x in reports]
    caps = [max(x for x in {row[j] for row in rows}
                if sum(s for s, row in zip(stakes, rows) if row[j] >= x) >= F(1, 2))
            for j in (0, 1)]
    clipped = [[min(row[j], caps[j]) for j in (0, 1)] for row in rows]
    rank = [sum(s*row[j] for s, row in zip(stakes, clipped)) for j in (0, 1)]
    inc = [x/sum(rank) for x in rank]
    fresh = [[stakes[i]*clipped[i][j]/rank[j] if rank[j] else F(0)
              for j in (0, 1)] for i in range(len(stakes))]
    bonds = [[(1-alpha)*old[i][j]+alpha*fresh[i][j] for j in (0, 1)]
             for i in range(len(stakes))]
    for j in (0, 1):
        total = sum(row[j] for row in bonds)
        if total:
            for row in bonds:
                row[j] /= total
    pay = [V*sum(row[j]*inc[j] for j in (0, 1)) for row in bonds]
    assert sum(pay) == V
    return inc, pay, bonds


def current_shock(n, p, alpha, signal, report):
    stakes = [F(1, n)]*n
    old = [[s, s] for s in stakes]
    paydiff, allocdiff = F(0), F(0)
    shock = [[F(0), F(0)] for _ in stakes]
    for theta in (0, 1):
        post = p if theta == signal else 1-p
        for tail in product((0, 1), repeat=n-1):
            prob = post
            for s in tail:
                prob *= p if s == theta else 1-p
            ref = step(stakes, [F(signal), *map(F, tail)], old, alpha)
            dev = step(stakes, [report, *map(F, tail)], old, alpha)
            paydiff += prob*(dev[1][0]-ref[1][0])
            allocdiff += prob*(dev[0][0]-ref[0][0])
            for i in range(n):
                for j in (0, 1):
                    shock[i][j] += prob*(dev[2][i][j]-ref[2][i][j])
    return paydiff, allocdiff, shock


def pv(n, p, alpha, discount, signal, report):
    paydiff, allocdiff, shock = current_shock(n, p, alpha, signal, report)
    # IID symmetric future states and extreme, signal-following reports imply
    # each column wins with probability 1/2 independently of the current shock.
    factor = F(1, 2)*discount*(1-alpha)/2/(1-discount*(1-alpha/2))
    return paydiff+factor*sum(shock[0]), allocdiff/2, paydiff, shock


def replay_future(shock, n, p, alpha, discount, steps=4):
    """Independent exact profile enumeration of the linear future transition."""
    old = [[F(1, n), F(1, n)] for _ in range(n)]
    state = shock
    total = F(0)
    for t in range(1, steps+1):
        nxt = [[F(0), F(0)] for _ in range(n)]
        pay = F(0)
        for reports in product((0, 1), repeat=n):
            k = sum(reports)
            prob = (p**k*(1-p)**(n-k)+(1-p)**k*p**(n-k))/2
            ref = step([F(1, n)]*n, list(map(F, reports)), old, alpha)
            changed = [[old[i][j]+state[i][j] for j in (0, 1)] for i in range(n)]
            dev = step([F(1, n)]*n, list(map(F, reports)), changed, alpha)
            pay += prob*(dev[1][0]-ref[1][0])
            for i in range(n):
                for j in (0, 1):
                    nxt[i][j] += prob*(dev[2][i][j]-ref[2][i][j])
        expected = F(1, 2)*(1-alpha)/2*(1-alpha/2)**(t-1)*sum(shock[0])
        assert pay == expected
        total += discount**t*pay
        state = nxt
    return total


def instantaneous_metrics(n, p, ell):
    rows = [yuma_profile(n, k, sp.S.One, sp.Rational(ell)) for k in range(n+1)]
    p = sp.Rational(p)
    quality = sum(comb(n, k)*p**k*(1-p)**(n-k)*rows[k][0] for k in range(n+1))
    influence = sum(comb(n-1, k)*p**k*(1-p)**(n-1-k)*(rows[k+1][0]-rows[k][0])
                    for k in range(n))
    noinfo = sum(sp.Rational(1, 2)*comb(n-1, k)
                 *(p**k*(1-p)**(n-1-k)+(1-p)**k*p**(n-1-k))*rows[k+1][2]
                 for k in range(n))
    rent = sp.Rational(1, 2*n)-noinfo
    return tuple(map(sp.cancel, (quality, rent, influence, 4*rent/influence)))


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    lines = ['# Yuma 极端报告、零列与耐心收益', '',
             '2026-09-29。研究探针；经典 Yuma、beta=1、理想有理数算术、固定 stake，无重新注册。旧探针及旧凭证保持不变。', '',
             '源码：[run_epoch.rs c004cebf](https://github.com/opentensor/subtensor/blob/c004cebf/pallets/subtensor/src/epoch/run_epoch.rs)，dense 363–379、sparse 850–869：新 bonds 列归一化，EMA 后再次列归一化。两种实现都有这一步。', '',
             '## 1. 即时结算 alpha=1 的十二组端点与软报告扫描', '',
             '这是静态结算机制，也是“新 bonds 全额按本轮 incentive 支付”的反事实核算；不能自动等同于实际 alpha<1 的 delta→1。每组扫描 ell∈{0,1/100,1/20,1/5,2/5}；只检查这两种信号报告之间的个体 IC。', '',
             '| n | p | Q(ell=0) | K | omega_Y/K | 所有 ell>0 同时严格降低 Q 与 omega_Y |',
             '|---:|---:|---:|---:|---:|---|']
    for n in (3, 5, 7, 9):
        for p in (F(3, 5), F(3, 4), F(9, 10)):
            A, b, G, K = primitives(n, sp.Rational(p))
            Q, rent, H, omega = instantaneous_metrics(n, p, F(0))
            assert (Q, rent, H, omega) == (A, G, b, K)
            softer = [instantaneous_metrics(n, p, ell) for ell in (F(1,100), F(1,20), F(1,5), F(2,5))]
            strict = all(row[0] < Q and row[3] < omega for row in softer)
            assert strict
            lines.append(f'| {n} | {p} | {Q} | {K} | {omega/K} | {strict} |')
    lines += ['', '## 2. 真正的动态一次偏离', '',
              'n=3，p=3/4，alpha=1/10，delta=99/100，rho=0，V=M=1/2，初始两列 B_i,j=1/3。其他人当前报极端信号；此后所有人每期恢复极端信号报告。当前已获得信号 0，比较报告 x 与真实 x=0；成本相同，持股为零。', '',
              '极端报告下，每期只有赢家列更新。alpha<1 时零新列经 EMA 再归一化回原列，所以输家列不衰减。IID 状态使每列下一期以 1/2 概率赢。若当前报告后的焦点 bonds 差为 d_j，则未来期 t≥1 的期望支付差为 V(1-alpha)/2 · (1-alpha/2)^(t-1) · sum_j d_j。', '',
              '折现未来和 = V delta(1-alpha) / [2(1-delta(1-alpha/2))] · sum_j d_j。当前实际支付差另加。下面数值全是有理数，非浮点搜索。', '',
              '| 偏离 x | 当前验证收益差 | 完整折现验证收益差 | miner 1 收益差 |',
              '|---:|---:|---:|---:|']
    selected = None
    for report in (F(0), F(1,10000), F(1,100), F(1,20), F(1,10), F(1,4), F(1,2), F(3,4), F(1)):
        ans = pv(3, F(3,4), F(1,10), F(99,100), 0, report)
        lines.append(f'| {report} | {ans[2]} | {ans[0]} ({float(ans[0]):.10f}) | {ans[1]} |')
        if report == F(1,100):
            selected = ans
    assert selected[0] > 0
    replay_future(selected[3], 3, F(3,4), F(1,10), F(99,100))
    # Independent symbolic profile calculation for n=3 and 0<x<1.
    x, a, d, v = sp.symbols('x a d v', positive=True)
    # Conditional outsider counts L=0,1,2 have probabilities 7/16,6/16,3/16.
    delta0 = (1-x)/(3-x)-sp.Rational(1,3)
    delta1 = x/(2+x)
    current = v*a*(sp.Rational(7,16)*delta0+sp.Rational(3,16)*delta1)
    shock = a*(sp.Rational(7,16)*delta0+sp.Rational(3,16)*delta1+sp.Rational(1,16))
    formula = sp.factor(current+v*d*(1-a)/(2*(1-d*(1-a/2)))*shock)
    instance = formula.subs({x:sp.Rational(1,100),a:sp.Rational(1,10),d:sp.Rational(99,100),v:sp.Rational(1,2)})
    assert instance == sp.Rational(selected[0])
    limit_x = sp.factor(sp.limit(formula, x, 0, dir='+'))
    patient_limit = sp.factor(sp.limit(limit_x, d, 1, dir='-'))
    assert sp.cancel(patient_limit-v*(1-a)/16) == 0
    # The four-step replay has an exactly summable geometric remainder.
    partial = replay_future(selected[3], 3, F(3,4), F(1,10), F(99,100))
    z = F(99,100)*(1-F(1,10)/2)
    factor = F(1,2)*F(99,100)*(1-F(1,10))/2/(1-z)
    assert partial+factor*sum(selected[3][0])*z**4 == selected[0]-selected[2]
    lines += ['', '## 3. 端点不连续的来源', '',
              '当其余两人信号一正一负时，x=0 只刷新 miner 0 的 bonds；任意 0<x<1 都刷新两列，焦点在每列的新份额均为 1/2。在初始 1/3 下，它以趋近于零的当期分配代价，在另一列获得正的未来债券收益。这个事件条件概率为 3/8。', '',
              f'对 0<x<1 的独立 SymPy 表达式为 `{formula}`，其中 a=alpha,d=delta,v=V；x→0+ 后得到 `{limit_x}`；再令 delta→1 得 `{patient_limit}`。V=1/2、alpha=1/10 时为 9/320。', '',
              f'具体有限参数反例 x=1/100 的净增益为 {selected[0]}，约 {float(selected[0]):.10f}。四步完整未来 profile 枚举及精确几何尾项与闭式一致。', '',
              '因此“alpha<1 下，极端信号报告在零持股时就是动态均衡”在此初始状态、IID 质量与指定继续策略下不成立。这里只否定该候选策略；不排除其他 bonds 状态、历史依赖策略或其他均衡。', '',
              '## 4. 对原记录的影响', '',
              '静态类、G*、K、T_static 和旧证书不变。alpha=1、极端报告时的静态等价成立；一般 n 的路径级理由是赢家获得全部矿工预算，赢家报告者均分验证预算。§11 原公式要求正列，其既有适用域不变；它不能直接取 ell=0，因为每期更新的列集合改变。delta→1 是折现收益差的极限，不把 delta=1 的无穷收入当作有限效用。', '',
              '“Yuma 悬崖”先保留为限定二元动作与结算口径的静态候选；完整动态连续报告版本需要先求 IC/均衡。未作链上固定点一致性、最小权重约束或 liquid-alpha/Yuma3 的结论。', '']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines), encoding='utf-8')
    print('12 exact endpoint identities, 48 soft-report comparisons; dynamic gain:', selected[0], float(selected[0]))
    print('Independent symbolic payoff and 4-period profile recurrence with exact geometric tail agree.')


if __name__ == '__main__':
    main()
