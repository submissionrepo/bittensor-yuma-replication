"""Exact algebra supporting the new Yuma and dominant-stake derivations.

These checks credential the stated identities and polynomial inequalities,
not the economic reductions or completeness of the equilibrium arguments.
"""
from itertools import product
from fractions import Fraction as F
from pathlib import Path
import sys
import sympy as sp
from yuma_continuous_theory import t,e,x,w,vL,vM,vR,iL,iM,iR,capM
from yuma_endpoint_probe import step
from rent_capacity_probe import reduced_design

R=sp.Rational


def bernstein_nonnegative(expr,var,lo,hi):
    z=sp.symbols('z')
    poly=sp.Poly(sp.expand(expr.subs(var,lo+(hi-lo)*z)),z)
    degree=poly.degree()
    coeff=[sum(poly.nth(j)*R(sp.binomial(k,j),sp.binomial(degree,j)) for j in range(k+1)) for k in range(degree+1)]
    assert all(c>=0 for c in coeff),(expr,coeff)
    return coeff


def check_soft_profiles():
    checked=0
    for p,ell in ((F(3,5),F(1,10)),(F(3,4),F(1,4)),(F(9,10),F(2,5))):
        for report in (F(0),ell/2,ell,F(1,2),1-ell,1-ell/2,F(1)):
            payoff=F(0);alloc=F(0)
            for theta in (0,1):
                post=p if theta==0 else 1-p
                one=p if theta else 1-p
                for tail in product((0,1),repeat=2):
                    prob=post
                    for bit in tail:prob*=one if bit else 1-one
                    reports=[report]+[1-ell if bit else ell for bit in tail]
                    aa,pp,_=step([F(1,3)]*3,reports,[[F(1,3)]*2 for _ in range(3)],F(1))
                    payoff+=prob*pp[0];alloc+=prob*aa[0]
            branch=(vL,iL) if report<=ell else (vM,iM) if report<=1-ell else (vR,iR)
            sub={t:R(p*(1-p)),e:R(ell),x:R(report)}
            assert sp.cancel(branch[0].subs(sub)/2-R(payoff))==0
            assert sp.cancel(branch[1].subs(sub)-R(alloc))==0
            checked+=1
    return checked


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    lines=['# 理论闭合：新增恒等式与区间代数证书','',
           '2026-09-29。只认证下列代数部件，通用机制归约与均衡穷尽仍是研究证明。','']
    a=1-3*t
    dL=sp.diff(vL-w*iL,x)
    assert sp.cancel(dL-a*(2-3*w*(1-e))/(3-e+x)**2-t*(4*(1+e)-w*(4+e))/(2+e+x)**2)==0
    dM=sp.diff(vM+w*iM,x)
    assert sp.cancel(dM-a*(-2+3*w*e)/(3-x+e)**2-t*(2+3*w*e)/(2+e+x)**2-2*w*t/(1+e))==0
    C=a*(-2+3*w*e)+2*t*(-(1+2*e)+w*(2-e))
    D=t*(-2+3*w*(1-e))
    assert sp.cancel(sp.diff(vR+w*iR,x)-C/(3-x+e)**2-D/(4-e-x)**2)==0
    assert sp.cancel(C.subs(w,1)+(1-4*t)*(2-3*e)+3*t*e)==0
    jump=sp.factor((sp.diff(vR+w*iR,x)-sp.diff(vM+w*iM,x)).subs(x,1-e))
    assert sp.cancel(jump+t*(12*e**3*w+18*e**2*w+8*e**2+45*e*w+34*e+12*w+17)/(18*(e+1)**2))==0
    lines += ['- 左、中、右分支导数及右接口导数跳跃：五个恒等式归零。',f'- 接口跳跃 = `{jump}`。']
    capL=sp.factor(sp.diff(vL,x).subs(x,e)/sp.diff(iL,x).subs(x,e))
    cm=sp.factor(capM.subs(t,R(3,16)));cl=sp.factor(capL.subs(t,R(3,16)))
    checks={'CM_increases':sp.fraction(sp.factor(sp.diff(cm,e)))[0],
            'CL_denominator_positive':-(28*e**3+28*e**2-37*e-64),
            'half_minus_CM_numerator':84*e**3+56*e**2+157*e+212}
    for name,poly in checks.items():
        coeff=bernstein_nonnegative(poly,e,R(0),R(1,2))
        lines.append(f'- {name}: 区间[0,1/2] Bernstein系数 `{coeff}`。')
    assert cm.subs(e,0)==R(1,108) and cm.subs(e,R(1,2))==R(8,51)
    # CL-CM has a positive numerator and two already controlled denominators.
    delta=sp.factor(cl-cm)
    positive_num=1568*e**5+7000*e**4+12572*e**3+16742*e**2+14713*e+5840
    assert sp.cancel(delta+2*positive_num/(3*(28*e**3+28*e**2-37*e-64)*(28*e**3+56*e**2+127*e+72)))==0
    lines += [f'- CM = `{cm}`；CL−CM = `{delta}`。','- 因而p=3/4时，0≤ell<1/2的完整软报告阈值由CM给出，其端点为1/108与8/51。']
    count=check_soft_profiles();lines.append(f'- {count}个有理条件期望与独立经典Yuma epoch枚举精确相等。')
    # Dominant validator n=3: compare all score-monotone threshold vertices.
    vertices=[(R(0),R(0)),(R(1,2),R(1)),((1+t)/2,R(1,2)+3*t),((1-t)/2,R(3,2)-3*t)]
    for j,(q,h) in enumerate(vertices):
        gap=sp.expand((1+t)*h/2-q*(R(1,2)+3*t))
        coeff=bernstein_nonnegative(gap,t,R(0),R(1,4)) if gap!=0 else [0]
        lines.append(f'- dominant3 vertex {j}: ratio gap={gap}, Bernstein={coeff}.')
    for p in (F(3,5),F(3,4),F(9,10)):
        for omega in (F(1,10),F(1,2),F(1)):
            pp=R(p);om=R(omega);tt=pp*(1-pp);dd=2*pp-1
            A=R(1,2)+dd*(1+tt)/2;K=dd**2/(R(1,2)+3*tt)
            formula=R(1,2)+(A-R(1,2))*min(1,K/om)
            got,_=reduced_design((F(3,5),F(1,5),F(1,5)),p,omega)
            assert abs(got-float(formula))<1e-9
    lines += ['- dominant3闭式与9个新容量LP比对通过；此条是浮点一致性探针，不是全称凭证。','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print('soft derivative identities, interval Bernstein certificates,',count,'exact profiles; dominant3 ratio identities and 9 new LP matches.')


if __name__=='__main__':main()
