# bonds 动态恒报均衡：任意多期偏离的势函数证书

2026-09-29。条件：n>=3等stake，经典Yuma，0<alpha<=1，delta<1，初始每列bond=1/n，其他人永远报1/2。

取r=1-alpha、u=h/[2(n-h)]∈[0,1/(4n-2)]、c=4(n-1)/n；偏好miner相反一列的bond缺口为D。
缺口下一期D_next=rD+alpha*c*u/(1-2u)。当前偏离收益g=(beta*M-alpha*V*c/2)u - V*r*D(1/2-u)。
取势函数Phi(D)=-kD，k=V*r*(1/2-1/(4n-2))/(1-delta*r)。

- ownership money cap = `2*V*alpha*(n - 1)*(alpha*delta - delta + 2*n - 1)/(n*(2*n - 1)*(alpha*delta - delta + 1))`.
- 精确恒等式：g+delta Phi(D_next)-Phi(D) = -V*r*D*(u_max-u) -(cap-beta*M)*u -2*delta*alpha*k*c*u^2/(1-2u)。
- 在全部声明域上右侧逐项非正；有界势函数的折现末项趋于0，所以任意长、随机、历史依赖偏离的总收益不正。
- n3,alpha1/10,delta99/100,V=M时，持股上限证书为8218/8175>1；覆盖全部omega∈[0,1]。
- 该参数下覆盖omega=1所需delta>=650/657。

另有256条三期有理报告路径与实际epoch精确回放：把每次偏离反射到持有miner方向，保留两列bond缺口之和并逐期弱增收益。有限回放不代替一般反射归约，通用结论见研究证明。
