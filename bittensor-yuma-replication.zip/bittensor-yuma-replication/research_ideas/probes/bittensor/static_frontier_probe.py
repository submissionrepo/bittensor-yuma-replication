"""First-layer discovery and exact finite replay of the static frontier.

No finite run certifies the arbitrary-n argument in the research notes.
"""
from math import comb
from pathlib import Path
import sys

import sympy as sp
from binary_mechanism_lp import build

R = sp.Rational


def primitives(n, p, V=R(1, 2), M=R(1, 2)):
    p = R(p)
    q = 1-p
    m = (n-1)//2
    A = sum(R(comb(n, k))*p**k*q**(n-k) for k in range(m+1, n+1))
    b = R(comb(n-1, m))*(p*q)**m
    G = sp.cancel(V*(2*p-1)*(A-p)/(2*n*p*q))
    K = sp.cancel(2*G/(M*b))
    return A, b, G, K


def candidate(model, eta):
    n, p, w = model.n, model.precision, model.ownership
    A, b, G, K = primitives(n, p)
    lam = sp.S.One if not w else min(sp.S.One, 4*(G-eta)/(w*b))
    values = {}
    for k in range(n+1):
        values[f'a_{k}'] = (1 + (1 if k > n//2 else -1)*lam)/2
        if k < n:
            values[f'v0_{k}'] = R(1, 2*(n-k)) if k <= n//2 else sp.S.Zero
        if k:
            values[f'v1_{k}'] = R(1, 2*k) if k > n//2 else sp.S.Zero
    values['eta'] = eta
    return [values[name] for name in model.names], R(1, 2)+(A-R(1, 2))*lam


def exact_feasible(model, x):
    for row, rhs in zip(model.eq, model.eq_rhs):
        assert sum(a*b for a, b in zip(row, x)) == rhs
    for row, rhs in zip(model.ub, model.ub_rhs):
        assert sum(a*b for a, b in zip(row, x)) <= rhs
    for v, (lo, hi) in zip(x, model.bounds):
        assert lo <= v <= hi


def lift_dual(model, eta=0):
    """Lift the solver's nonzero support by exact linear algebra.

    Independent rational approximation of each multiplier need not satisfy
    stationarity, even when every approximation is close. Solve it exactly.
    """
    result = model.solve(cost=eta)
    x, qstar = candidate(model, eta)
    exact_feasible(model, x)
    count = len(x)
    bounds = list(model.bounds)
    bounds[-1] = (R(eta),R(eta))
    columns = [sp.Matrix(row) for row in model.eq + model.ub]
    columns += [sp.eye(count)[:,j] for j in range(count)]*2
    raw = list(result['dual_eq'])+list(result['dual_ub'])+list(result['dual_lower'])+list(result['dual_upper'])
    support = [i for i,y in enumerate(raw) if abs(y)>1e-10]
    mat = sp.Matrix.hstack(*(columns[i] for i in support))
    _, pivots = mat.rref()
    ys = sp.Matrix([R(str(float(raw[i]))).limit_denominator(1000000) for i in support])
    c = sp.Matrix([-v for v in model.quality])
    correction = mat[:,list(pivots)].gauss_jordan_solve(c-mat*ys)[0]
    for j,z in zip(pivots,correction):
        ys[j] += z
    assert mat*ys == c
    dual = [sp.S.Zero]*len(raw)
    for j,y in zip(support,ys):
        dual[j] = y
    ne,nu = len(model.eq),len(model.ub)
    yeq,yub = dual[:ne],dual[ne:ne+nu]
    yl,yu = dual[ne+nu:ne+nu+count],dual[ne+nu+count:]
    assert all(y<=0 for y in yub+yu)
    assert all(y>=0 for y in yl)
    rhs = model.eq_rhs+model.ub_rhs+[lo for lo,hi in bounds]+[hi for lo,hi in bounds]
    primal = sum(c[j]*x[j] for j in range(count))
    dual_obj = sum(a*b for a,b in zip(rhs,dual))
    assert primal == dual_obj
    return dict(quality=qstar, primal=primal, dual=dual_obj, x=x, yeq=yeq, yub=yub, yl=yl, yu=yu)


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    lines = ['# 静态闭式边界：扩展参数探针', '',
             '2026-09-29。研究计算记录。浮点最优值用于发现；有理可行性与固定点原始/对偶证书仅覆盖明确的有限实例。', '',
             '候选公式：Q*=1/2+(A-1/2) min{1, 4(G-eta)/(omega b)}；omega=0 时取多数准确率 A。',
             'A=Pr[Bin(n,p)>n/2]；b=C(n-1,(n-1)/2)[p(1-p)]^((n-1)/2)；G=(2p-1)(A-p)/(4 n p(1-p))；K=4G/b。', '',
             '| n | p | A | G | K | 最大 LP 偏差（8 点） |',
             '|---:|---:|---:|---:|---:|---:|']
    runs = 0
    for n in (3, 5, 7, 9, 11):
        for p in (R(11,20), R(3,5), R(2,3), R(3,4), R(4,5), R(9,10)):
            A,b,G,K = primitives(n,p)
            worst = 0.0
            for w in (R(1,20),R(1,4),R(1,2),R(1)):
                model = build(n,p,w)
                for eta in (sp.S.Zero,G/4):
                    x,qstar = candidate(model,eta)
                    exact_feasible(model,x)
                    result = model.solve(cost=eta)
                    assert result['success'], (n,p,w,eta,result)
                    err = abs(result['quality']-float(qstar))
                    assert err < 2e-7, (n,p,w,eta,result['quality'],qstar)
                    worst = max(worst,err)
                    runs += 1
            lines.append(f'| {n} | {p} | {A} | {G} | {K} | {worst:.3g} |')
        print(f'n={n}: completed; cumulative LPs={runs}',flush=True)
    lines += ['', '所有 240 点：omega∈{1/20,1/4,1/2,1}，eta∈{0,G/4}。候选解的全部原模型约束均用有理数精确回代。', '',
              '## 新增固定点的最优性证书', '',
              '下列点另对 LP 返回的原始解与对偶乘子作有理重构，检查可行性、符号、stationarity 和零目标差。旧三点证书不重复运行。', '']
    lines += ['初次运行的 240 点均匹配，但逐个乘子限制分母到 10^6 的旧重构方法在 n=5,p=3/5,omega=1 产生 stationarity 残差 -1/78635475000；没有发出通过凭证。现按同一浮点解的非零对偶支持精确解线性方程，并完整重查所有符号与目标差。数学命题和原 LP 未改。', '']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    for n,p,w in ((5,R(3,5),R(1)),(5,R(3,4),R(1)),(7,R(2,3),R(1,2)),(9,R(3,4),R(1))):
        model = build(n,p,w)
        result = lift_dual(model)
        lines.append(f'- n={n}, p={p}, omega={w}: {result}.')
    lines += ['', '## 拒绝过度外推', '',
              '这批计算没有覆盖 n→∞、连续 p、非单调分配、异质信号或 coalition。一般证明与假设范围见 ../../bittensor_theory_20260929.md。', '']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print(f'Finished {runs} LP comparisons, {runs} exact feasible constructions, four new exact LP certificates.')


if __name__ == '__main__':
    main()
