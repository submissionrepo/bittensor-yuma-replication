"""New arbitrary-odd-n Markov frontier probes after the n=3 discovery."""
from pathlib import Path
from math import comb
import json
import sys
import sympy as sp
from dynamic_memoryless_probe import model
from static_frontier_probe import primitives

R=sp.Rational


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    rows=[]
    for n in (5,7,9):
        for p in (R(3,5),R(3,4),R(9,10)):
            A,b,G,K=primitives(n,p)
            for fraction in (R(1,3),R(4,5)):
                P=R(1,2)+fraction*(p-R(1,2))
                rent=2*(p-P)*G/(2*p-1)
                eta=rent/3
                for omega in (R(1,10),R(1)):
                    ans=model(n,p,omega,P).solve(cost=eta)
                    expected=R(1,2)+(A-R(1,2))*min(1,(rent-eta)/(omega*R(1,2)*b*(p-(2*p-1)*P)))
                    assert ans['success'],(n,p,P,ans)
                    error=abs(ans['quality']-float(expected))
                    assert error<2e-9,(n,p,P,ans['quality'],expected)
                    rows.append(dict(n=n,p=str(p),endpoint=str(P),omega=str(omega),
                                     eta=str(eta),quality=ans['quality'],formula=str(expected),error=error))
    p,P=sp.symbols('p P',real=True);q=1-p
    identities=0
    for n in (3,5,7,9):
        for j in range(n+1):
            # Exact count symmetry of the influence increment probabilities.
            if j<n:
                hp=sp.binomial(n-1,j)*p**j*q**(n-1-j)
                hq=sp.binomial(n-1,n-1-j)*q**(n-1-j)*p**j
                assert sp.expand(hp-hq)==0
                identities+=1
            if j>0:
                conditional=sp.binomial(n-1,j-1)*(p**j*q**(n-j)+q**j*p**(n-j))
                symmetric_count=sp.binomial(n,j)*(p**j*q**(n-j)+q**j*p**(n-j))/2
                assert sp.expand(conditional-R(2*j,n)*symmetric_count)==0
                identities+=1
        h=p**(n+1)/(p**(n+1)+q**(n+1))
        critical=(2*p-1)*(p**(n+1)+q**(n+1))/(p**(n+1)-q**(n+1))
        assert sp.factor((1-critical)/2+critical*h-p)==0
        identities+=1
    Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    lines=['# 任意奇数 n 的动态闭式：扩展探针','',
           '2026-09-30。三人发现后，新增n=5,7,9环境，不重复旧96个LP。','',
           f'- {len(rows)}个新LP与一般闭式一致，最大浮点差{max(row["error"] for row in rows):.3g}；仅作发现。',
           f'- {identities}个符号恒等式：条件支付计数系数、镜像影响力概率、一般持续性临界点代入。',
           '- 一般归约：W1(p)=V/n，故V/n-W1(P)=2(p-P)G/d；恒报1的分配优势=(p-dP)H。',
           '- 将G<=G*、Q-1/2<=(A-1/2)H/b接入，得到完整动态闭式与压扁多数达到。',
           '- 一般临界持续性rho_c(n,p)=d(p^(n+1)+q^(n+1))/(p^(n+1)-q^(n+1))。','',
           '有限符号检查不替代一般计数组合恒等式和全历史均衡推导；证明在动态研究MD。','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print(f'{len(rows)} new floating LP matches; {identities} symbolic identities.')


if __name__=='__main__':main()
