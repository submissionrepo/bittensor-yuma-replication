"""Heterogeneous stake: exact Yuma rents and a weighted-score design LP.

The LP is a new restricted mechanism class, not a replacement for A_static.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import sys
import numpy as np
from scipy.optimize import linprog


def probability(bits, p, theta):
    return (p if theta else 1-p)**sum(bits)*(1-p if theta else p)**(len(bits)-sum(bits))


def yuma_binary(stakes, bits, V=F(1,2)):
    one = sum(s*r for s, r in zip(stakes, bits))
    assert one != F(1,2), 'This probe excludes exact stake ties.'
    winner = int(one > F(1,2))
    weight = one if winner else 1-one
    return F(winner), [V*s/weight if r == winner else F(0) for s,r in zip(stakes,bits)]


def metrics(stakes, p, V=F(1,2), M=F(1,2)):
    n = len(stakes)
    profiles = list(product((0,1), repeat=n))
    outcomes = {r:yuma_binary(stakes,r,V) for r in profiles}
    quality = sum(probability(r,p,1)*outcomes[r][0] for r in profiles)
    rents, pivotal, thresholds = [], [], []
    for i in range(n):
        truth = sum((probability(r,p,1)+probability(r,p,0))/2*outcomes[r][1][i] for r in profiles)
        constant, influence = F(0), F(0)
        for others in product((0,1), repeat=n-1):
            low = others[:i]+(0,)+others[i:]
            high = others[:i]+(1,)+others[i:]
            constant += (probability(others,p,1)+probability(others,p,0))/2*outcomes[low][1][i]
            influence += probability(others,p,1)*(outcomes[high][0]-outcomes[low][0])
        rent = truth-constant
        rents.append(rent); pivotal.append(influence)
        thresholds.append(2*rent/(M*influence) if influence else None)
        # Independent conditional reporting margin replay: at beta=0 it is 2G_i.
        for signal in (0,1):
            gap = F(0)
            for theta in (0,1):
                post = p if theta == signal else 1-p
                for others in product((0,1), repeat=n-1):
                    r0 = others[:i]+(signal,)+others[i:]
                    r1 = others[:i]+(1-signal,)+others[i:]
                    gap += post*probability(others,p,theta)*(outcomes[r0][1][i]-outcomes[r1][1][i])
            assert gap == 2*rent
    return quality, rents, pivotal, thresholds


def design(stakes,p,omega,eta=F(0),V=F(1,2),M=F(1,2)):
    """Allocation monotone in total reported stake; arbitrary label-symmetric payments."""
    n=len(stakes); profiles=list(product((0,1),repeat=n)); N=len(profiles)
    pos={r:k for k,r in enumerate(profiles)}; size=(n+1)*N
    eq=[]; beq=[]; ub=[]; bub=[]
    blank=lambda:np.zeros(size)
    for k,r in enumerate(profiles):
        comp=pos[tuple(1-x for x in r)]
        row=blank()
        for i in range(n):row[N+i*N+k]=1
        eq.append(row);beq.append(float(V))
        if k<comp:
            row=blank();row[k]=row[comp]=1;eq.append(row);beq.append(1)
            for i in range(n):
                row=blank();row[N+i*N+k]=1;row[N+i*N+comp]=-1
                eq.append(row);beq.append(0)
    ordered=sorted(range(N),key=lambda k:sum(s*r for s,r in zip(stakes,profiles[k])))
    for low,high in zip(ordered,ordered[1:]):
        row=blank();row[low]=1;row[high]=-1
        if sum(s*r for s,r in zip(stakes,profiles[low]))==sum(s*r for s,r in zip(stakes,profiles[high])):
            eq.append(row);beq.append(0)
        else:ub.append(row);bub.append(0)
    for i in range(n):
        row=blank()
        for k,r in enumerate(profiles):
            row[N+i*N+k]-=float((probability(r,p,1)+probability(r,p,0))/2)
        for others in product((0,1),repeat=n-1):
            lo=pos[others[:i]+(0,)+others[i:]];hi=pos[others[:i]+(1,)+others[i:]]
            row[N+i*N+lo]+=float((probability(others,p,1)+probability(others,p,0))/2)
            coef=float(omega*M*probability(others,p,1)/2)
            row[hi]+=coef;row[lo]-=coef
        ub.append(row);bub.append(-float(eta))
    obj=blank()
    for k,r in enumerate(profiles):obj[k]=-float((probability(r,p,1)-probability(r,p,0))/2)
    ans=linprog(obj,A_eq=eq,b_eq=beq,A_ub=ub,b_ub=bub,
                bounds=[(0,1)]*N+[(0,float(V))]*(n*N),method='highs')
    assert ans.success,ans.message
    return .5-ans.fun


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    cases=[(F(1,3),)*3,(F(49,100),F(26,100),F(1,4)),(F(3,5),F(1,5),F(1,5)),
           (F(1,5),)*5,(F(2,5),F(3,20),F(3,20),F(3,20),F(3,20)),
           (F(3,5),F(1,10),F(1,10),F(1,10),F(1,10))]
    lines=['# 任意 stake 向量的第一层探针','',
           '2026-09-29。等 stake 原定理不变。这里先区分两件事：固定加权多数+胜方按 stake 分红的精确 IC，以及分配须按总报告 stake 单调的新设计类。后者允许重设计支付，浮点 LP 仅用于发现。','',
           'p=3/4，V=M=1/2，eta=0。精确 stake 平局暂不纳入本探针；解析扩展须指定标签对称的平局随机化。','',
           '| stake 向量 | 加权多数准确率 | 各人的 G_i | 各人的 b_i | 各人的 2G_i/(M b_i) |',
           '|---|---:|---|---|---|']
    exact=[]
    for stakes in cases:
        row=metrics(stakes,F(3,4));exact.append(row)
        lines.append('| '+str(tuple(map(str,stakes)))+' | '+' | '.join(str(x) for x in row)+' |')
    assert exact[0][1]==[F(1,48)]*3
    assert exact[2][1][0]<0
    lines += ['', 'b_i=0 的 None 只表示无所有权分配约束；仍须检查 G_i>=eta_i。负 G_i 表示零持股、零评估成本下也没有信号跟随激励，不能把负数截为零后宣称可行。','',
              '## 加权分数单调的设计 LP（发现）','',
              '每个二元 profile 一份分配和 n 份支付；非负逐 profile 预算、标签对称、同总 stake 同分配、总 stake 增加分配不下降；逐个 validator 施加 G_i>=eta_i+omega M H_i/2。没有把 stake 误当信号准确率，也没有强加验证收益按 stake 分配。','',
              '| stake 向量 | omega=0 最大 Q | omega=1/4 最大 Q | omega=1 最大 Q |',
              '|---|---:|---:|---:|']
    for stakes in cases:
        values=[design(stakes,F(3,4),w) for w in (F(0),F(1,4),F(1))]
        lines.append('| '+str(tuple(map(str,stakes)))+' | '+' | '.join(f'{v:.10f}' for v in values)+' |')
    lines += ['', '等 stake 的 LP 是原类的非匿名扩写；可用对称化恢复原结果。异质 stake 的数值是新类的候选最优值，未发最优性凭证。','',
              '大户不只通过 pivotality 起作用。支付中的胜方总 stake 分母会同时改变信息租金。n=3 且 stake=(3/5,1/5,1/5) 时大户决定赢家，它偏好少人同报来少分摊验证预算，G_1<0。该事实针对固定 Yuma 支付，不能外推为所有异质 stake 机制不可能。','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print('6 rational weighted-Yuma profiles sets; all 2n conditional reporting margins replayed. 18 new design LPs.')
    print('Dictator case:',exact[2])


if __name__=='__main__':main()
