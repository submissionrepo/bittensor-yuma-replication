"""Continuous-report Yuma: discover active deviations before general proofs."""
from math import comb
from pathlib import Path
import sys
import numpy as np
import sympy as sp
from yuma_endpoint_probe import current_shock,F

R=sp.Rational
t,e,x,w=sp.symbols('t ell x w',real=True)
a=1-3*t
vL=a*(1-e+x)/(3-e+x)+t*(2-e+3*x)/(2+e+x)
iL=a*(x+2*e)/(3-e+x)+t*(2+2*e+3*x)/(2+e+x)
vM=a*(1-x+e)/(3-x+e)+t*(e+x)/(2+e+x)+t/(1+e)
iM=3*a*e/(3-x+e)+t*(1-3*e/(2+e+x))+t*(e+2*x)/(1+e)
vR=(a*(1-x+e)+2*t*(2-e-x))/(3-x+e)+t*(2-e-x)/(4-e-x)
iR=(3*a*e+2*t*(2-e))/(3-x+e)+3*t*(1-e)/(4-e-x)
vtrue=sp.factor(vM.subs(x,e));itrue=sp.factor(iM.subs(x,e))
capM=sp.factor(-sp.diff(vM,x).subs(x,e)/sp.diff(iM,x).subs(x,e))


def general_s(n,p):
    m=n//2
    weights=[R(comb(n-1,k))*(p**(n-k)*(1-p)**k+(1-p)**(n-k)*p**k) for k in range(n)]
    b=R(comb(n-1,m))*(p*(1-p))**m
    S=sum(weights[k]*R(n-k-1,(n-k)**2) for k in range(m))-sum(weights[k]/k for k in range(m+1,n))
    return sp.factor(S),b


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    lines=['# 连续报告的 Yuma 新探针','',
           '2026-09-29。alpha=1、V=M=1/2 的经典实数路径，先做结构发现；t=p(1-p)，ell 为真实信号0对应报告。其余人对应报告ell或1-ell。w=omega M/V。','',
           '## 极端报告的完整连续偏离','',
           '对信号0、其他人极端报告，条件报告增益 F(x) 满足 F(0)=0 且 F严格凹；当前推导候选为连续IC当且仅当 V S_n(p)>=omega M b_n，其中 S_n 为原点负导数。', '',
           '| n | p | S_n/b_n（V=M） | 代表性连续偏离的验证增益 |','|---:|---:|---:|---:|']
    for n in (3,5,7,9):
        for p in (R(3,5),R(3,4),R(9,10)):
            S,b=general_s(n,p)
            gain=current_shock(n,F(p),F(1),0,F(1,100))[0]
            lines.append(f'| {n} | {p} | {S/b} | {gain} |')
    p=sp.symbols('p',real=True)
    S,b=general_s(3,p)
    assert sp.cancel(S/b-(4-21*p*(1-p))/(36*p*(1-p)))==0
    assert sp.factor((vM-vtrue).subs(e,0)/x).subs(t,R(3,16)).subs(x,R(1,100))*R(1,2)==sp.Rational(current_shock(3,F(3,4),F(1),0,F(1,100))[0])/R(1,100)
    # Check continuity between the three expression branches.
    for uL,uM,uR in ((vL,vM,vR),(iL,iM,iR)):
        assert sp.cancel((uL-uM).subs(x,e))==0
        assert sp.cancel((uM-uR).subs(x,1-e))==0
    lines += ['', '## 三人软报告的分支表达式','',f'- right_local_cap = `{capM}`.',
              f'- v_true/V = `{vtrue}`.',f'- I_true = `{itrue}`.','',
              '对候选w=right_local_cap，另检查左侧和超过1-ell的远端偏离。以下是浮点结构探针，不是全称凭证。','']
    gL=sp.factor(vtrue-vL-capM*(itrue-iL))
    gR=sp.factor(vtrue-vR-capM*(iR-itrue))
    fL=sp.lambdify((t,e,x),gL,'numpy');fR=sp.lambdify((t,e,x),gR,'numpy')
    fcap=sp.lambdify((t,e),capM,'numpy')
    failures=[];count=0
    for tt in np.linspace(.005,.249,35):
        for ee in np.linspace(.001,.499,35):
            cap=fcap(tt,ee)
            if cap<0:continue
            count+=1
            xx=np.linspace(0,ee,31);yy=np.linspace(1-ee,1,31)
            lm=float(np.min(fL(tt,ee,xx)));rm=float(np.min(fR(tt,ee,yy)))
            if min(lm,rm)<-1e-8:failures.append((tt,ee,cap,lm,rm))
    lines += [f'- 可行局部阈值点数：{count}；全局分支负差实例数：{len(failures)}。',f'- 最先的负差实例：{failures[:8]}。','',
              f'- 左侧在局部阈值处的收益差因式：`{gL}`。',f'- 远右侧收益差因式：`{gR}`。','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Extreme n=3 threshold:',sp.factor(S/b),'at p=3/4:',(S/b).subs(p,R(3,4)))
    print('Soft local cap:',capM)
    print('Soft global failures:',len(failures),failures[:5])
    print('gL:',gL);print('gR:',gR)


if __name__=='__main__':main()
