"""State-level ports of four official legacy epoch tests.

All listed expected integers come from tests/epoch.rs at the recorded commit.
Registration/staking extrinsics are replaced by their effective epoch state.
"""
import copy
import argparse
import json
from pathlib import Path
from differential import rust_batch, first_difference

ROOT=Path(__file__).resolve().parent


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--reference-only',action='store_true');args=ap.parse_args()
    if not args.reference_only:from python_epoch import epoch
    fixtures=[];checks=[]

    def run(name,state):
        r=rust_batch([state])[0]
        if not args.reference_only:
            p=json.loads(json.dumps(epoch(state)))
            difference=first_difference(r['terms'],p['terms'])
            assert difference is None,(name,difference)
        fixtures.append(dict(name=name,input=copy.deepcopy(state),output=r))
        return r['terms']

    def check(name,got,target):
        assert got==target,(name,got,target)
        checks.append(dict(name=name,got=got,target=target))

    for n in [1,10]:
        name=f'test_{n}_graph'
        state=dict(stakes=[10**9 if n==1 else 1]*n,weights_sparse=[[[i,65535]] for i in range(n)])
        terms=run(name,state)
        for i,t in enumerate(terms):
            for field in ['consensus','incentive','dividend']:
                check(name+f'/{i}/{field}',t[field],0)
            if n==10:check(name+f'/{i}/emission',t['emission'],99999999)
    terms=run('test_epoch_outputs_single_staker_registered_no_weights',dict(stakes=[1]))
    check('single_staker_emission',sum(t['server_emission']+t['validator_emission'] for t in terms),10**9)
    state=dict(stakes=[1,2,3,4,0,0,0,0],weights_sparse=[[[4,16383],[5,32767],[6,49149],[7,65535]] for _ in range(4)]+[[],[],[],[]],bonds_penalty=65535)
    expectations=[(4,[16383,32767,49151,65535]),(4,[14582,32767,49151,65535]),
                  (4,[12603,28321,49151,65535]),(7,[12602,28320,49150,65535]),
                  (7,[10951,24609,49150,65535]),(7,[9559,21482,49150,65535]),
                  (7,[8376,18824,49150,65535])]
    for step,(col,target) in enumerate(expectations):
        if 1<=step<=3:state['weights_sparse'][step-1]=[[step-1,65535]]
        elif step==4:state['weights_sparse'][2]=[[7,65535]]
        terms=run(f'test_bonds/{step}',state)
        check(f'test_bonds/{step}/column{col}',[dict(t['bond']).get(col,0) for t in terms[:4]],target)
        state['bonds_sparse']=[t['bond'] for t in terms]
    result=dict(test_names=['test_1_graph','test_10_graph','test_epoch_outputs_single_staker_registered_no_weights','test_bonds'],
                epochs=len(fixtures),assertions=len(checks),checks=checks,fixtures=fixtures,
                excluded_assertions='FRAME registration, staking, rank/trust storage getters are outside epoch-state runner')
    result['python_compared']=not args.reference_only
    filename='official_classic_reference.json' if args.reference_only else 'official_classic_results.json'
    (ROOT/filename).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print('official classic ports:',result['epochs'],'epochs;',result['assertions'],'assertions')


if __name__=='__main__':main()
