"""Reuse six upstream sequence-test bodies with an explicit epoch-state adapter."""
from build_reference import SOURCE, OUT, function
import json

NAMES = ["test_yuma_3_kappa_moves_first", "test_yuma_3_kappa_moves_second",
         "test_yuma_3_kappa_moves_last", "test_yuma_3_one_epoch_switch",
         "test_yuma_3_liquid_alpha_disabled", "test_yuma_3_stable_miner"]


def main():
    raw = (SOURCE / "pallets/subtensor/src/tests/epoch.rs").read_text(encoding="utf-8")
    text = '\n\n'.join(function(raw, n) for n in NAMES)
    text = text.replace('[true, false]', '[true]').replace('NetUid::from(1)', '1_u16')
    text += '\n' + function(raw, 'assert_approx_eq')
    text += '\n' + function(raw, 'run_epoch_and_check_bonds_dividends')
    dispatch = '\n'.join(f'run_case("{n}", {n});' for n in NAMES)
    text += '\npub fn run_all()->Value {\n RESULTS.with(|r|r.borrow_mut().clear());\n' + dispatch
    text += '\nRESULTS.with(|r|json!(r.borrow().clone()))\n}\n'
    (OUT / 'src/upstream_scenarios.rs').write_text(text, encoding='utf-8')
    print('extracted scenarios:', ', '.join(NAMES))


if __name__ == '__main__':
    main()
