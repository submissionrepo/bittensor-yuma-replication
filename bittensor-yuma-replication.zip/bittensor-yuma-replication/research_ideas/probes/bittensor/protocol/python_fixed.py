"""Integer operations for the substrate-fixed v0.6.0 epoch port.

Values are signed raw bits. I32F32 is the default (frac=32, bits=64).
No binary floating arithmetic is used by the epoch implementation.
"""

F = 1 << 32
F64 = 1 << 64
U16_MAX = (1 << 16) - 1
U64_MAX = (1 << 64) - 1


def sat(value: int, bits: int = 64) -> int:
    return min((1 << (bits - 1)) - 1, max(-(1 << (bits - 1)), value))


def wrap(value: int, bits: int = 64) -> int:
    return (value + (1 << (bits - 1))) % (1 << bits) - (1 << (bits - 1))


def integer(value: int, frac: int = 32, bits: int = 64) -> int:
    return sat(int(value) << frac, bits)


def trunc_div(numerator: int, denominator: int) -> int:
    if denominator == 0:
        raise ZeroDivisionError
    quotient = abs(numerator) // abs(denominator)
    return -quotient if (numerator < 0) != (denominator < 0) else quotient


def add(a: int, b: int, bits: int = 64) -> int:
    return sat(a + b, bits)


def sub(a: int, b: int, bits: int = 64) -> int:
    return sat(a - b, bits)


def mul(a: int, b: int, frac: int = 32, bits: int = 64) -> int:
    return sat((a * b) >> frac, bits)


def checked_mul(a: int, b: int, frac: int = 32, bits: int = 64):
    value = (a * b) >> frac
    return value if sat(value, bits) == value else None


def checked_div(a: int, b: int, frac: int = 32, bits: int = 64):
    if b == 0:
        return None
    value = trunc_div(a << frac, b)
    return value if sat(value, bits) == value else None


def safe_div(a: int, b: int, frac: int = 32, bits: int = 64) -> int:
    value = checked_div(a, b, frac, bits)
    return value if value is not None else 0


def div(a: int, b: int, frac: int = 32, bits: int = 64) -> int:
    # substrate-fixed saturating_div still panics on zero divisors.
    return sat(trunc_div(a << frac, b), bits)


def uint(value: int, frac: int = 32, bits: int = 64) -> int:
    return min((1 << bits) - 1, max(0, value >> frac))


def proportion(value: int) -> int:
    return safe_div(integer(value), integer(U16_MAX))


def to_u16(value: int) -> int:
    return uint(mul(value, integer(U16_MAX)), bits=16)


def normalise(values, frac: int = 32, bits: int = 64, total=None):
    values = list(values)
    total = wrap(sum(values), bits) if total is None else total
    return [safe_div(value, total, frac, bits) for value in values] if total else values


def exp_safe(value: int) -> int:
    """math.rs exp_safe wrapping the pinned 30-term fixed-point exp.

    The x=1 branch intentionally uses the dependency's I9F23 E constant,
    rather than a more accurate real exponential.
    """
    value = min(20 * F, max(-20 * F, value))
    if value == 0:
        return F
    if value == F:
        return (0xADF85458A2BB4A9AAFDC5620273D3CF1 >> 103) << 9
    negative = value < 0
    operand = abs(value)
    result = operand + F
    term = operand
    for i in range(2, 32):
        term = checked_mul(term, operand)
        if term is None:
            return 0 if negative else (1 << 63) - 1
        term = checked_div(term, integer(i))
        if term is None:
            return 0 if negative else (1 << 63) - 1
        result += term
        if result != sat(result):
            return 0 if negative else (1 << 63) - 1
    return safe_div(F, result) if negative else result
