//! State adapters for original upstream sequence-test bodies.
use super::*;
type SubtensorModule=Pallet<Runtime>;
thread_local! {
    static FIXTURES:RefCell<Vec<Value>>=RefCell::new(vec![]);
    static RESULTS:RefCell<Vec<Value>>=RefCell::new(vec![]);
}
struct Ext;
fn new_test_ext(_:u16)->Ext{Ext}
impl Ext{fn execute_with<F:FnOnce()>(&self,f:F){f()}}
fn run_case(name:&str,f:fn()){
    FIXTURES.with(|v|v.borrow_mut().clear());
    let ans=std::panic::catch_unwind(f);
    let error=ans.err().map(|e|{
        if let Some(s)=e.downcast_ref::<String>(){s.clone()}
        else if let Some(s)=e.downcast_ref::<&str>(){s.to_string()}
        else {"unknown panic".to_string()}
    });
    let fixtures=FIXTURES.with(|v|v.borrow().clone());
    RESULTS.with(|r|r.borrow_mut().push(json!({"name":name,"passed":error.is_none(),"error":error,"fixtures":fixtures})));
}
fn setup_yuma_3_scenario(_:u16,n:u16,_:bool,_:u64,stakes:Vec<u64>){
    STATE.with(|s|*s.borrow_mut()=json!({
        "stakes":stakes,"yuma3":true,"liquid":true,"alpha_low":6553,"alpha_high":19660,
        "bonds_penalty":0,"steepness":1000,"moving_average":975000,"max_validators":3,
        "permits":(0..n).map(|i|i<3).collect::<Vec<_>>(),"current_block":110,"last_update":vec![100;n as usize]
    }));
}
fn set_yuma_3_weights(_:u16,weights:Vec<Vec<u16>>,indices:Vec<u16>){
    let mut matrix=vec![vec![];len()];
    for(i,w)in weights.iter().enumerate(){matrix[i]=indices.iter().copied().zip(vec_u16_max_upscale_to_u16(w)).collect();}
    STATE.with(|s|s.borrow_mut()["weights_sparse"]=json!(matrix));
}
fn run_epoch(_:u16,_:bool){
    TRACE.with(|t|t.borrow_mut().clear());
    let input=STATE.with(|s|s.borrow().clone());
    let out=Pallet::<Runtime>::epoch_mechanism(1,0,1_000_000_000);
    let terms:Vec<_>=out.0.into_values().collect();
    let trace=TRACE.with(|t|t.borrow().clone());
    FIXTURES.with(|f|f.borrow_mut().push(json!({"input":input,"output":{"terms":terms,"trace":trace}})));
    STATE.with(|s|{
        let mut s=s.borrow_mut();
        s["bonds_sparse"]=json!(terms.iter().map(|t|t.bond.clone()).collect::<Vec<_>>());
        s["previous_consensus"]=json!(terms.iter().map(|t|t.consensus).collect::<Vec<_>>());
        s["has_previous_consensus"]=json!(true);
        s["stored_dividends"]=json!(terms.iter().map(|t|t.dividend).collect::<Vec<_>>());
    });
}
impl<T:Config> Pallet<T>{
    fn set_liquid_alpha_enabled(_:u16,b:bool){STATE.with(|s|s.borrow_mut()["liquid"]=json!(b));}
    fn get_dividends(_:u16)->Vec<u16>{arr("stored_dividends",0).into_iter().map(|v|v as u16).collect()}
}
include!("upstream_scenarios.rs");
