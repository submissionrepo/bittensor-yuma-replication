# Fixed-point epoch replication

`python_epoch.epoch(state)` implements the legacy, Yuma3, and adaptive-alpha
paths using integer raw bits. The source is Subtensor commit
`c004cebf360f4088187ee49d851dfb1a1eaaf710`, with substrate-fixed commit
`d5f70362f2e05b5f33fb51cd7baa825323e4e6c5`. Rust 1.89.0 was used.

## Build from public source

Install Rust 1.89.0 and its platform linker. From the repository root:

```sh
rustup toolchain install 1.89.0
python research_ideas/probes/bittensor/protocol/fetch_source.py
python research_ideas/probes/bittensor/protocol/build_reference.py
python research_ideas/probes/bittensor/protocol/build_scenarios.py
cargo +1.89.0 build --locked --manifest-path research_ideas/probes/bittensor/protocol/rust_reference/Cargo.toml
cargo +1.89.0 test --locked --manifest-path research_ideas/probes/bittensor/protocol/rust_reference/Cargo.toml
```

Downloads go into `vendor/` beside this file. The Python comparators look for
`rust_reference/target/debug/bittensor-epoch-reference` (with `.exe` on Windows).
Use the debug build above, or set `differential.EXE` explicitly in a custom
runner. No downloaded source or compiled binary is included in the package.

The adapter and extracted Rust sources are included for inspection. The build
scripts regenerate the upstream function bodies, imports, observation hooks,
and sequence tests from the stated source version. The mathematical operations
are not replaced with ideal real-arithmetic formulas.

## Recorded coverage

| Material | Recorded result | Scope |
|---|---|---|
| Upstream `tests/math.rs` | 81 tests passed | Adapted imports; the randomized test uses a fixed StdRng seed |
| Six official Yuma3 sequences | 36 epochs | Sparse production branch and active assertions |
| Four classic official tests | 10 epochs, 51 numeric assertions | Resolved epoch-state boundary |
| Additional official states and helpers | 113 epochs, 23 helpers, 18,737 expanded checks | See `official_extra_coverage.md` for exclusions |
| Differential comparison | 516 inputs, zero differences | 80 boundary states, 400 random states, 36 official sequence inputs |

These counts overlap and must not be added as independent samples. Some
upstream bond assertions zip empty ranges; differential tests compare complete
bond outputs and seven intermediate traces separately. Full coverage details
are in [official_extra_coverage.md](official_extra_coverage.md).

## State interface

Inputs include effective `stakes`, sparse weight/bond rows as
`[[column, u16], ...]`, validator permits, registration/update blocks, resolved
commit information, and epoch hyperparameters. `stakes_fixed64` can carry
I64F64 raw bits as decimal strings. See `python_epoch.py` for defaults.
Sparse missing entries and explicit zeros are distinct, especially for
adaptive bonds. Outputs contain `terms` and `trace` with the integer emissions,
stored bonds, and raw fixed-point intermediates.

The runner does not rebuild the chain runtime, dTAO effective-stake conversion,
permissions, registration, scheduling, or storage isolation. The reference
expects unique UID identities and already-resolved chain state.

## Replay

```sh
python research_ideas/probes/bittensor/protocol/differential.py
python research_ideas/probes/bittensor/protocol/official_classic.py
python research_ideas/probes/bittensor/protocol/official_extra.py
```

Run these from the repository root after building Rust. `official_extra.py`
also reads the fetched upstream test source. Saved results and inputs are
included so they can be inspected without a compiler. To regenerate the
official sequence fixture, send one line `{"op":"official_scenarios"}` to
the reference executable and save its single JSON response as
`official_scenarios.json`.

See [NOTICE.md](NOTICE.md) and the adjacent license files for upstream
attribution and licenses.
