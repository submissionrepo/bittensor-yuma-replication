# Additional official epoch test coverage

Research software evidence only; not a full FRAME suite pass.

Formal test functions: 38. Additional epoch comparisons: 113. Helper calls: 23. Replayed numerical expectation checks: 18737. Findings: 0.

| Source test | Status | Epochs | Numeric checks | Scope/reason |
| --- | --- | ---: | ---: | --- |
| `test_1_graph` (line 557) | covered_in_existing_material | 0 | 0 | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| `test_10_graph` (line 610) | covered_in_existing_material | 0 | 0 | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| `test_512_graph` (line 680) | state_boundary_replayed | 18 | 18432 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. |
| `test_512_graph_random_weights` (line 760) | outside_current_entry_not_replayed | 0 | 0 | Original assertion compares dense epoch against sparse epoch under Rust StdRng. The reference deliberately runs production sparse only; no claim of original dense/sparse test replay. |
| `test_bonds` (line 1006) | covered_in_existing_material | 0 | 0 | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| `test_set_alpha_disabled` (line 1311) | outside_current_entry_not_replayed | 0 | 0 | FRAME origin/owner authorization and LiquidAlphaDisabled dispatch error; no epoch invocation. |
| `test_active_stake` (line 1355) | state_boundary_replayed | 3 | 30 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. |
| `test_outdated_weights` (line 1575) | state_boundary_replayed | 2 | 4 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. |
| `test_zero_weights` (line 1775) | state_boundary_replayed | 4 | 8 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. |
| `test_deregistered_miner_bonds` (line 1985) | state_boundary_replayed | 2 | 4 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. |
| `test_validator_permits` (line 2169) | state_boundary_replayed | 36 | 168 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. |
| `test_min_alpha_low_matches_bonds_moving_average_floor` (line 2301) | numeric_conversion_assertions_replayed_setup_excluded | 0 | 2 | Only original fixed-alpha floor/conversion numeric assertions replayed through source helper; setters, origin checks, storage round trips and dispatch errors remain excluded. |
| `test_get_set_alpha` (line 2331) | numeric_conversion_assertions_replayed_setup_excluded | 0 | 2 | Only original fixed-alpha floor/conversion numeric assertions replayed through source helper; setters, origin checks, storage round trips and dispatch errors remain excluded. |
| `test_blocks_since_last_step` (line 2482) | outside_current_entry_not_replayed | 0 | 0 | on_initialize/automatic epoch scheduling and block-counter storage; outside single epoch mathematical entry. |
| `test_can_set_self_weight_as_subnet_owner` (line 2531) | state_boundary_replayed | 1 | 4 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. |
| `test_epoch_outputs_single_staker_registered_no_weights` (line 2594) | covered_in_existing_material | 0 | 0 | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| `test_yuma_3_kappa_moves_first` (line 2866) | covered_in_existing_material | 0 | 0 | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| `test_yuma_3_kappa_moves_second` (line 2969) | covered_in_existing_material | 0 | 0 | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| `test_yuma_3_kappa_moves_last` (line 3071) | covered_in_existing_material | 0 | 0 | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| `test_yuma_3_one_epoch_switch` (line 3173) | covered_in_existing_material | 0 | 0 | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| `test_yuma_3_liquid_alpha_disabled` (line 3259) | covered_in_existing_material | 0 | 0 | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| `test_yuma_3_stable_miner` (line 3348) | covered_in_existing_material | 0 | 0 | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| `test_yuma_3_bonds_reset` (line 3462) | state_boundary_replayed | 41 | 35 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. Reset storage transform supplied explicitly. Original helper's bond zip skips all short target rows, so only dividend target assertions are active; all resulting bond bytes still compared across implementations. |
| `test_liquid_alpha_equal_values_against_itself` (line 3608) | dense_helper_original_assertions_rust_only | 0 | 17 | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |
| `test_liquid_alpha_consensus_modes` (line 3650) | sparse_helper_assertions_replayed | 0 | 8 | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. Other-mechanism previous vector is supplied as a second state; this checks selection values, not FRAME cross-mechanism storage isolation. |
| `test_compute_bonds_uses_selected_consensus` (line 3707) | dense_helper_original_assertions_rust_only | 0 | 4 | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |
| `test_compute_bonds_sparse_uses_selected_consensus` (line 3756) | sparse_helper_assertions_replayed | 0 | 4 | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. |
| `test_compute_bonds_checks_selected_consensus_for_zero` (line 3822) | dense_helper_original_assertions_rust_only | 0 | 4 | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |
| `test_compute_bonds_sparse_checks_selected_consensus_for_zero` (line 3870) | sparse_helper_assertions_replayed | 0 | 4 | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. |
| `regression_liquid_alpha_event_indices_are_append_only` (line 3938) | outside_current_entry_not_replayed | 0 | 0 | SCALE event discriminants, outside numerical epoch. |
| `test_epoch_masks_incoming_to_sniped_uid_prevents_inheritance` (line 3961) | state_boundary_replayed | 1 | 1 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. |
| `test_epoch_no_mask_when_commit_reveal_disabled` (line 4059) | epoch_calls_replayed_storage_assertion_excluded | 3 | 0 | Original checks get_weights_sparse storage remains nonempty, not masked epoch weights. Epoch output does not persist weights; do not turn this into a stronger effective-weight assertion. |
| `test_epoch_does_not_mask_outside_window_but_masks_inside` (line 4106) | state_boundary_replayed | 1 | 3 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. |
| `test_last_update_size_mismatch` (line 4210) | state_boundary_replayed | 1 | 3 | All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions. |
| `empty_ok` (line 4266) | outside_current_entry_not_replayed | 0 | 0 | is_epoch_input_state_consistent checks FRAME Keys map; runner assumes unique UID/hotkey map by construction. |
| `unique_hotkeys_and_uids_ok` (line 4274) | outside_current_entry_not_replayed | 0 | 0 | is_epoch_input_state_consistent checks FRAME Keys map; runner supplies one unique hotkey per UID. |
| `duplicate_hotkey_within_same_netuid_fails` (line 4288) | outside_current_entry_not_replayed | 0 | 0 | Duplicate FRAME hotkeys cannot be represented by current unique-UID mathematical input. |
| `same_hotkey_across_different_netuids_is_ok` (line 4302) | outside_current_entry_not_replayed | 0 | 0 | Cross-netuid Keys storage isolation, outside single-network mathematical input. |

Every source assertion macro and its line/text is inventoried in `official_extra_results.json`; setup/adapter assertions are preserved as coverage exclusions, not counted as passed. The check list identifies the numerical assertions actually executed.

Large uniform graph replay uses the original n=512, 64 validators and all three interleaving modes, two server-self settings, and three epochs. The upstream random interleaving is unseeded; this replay chooses one reproducible permutation. Original random-weight dense-versus-sparse test remains separately excluded.

Outputs are compared for all EpochTerms and seven raw traces, including bond values even when an upstream helper accidentally skips its target bond loop. These finite tests do not prove universal equivalence.

## Assertion-level coverage

The following inventory lists the disposition of every assertion macro (and direct matrix comparison) inside the 38 formal test functions. A pass at the state boundary does not cover excluded setup, identity, or storage assertions.

### test_1_graph

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 574 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 581 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 583 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 593 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 597 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 598 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 599 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 600 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 604 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |

### test_10_graph

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 631 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 642 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 645 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 657 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 661 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 662 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 663 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 664 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 668 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 669 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |

### test_512_graph

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 717 | not_replayed_stake_storage | Upstream staking storage assertion, not the effective stake conversion performed by epoch. |
| 721 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 722 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 726 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 727 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 731 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 732 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 735 | not_replayed_stake_storage | Upstream staking storage assertion, not the effective stake conversion performed by epoch. |
| 739 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 740 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 744 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 745 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 749 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 750 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |

### test_512_graph_random_weights

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 839 | not_replayed | Original assertion compares dense epoch against sparse epoch under Rust StdRng. The reference deliberately runs production sparse only; no claim of original dense/sparse test replay. |
| 843 | not_replayed | Original assertion compares dense epoch against sparse epoch under Rust StdRng. The reference deliberately runs production sparse only; no claim of original dense/sparse test replay. |
| 847 | not_replayed | Original assertion compares dense epoch against sparse epoch under Rust StdRng. The reference deliberately runs production sparse only; no claim of original dense/sparse test replay. |
| 851 | not_replayed | Original assertion compares dense epoch against sparse epoch under Rust StdRng. The reference deliberately runs production sparse only; no claim of original dense/sparse test replay. |
| 855 | not_replayed | Original assertion compares dense epoch against sparse epoch under Rust StdRng. The reference deliberately runs production sparse only; no claim of original dense/sparse test replay. |
| 856 | not_replayed | Original assertion compares dense epoch against sparse epoch under Rust StdRng. The reference deliberately runs production sparse only; no claim of original dense/sparse test replay. |

### test_bonds

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 1017 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1032 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1035 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1036 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1040 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1046 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1084 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1085 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1086 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1087 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1091 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1132 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1133 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1134 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1135 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1139 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1169 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1170 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1171 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1172 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1176 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1206 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1207 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1208 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1209 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1212 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1242 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1243 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1244 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1245 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1264 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1265 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1266 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1267 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1286 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1287 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1288 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |
| 1289 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |

### test_set_alpha_disabled

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 1322 | not_replayed | FRAME origin/owner authorization and LiquidAlphaDisabled dispatch error; no epoch invocation. |
| 1327 | not_replayed | FRAME origin/owner authorization and LiquidAlphaDisabled dispatch error; no epoch invocation. |
| 1334 | not_replayed | FRAME origin/owner authorization and LiquidAlphaDisabled dispatch error; no epoch invocation. |
| 1338 | not_replayed | FRAME origin/owner authorization and LiquidAlphaDisabled dispatch error; no epoch invocation. |
| 1344 | not_replayed | FRAME origin/owner authorization and LiquidAlphaDisabled dispatch error; no epoch invocation. |

### test_active_stake

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 1366 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1383 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1399 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1400 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1404 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1410 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1429 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1432 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1440 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1443 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1450 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1489 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1490 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1495 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1498 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1502 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1507 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1513 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1553 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1554 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1559 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1561 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1562 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1567 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |

### test_outdated_weights

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 1590 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1606 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1622 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1623 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1627 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1629 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1631 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1635 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1644 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1699 | not_replayed_registration_identity | Block progression, re-registration selection, or AccountId identity is supplied by the state adapter rather than executed. |
| 1700 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1701 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1702 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1712 | not_replayed_registration_identity | Block progression, re-registration selection, or AccountId identity is supplied by the state adapter rather than executed. |
| 1720 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1763 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1764 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1768 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1769 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |

### test_zero_weights

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 1802 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1821 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 1837 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1843 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1854 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1876 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1882 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1893 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1915 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1938 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1944 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 1954 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 1975 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |

### test_deregistered_miner_bonds

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 2000 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2017 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 2033 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2034 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2038 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2040 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2042 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2046 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 2077 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 2078 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 2101 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2102 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2103 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 2113 | not_replayed_registration_identity | Block progression, re-registration selection, or AccountId identity is supplied by the state adapter rather than executed. |
| 2121 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 2135 | not_replayed_registration_identity | Block progression, re-registration selection, or AccountId identity is supplied by the state adapter rather than executed. |
| 2156 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 2160 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |

### test_validator_permits

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 2196 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2222 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 2238 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2242 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 2248 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 2254 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 2280 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 2286 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |

### test_min_alpha_low_matches_bonds_moving_average_floor

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 2307 | numeric_conversion_assertions_replayed_setup_excluded | Only original fixed-alpha floor/conversion numeric assertions replayed through source helper; setters, origin checks, storage round trips and dispatch errors remain excluded. |
| 2308 | numeric_conversion_assertions_replayed_setup_excluded | Only original fixed-alpha floor/conversion numeric assertions replayed through source helper; setters, origin checks, storage round trips and dispatch errors remain excluded. |
| 2311 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2320 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |

### test_get_set_alpha

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 2345 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2348 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2353 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2361 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2368 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2378 | not_replayed_storage_roundtrip | Alpha values storage setter/getter round-trip is supplied by adapter, not executed. |
| 2379 | not_replayed_storage_roundtrip | Alpha values storage setter/getter round-trip is supplied by adapter, not executed. |
| 2395 | numeric_conversion_assertions_replayed_setup_excluded | Only original fixed-alpha floor/conversion numeric assertions replayed through source helper; setters, origin checks, storage round trips and dispatch errors remain excluded. |
| 2401 | numeric_conversion_assertions_replayed_setup_excluded | Only original fixed-alpha floor/conversion numeric assertions replayed through source helper; setters, origin checks, storage round trips and dispatch errors remain excluded. |
| 2410 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2416 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2425 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2435 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2444 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2454 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2462 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |
| 2472 | not_replayed_dispatch | Parameter validation, authorization and FRAME dispatch are outside supplied helper state. |

### test_blocks_since_last_step

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 2496 | not_replayed | on_initialize/automatic epoch scheduling and block-counter storage; outside single epoch mathematical entry. |
| 2497 | not_replayed | on_initialize/automatic epoch scheduling and block-counter storage; outside single epoch mathematical entry. |
| 2509 | not_replayed | on_initialize/automatic epoch scheduling and block-counter storage; outside single epoch mathematical entry. |
| 2521 | not_replayed | on_initialize/automatic epoch scheduling and block-counter storage; outside single epoch mathematical entry. |
| 2525 | not_replayed | on_initialize/automatic epoch scheduling and block-counter storage; outside single epoch mathematical entry. |

### test_can_set_self_weight_as_subnet_owner

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 2575 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 2576 | not_replayed_registration_identity | Block progression, re-registration selection, or AccountId identity is supplied by the state adapter rather than executed. |
| 2581 | not_replayed_registration_identity | Block progression, re-registration selection, or AccountId identity is supplied by the state adapter rather than executed. |
| 2585 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 2586 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 2589 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |

### test_epoch_outputs_single_staker_registered_no_weights

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 2625 | delegated_existing_material | See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there. |

### test_yuma_3_kappa_moves_first

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| — | expectations delegated to test helper | See the test-level row and executed check list. |

### test_yuma_3_kappa_moves_second

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| — | expectations delegated to test helper | See the test-level row and executed check list. |

### test_yuma_3_kappa_moves_last

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| — | expectations delegated to test helper | See the test-level row and executed check list. |

### test_yuma_3_one_epoch_switch

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| — | expectations delegated to test helper | See the test-level row and executed check list. |

### test_yuma_3_liquid_alpha_disabled

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| — | expectations delegated to test helper | See the test-level row and executed check list. |

### test_yuma_3_stable_miner

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| — | expectations delegated to test helper | See the test-level row and executed check list. |

### test_yuma_3_bonds_reset

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| — | expectations delegated to test helper | See the test-level row and executed check list. |

### test_liquid_alpha_equal_values_against_itself

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 3641 | dense_helper_original_assertions_rust_only | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |

### test_liquid_alpha_consensus_modes

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 3671 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. Other-mechanism previous vector is supplied as a second state; this checks selection values, not FRAME cross-mechanism storage isolation. |
| 3678 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. Other-mechanism previous vector is supplied as a second state; this checks selection values, not FRAME cross-mechanism storage isolation. |
| 3679 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. Other-mechanism previous vector is supplied as a second state; this checks selection values, not FRAME cross-mechanism storage isolation. |
| 3680 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. Other-mechanism previous vector is supplied as a second state; this checks selection values, not FRAME cross-mechanism storage isolation. |
| 3681 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. Other-mechanism previous vector is supplied as a second state; this checks selection values, not FRAME cross-mechanism storage isolation. |
| 3688 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. Other-mechanism previous vector is supplied as a second state; this checks selection values, not FRAME cross-mechanism storage isolation. |
| 3693 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. Other-mechanism previous vector is supplied as a second state; this checks selection values, not FRAME cross-mechanism storage isolation. |
| 3699 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. Other-mechanism previous vector is supplied as a second state; this checks selection values, not FRAME cross-mechanism storage isolation. |

### test_compute_bonds_uses_selected_consensus

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 3734 | dense_helper_original_assertions_rust_only | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |
| 3739 | dense_helper_original_assertions_rust_only | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |
| 3743 | dense_helper_original_assertions_rust_only | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |
| 3748 | dense_helper_original_assertions_rust_only | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |

### test_compute_bonds_sparse_uses_selected_consensus

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 3800 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. |
| 3805 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. |
| 3809 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. |
| 3814 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. |

### test_compute_bonds_checks_selected_consensus_for_zero

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 3854 | dense_helper_original_assertions_rust_only | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |
| 3855 | dense_helper_original_assertions_rust_only | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |
| 3864 | dense_helper_original_assertions_rust_only | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |
| 3865 | dense_helper_original_assertions_rust_only | Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call. |

### test_compute_bonds_sparse_checks_selected_consensus_for_zero

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 3919 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. |
| 3920 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. |
| 3932 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. |
| 3933 | sparse_helper_assertions_replayed | Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python. |

### regression_liquid_alpha_event_indices_are_append_only

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 3955 | not_replayed | SCALE event discriminants, outside numerical epoch. |
| 3956 | not_replayed | SCALE event discriminants, outside numerical epoch. |
| 3957 | not_replayed | SCALE event discriminants, outside numerical epoch. |

### test_epoch_masks_incoming_to_sniped_uid_prevents_inheritance

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 3968 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 4014 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 4040 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 4050 | not_replayed_legacy_storage | Rank/trust storage getters are not emitted or persisted by current EpochTerms; do not relabel incentive/trust trace checks as these storage assertions. |
| 4051 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |

### test_epoch_no_mask_when_commit_reveal_disabled

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 4086 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 4096 | not_replayed_weight_storage | Original assertion is on unmodified stored weights, not effective masked weights; epoch runner does not emulate the persistence layer. |

### test_epoch_does_not_mask_outside_window_but_masks_inside

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 4113 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 4179 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 4190 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 4194 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 4199 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |

### test_last_update_size_mismatch

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 4229 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 4236 | not_replayed_configuration_storage | FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter. |
| 4238 | not_replayed_dispatch | Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary. |
| 4250 | not_replayed_stake_storage | Upstream staking storage assertion, not the effective stake conversion performed by epoch. |
| 4254 | not_replayed_legacy_storage | Rank/trust storage getters are not emitted or persisted by current EpochTerms; do not relabel incentive/trust trace checks as these storage assertions. |
| 4255 | not_replayed_legacy_storage | Rank/trust storage getters are not emitted or persisted by current EpochTerms; do not relabel incentive/trust trace checks as these storage assertions. |
| 4256 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 4257 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |
| 4261 | state_expectation_replayed | Numeric epoch expectation expanded over the source test loops; see checks for concrete values. |

### empty_ok

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 4269 | not_replayed | is_epoch_input_state_consistent checks FRAME Keys map; runner assumes unique UID/hotkey map by construction. |

### unique_hotkeys_and_uids_ok

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 4283 | not_replayed | is_epoch_input_state_consistent checks FRAME Keys map; runner supplies one unique hotkey per UID. |

### duplicate_hotkey_within_same_netuid_fails

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 4297 | not_replayed | Duplicate FRAME hotkeys cannot be represented by current unique-UID mathematical input. |

### same_hotkey_across_different_netuids_is_ok

| Source line | Assertion status | Reason |
| ---: | --- | --- |
| 4312 | not_replayed | Cross-netuid Keys storage isolation, outside single-network mathematical input. |
| 4313 | not_replayed | Cross-netuid Keys storage isolation, outside single-network mathematical input. |
