"""Build a standalone runner from pinned, unmodified upstream function bodies.

Only imports, state/storage adapters, serialization and observation hooks differ.
This is an epoch-state runner, not a FRAME runtime or a chain-state importer.
"""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parent
COMMIT = "c004cebf360f4088187ee49d851dfb1a1eaaf710"
FIXED = "d5f70362f2e05b5f33fb51cd7baa825323e4e6c5"
SOURCE = ROOT / "vendor" / ("subtensor-" + COMMIT)
OUT = ROOT / "rust_reference"


def function(text, name):
    m = re.search(r"(?:pub(?:\(crate\))?\s+)?fn\s+" + name + r"\s*(?:<[^\n]*>)?\s*\(", text)
    if not m:
        raise ValueError(name)
    start = m.start()
    pos = text.index("{", m.end())
    depth = 1
    end = pos + 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return text[start:end]


def main():
    src = OUT / "src"
    src.mkdir(parents=True, exist_ok=True)
    math = (SOURCE / "pallets/subtensor/src/epoch/math.rs").read_text(encoding="utf-8")
    math = math.replace("use safe_math::*;", "use crate::safe_math::*;")
    math = math.replace("use sp_runtime::traits::CheckedAdd;", "use num_traits::CheckedAdd;")
    math = math.replace("use sp_std::", "use std::")
    (src / "math.rs").write_text(math, encoding="utf-8")
    raw = (SOURCE / "pallets/subtensor/src/epoch/run_epoch.rs").read_text(encoding="utf-8")
    names = ["epoch_mechanism", "get_float_kappa", "get_float_bonds_penalty",
             "get_block_at_registration", "get_weights_sparse", "get_weights",
             "get_bonds_sparse", "get_bonds", "get_bonds_fixed_proportion",
             "get_bonds_sparse_fixed_proportion", "compute_ema_bonds_normal_sparse",
             "compute_ema_bonds_normal", "compute_bonds", "compute_bonds_sparse",
             "compute_consensus_for_liquid_alpha", "compute_liquid_alpha_values",
             "compute_liquid_alpha_values_sparse", "alpha_sigmoid", "compute_disabled_liquid_alpha"]
    bodies = "\n\n".join(function(raw, name) for name in names)
    # Observation only: these insertions do not write any upstream local variable.
    hooks = {
        'log::debug!("Normalised Stake: {:?}", &stake);': 'trace32("normalized_stake", &stake);',
        'log::trace!("Active Stake: {:?}", &active_stake);': 'trace32("active_stake", &active_stake);',
        'log::trace!("Weights (mask+norm): {:?}", &weights);': 'tracesparse("weights", &weights);',
        'log::trace!("Consensus: {:?}", &consensus);': 'trace32("consensus", &consensus);',
        'log::trace!("Clipped Weights: {:?}", &clipped_weights);': 'tracesparse("clipped_weights", &clipped_weights);',
        'log::trace!("Incentive (=Rank): {:?}", &incentive);': 'trace32("incentive", &incentive);',
        'log::trace!("Dividends: {:?}", &dividends);': 'trace32("dividends", &dividends);',
    }
    for anchor, extra in hooks.items():
        if anchor not in bodies:
            raise ValueError(anchor)
        bodies = bodies.replace(anchor, anchor + "\n" + extra)
    (src / "upstream_impl.rs").write_text("impl<T: Config> Pallet<T> {\n" + bodies + "\n}\n", encoding="utf-8")
    safe = (SOURCE / "primitives/safe-math/src/lib.rs").read_text(encoding="utf-8")
    # Only the trait's two methods used by epoch math. Bodies copied verbatim.
    sf = 'use substrate_fixed::traits::Fixed;\npub trait FixedExt: Fixed {\n'
    sf += function(safe[safe.index("pub trait FixedExt"):], "safe_div_or") + "\n"
    sf += function(safe[safe.index("pub trait FixedExt"):], "safe_div") + "\n}\nimpl<T: Fixed> FixedExt for T {}\n"
    sf += safe[safe.index("pub trait SafeDiv"):safe.index("pub trait FixedExt")]
    (src / "safe_math.rs").write_text(sf.rstrip() + "\n", encoding="utf-8")
    test = (SOURCE / "pallets/subtensor/src/tests/math.rs").read_text(encoding="utf-8")
    test = test.replace("crate::epoch::math::*", "crate::math::*")
    test = test.replace("use rand::{RngExt,", "use rand::{SeedableRng, RngExt,")
    test = test.replace("rand::rng()", "rand::rngs::StdRng::seed_from_u64(20260930)")
    (src / "upstream_math_tests.rs").write_text(test, encoding="utf-8")
    fixedpath = "../vendor/substrate-fixed-" + FIXED
    (OUT / "Cargo.toml").write_text(f'''[package]
name = "bittensor-epoch-reference"
version = "0.1.0"
edition = "2024"

[dependencies]
substrate-fixed = {{ path = "{fixedpath}", features = ["std"] }}
serde = {{ version = "1.0", features = ["derive"] }}
serde_json = "1.0"
num-traits = "0.2"
log = "0.4"

[dev-dependencies]
rand = {{ version = "0.10", default-features = false, features = ["std", "std_rng"] }}
''', encoding="utf-8")
    (ROOT / "reference_extraction.json").write_text(json.dumps({
        "commit": COMMIT, "substrate_fixed_commit": FIXED, "functions": names,
        "math": "all function bodies; imports adapted", "safe_math": "SafeDiv plus used FixedExt methods",
        "tests": "entire upstream tests/math.rs; import path adapted; randomized median uses StdRng seed 20260930 instead of OS thread rng",
        "observations": hooks,
        "state_boundary": "effective stake, registered UIDs, hyperparameters and resolved commit state; no FRAME storage or dTAO conversion"
    }, indent=2) + "\n", encoding="utf-8")
    print(f"extracted {len(names)} original epoch/getter/bond functions and complete math module")


if __name__ == "__main__":
    main()
