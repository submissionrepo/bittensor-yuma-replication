# 符号重算与非负证书

2026-09-29。第一层计算；不替代第二层对模型、量词、经济学归约及整段证明的独立核查。

## 三人联盟全参数质量比较

p=(1+z)/2，z∈[0,1]。在 r≥lambda 分支取 r=base+e、lambda=base；另一分支交换。base,e≥0。
对每个确定性零/一/二信号策略，Q_policy−Q_attack=base P(z)+e R(z)。下列每个多项式的 Bernstein 系数非负，因此在整个区间非负；不是 p 网格。

- r>=lambda; acquired=0; policy=(0,); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1/2]].
- r>=lambda; acquired=0; policy=(1,); Bernstein(base,e)=[[0, 1], [0, 1/12, 1/6, 0]].
- r>=lambda; acquired=0; policy=(2,); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1/2]].
- r>=lambda; acquired=1; policy=(0, 0); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1/2]].
- r>=lambda; acquired=1; policy=(0, 1); Bernstein(base,e)=[[0, 3/2], [0, 1/4, 1/2, 1/2]].
- r>=lambda; acquired=1; policy=(0, 2); Bernstein(base,e)=[[0, 2], [0, 5/12, 5/6, 1]].
- r>=lambda; acquired=1; policy=(1, 0); Bernstein(base,e)=[[0, 1/2], [0, 1/12, 1/6, 0]].
- r>=lambda; acquired=1; policy=(1, 1); Bernstein(base,e)=[[0, 1], [0, 1/12, 1/6, 0]].
- r>=lambda; acquired=1; policy=(1, 2); Bernstein(base,e)=[[0, 3/2], [0, 1/4, 1/2, 1/2]].
- r>=lambda; acquired=1; policy=(2, 0); Bernstein(base,e)=[[0], [0, 1/12, 1/6, 0]].
- r>=lambda; acquired=1; policy=(2, 1); Bernstein(base,e)=[[0, 1/2], [0, 1/12, 1/6, 0]].
- r>=lambda; acquired=1; policy=(2, 2); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1/2]].
- r>=lambda; acquired=2; policy=(0, 0, 0); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1/2]].
- r>=lambda; acquired=2; policy=(0, 0, 1); Bernstein(base,e)=[[0, 3/2], [0, 7/24, 7/12, 1/2]].
- r>=lambda; acquired=2; policy=(0, 0, 2); Bernstein(base,e)=[[0, 2], [0, 5/12, 5/6, 1]].
- r>=lambda; acquired=2; policy=(0, 1, 0); Bernstein(base,e)=[[0, 1], [0, 1/2]].
- r>=lambda; acquired=2; policy=(0, 1, 1); Bernstein(base,e)=[[0, 3/2], [0, 5/24, 5/12, 1/2]].
- r>=lambda; acquired=2; policy=(0, 1, 2); Bernstein(base,e)=[[0, 2], [0, 1]].
- r>=lambda; acquired=2; policy=(0, 2, 0); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1/2]].
- r>=lambda; acquired=2; policy=(0, 2, 1); Bernstein(base,e)=[[0, 3/2], [0, 7/24, 7/12, 1/2]].
- r>=lambda; acquired=2; policy=(0, 2, 2); Bernstein(base,e)=[[0, 2], [0, 5/12, 5/6, 1]].
- r>=lambda; acquired=2; policy=(1, 0, 0); Bernstein(base,e)=[[0, 1/2], [0, 1/8, 1/4, 0]].
- r>=lambda; acquired=2; policy=(1, 0, 1); Bernstein(base,e)=[[0, 1], [0, 1/6, 1/3, 0]].
- r>=lambda; acquired=2; policy=(1, 0, 2); Bernstein(base,e)=[[0, 3/2], [0, 7/24, 7/12, 1/2]].
- r>=lambda; acquired=2; policy=(1, 1, 0); Bernstein(base,e)=[[0, 1/2], [0, 1/24, 1/12, 0]].
- r>=lambda; acquired=2; policy=(1, 1, 1); Bernstein(base,e)=[[0, 1], [0, 1/12, 1/6, 0]].
- r>=lambda; acquired=2; policy=(1, 1, 2); Bernstein(base,e)=[[0, 3/2], [0, 5/24, 5/12, 1/2]].
- r>=lambda; acquired=2; policy=(1, 2, 0); Bernstein(base,e)=[[0, 1/2], [0, 1/8, 1/4, 0]].
- r>=lambda; acquired=2; policy=(1, 2, 1); Bernstein(base,e)=[[0, 1], [0, 1/6, 1/3, 0]].
- r>=lambda; acquired=2; policy=(1, 2, 2); Bernstein(base,e)=[[0, 3/2], [0, 7/24, 7/12, 1/2]].
- r>=lambda; acquired=2; policy=(2, 0, 0); Bernstein(base,e)=[[0], [0, 1/12, 1/6, 0]].
- r>=lambda; acquired=2; policy=(2, 0, 1); Bernstein(base,e)=[[0, 1/2], [0, 1/8, 1/4, 0]].
- r>=lambda; acquired=2; policy=(2, 0, 2); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1/2]].
- r>=lambda; acquired=2; policy=(2, 1, 0); Bernstein(base,e)=[[0], [0]].
- r>=lambda; acquired=2; policy=(2, 1, 1); Bernstein(base,e)=[[0, 1/2], [0, 1/24, 1/12, 0]].
- r>=lambda; acquired=2; policy=(2, 1, 2); Bernstein(base,e)=[[0, 1], [0, 1/2]].
- r>=lambda; acquired=2; policy=(2, 2, 0); Bernstein(base,e)=[[0], [0, 1/12, 1/6, 0]].
- r>=lambda; acquired=2; policy=(2, 2, 1); Bernstein(base,e)=[[0, 1/2], [0, 1/8, 1/4, 0]].
- r>=lambda; acquired=2; policy=(2, 2, 2); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1/2]].
- lambda>=r; acquired=0; policy=(0,); Bernstein(base,e)=[[0, 1], [0, 1/2]].
- lambda>=r; acquired=0; policy=(1,); Bernstein(base,e)=[[0, 1], [0, 1]].
- lambda>=r; acquired=0; policy=(2,); Bernstein(base,e)=[[0, 1], [0, 1/2]].
- lambda>=r; acquired=1; policy=(0, 0); Bernstein(base,e)=[[0, 1], [0, 1/2]].
- lambda>=r; acquired=1; policy=(0, 1); Bernstein(base,e)=[[0, 3/2], [0, 1]].
- lambda>=r; acquired=1; policy=(0, 2); Bernstein(base,e)=[[0, 2], [0, 1]].
- lambda>=r; acquired=1; policy=(1, 0); Bernstein(base,e)=[[0, 1/2], [0, 1/2]].
- lambda>=r; acquired=1; policy=(1, 1); Bernstein(base,e)=[[0, 1], [0, 1]].
- lambda>=r; acquired=1; policy=(1, 2); Bernstein(base,e)=[[0, 3/2], [0, 1]].
- lambda>=r; acquired=1; policy=(2, 0); Bernstein(base,e)=[[0], [0]].
- lambda>=r; acquired=1; policy=(2, 1); Bernstein(base,e)=[[0, 1/2], [0, 1/2]].
- lambda>=r; acquired=1; policy=(2, 2); Bernstein(base,e)=[[0, 1], [0, 1/2]].
- lambda>=r; acquired=2; policy=(0, 0, 0); Bernstein(base,e)=[[0, 1], [0, 1/2]].
- lambda>=r; acquired=2; policy=(0, 0, 1); Bernstein(base,e)=[[0, 3/2], [0, 7/24, 7/12, 1]].
- lambda>=r; acquired=2; policy=(0, 0, 2); Bernstein(base,e)=[[0, 2], [0, 1]].
- lambda>=r; acquired=2; policy=(0, 1, 0); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1/2]].
- lambda>=r; acquired=2; policy=(0, 1, 1); Bernstein(base,e)=[[0, 3/2], [0, 3/8, 3/4, 1]].
- lambda>=r; acquired=2; policy=(0, 1, 2); Bernstein(base,e)=[[0, 2], [0, 5/12, 5/6, 1]].
- lambda>=r; acquired=2; policy=(0, 2, 0); Bernstein(base,e)=[[0, 1], [0, 1/2]].
- lambda>=r; acquired=2; policy=(0, 2, 1); Bernstein(base,e)=[[0, 3/2], [0, 7/24, 7/12, 1]].
- lambda>=r; acquired=2; policy=(0, 2, 2); Bernstein(base,e)=[[0, 2], [0, 1]].
- lambda>=r; acquired=2; policy=(1, 0, 0); Bernstein(base,e)=[[0, 1/2], [0, 1/8, 1/4, 1/2]].
- lambda>=r; acquired=2; policy=(1, 0, 1); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1]].
- lambda>=r; acquired=2; policy=(1, 0, 2); Bernstein(base,e)=[[0, 3/2], [0, 7/24, 7/12, 1]].
- lambda>=r; acquired=2; policy=(1, 1, 0); Bernstein(base,e)=[[0, 1/2], [0, 5/24, 5/12, 1/2]].
- lambda>=r; acquired=2; policy=(1, 1, 1); Bernstein(base,e)=[[0, 1], [0, 1]].
- lambda>=r; acquired=2; policy=(1, 1, 2); Bernstein(base,e)=[[0, 3/2], [0, 3/8, 3/4, 1]].
- lambda>=r; acquired=2; policy=(1, 2, 0); Bernstein(base,e)=[[0, 1/2], [0, 1/8, 1/4, 1/2]].
- lambda>=r; acquired=2; policy=(1, 2, 1); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1]].
- lambda>=r; acquired=2; policy=(1, 2, 2); Bernstein(base,e)=[[0, 3/2], [0, 7/24, 7/12, 1]].
- lambda>=r; acquired=2; policy=(2, 0, 0); Bernstein(base,e)=[[0], [0]].
- lambda>=r; acquired=2; policy=(2, 0, 1); Bernstein(base,e)=[[0, 1/2], [0, 1/8, 1/4, 1/2]].
- lambda>=r; acquired=2; policy=(2, 0, 2); Bernstein(base,e)=[[0, 1], [0, 1/2]].
- lambda>=r; acquired=2; policy=(2, 1, 0); Bernstein(base,e)=[[0], [0, 1/12, 1/6, 0]].
- lambda>=r; acquired=2; policy=(2, 1, 1); Bernstein(base,e)=[[0, 1/2], [0, 5/24, 5/12, 1/2]].
- lambda>=r; acquired=2; policy=(2, 1, 2); Bernstein(base,e)=[[0, 1], [0, 1/4, 1/2, 1/2]].
- lambda>=r; acquired=2; policy=(2, 2, 0); Bernstein(base,e)=[[0], [0]].
- lambda>=r; acquired=2; policy=(2, 2, 1); Bernstein(base,e)=[[0, 1/2], [0, 1/8, 1/4, 1/2]].
- lambda>=r; acquired=2; policy=(2, 2, 2); Bernstein(base,e)=[[0, 1], [0, 1/2]].

## 其他恒等式

- 三人真实质量、两种攻击的质量与精确利润差、期望 miner 分配均由独立枚举式作符号相消。攻击利润分别为 2(2p−1)^2(x−V/3) 和 2(1−2p(1−p))(x−V/3)。
- 三人无所有权设计的三条全局支撑不等式：两条恒等式精确相消，第一条差为 (1/2−2p(1−p))lambda≥0。
- n=3,5,...,23 的二项导数与无信息支付尾和共 22 个多项式/有理函数恒等式精确为零；这是有限 n 的符号范围，不认证任意 n 的证明。
- 动态项：2×2 Markov 矩阵的 zP(I−zP)^(-1) 与两个特征通道 z/(1−z)、z rho/(1−z rho) 的矩阵表达逐项精确相等。z=delta(1−alpha)。收敛范围仍由假设 0≤delta<1,0<alpha≤1,0≤rho≤1 保证。
