"""Exact finite discovery probe, not a dynamic-equilibrium or chain-parity test.

Reproduce from Documents with the shared Python environment. Results are Markdown.
The candidate signal-following strategies of the OTHER validators are held fixed.
"""

from fractions import Fraction as F
from itertools import product
from pathlib import Path
import sys

import sympy as sp


Q_LOW, Q_HIGH = F(1, 5), F(4, 5)
KAPPA = F(32767, 65535)
GRID = tuple(F(k, 20) for k in range(21))
OUT = Path(__file__).with_suffix('.md')


def epoch(stakes, reports, alpha):
    """Real-arithmetic classic path, beta=1, initial bonds B_ij=S_i."""
    w = [(x, 1 - x) for x in reports]
    consensus = []
    for j in range(2):
        consensus.append(max(x for x in {row[j] for row in w}
                             if sum(s for s, row in zip(stakes, w)
                                    if row[j] >= x) >= KAPPA))
    clipped = [[min(row[j], consensus[j]) for j in range(2)] for row in w]
    rank = [sum(s * row[j] for s, row in zip(stakes, clipped)) for j in range(2)]
    incentive = [v / sum(rank) for v in rank]
    delta = [[stakes[i] * clipped[i][j] / rank[j] if rank[j] else F(0)
              for j in range(2)] for i in range(len(stakes))]
    bonds = [[alpha * delta[i][j] + (1 - alpha) * stakes[i] for j in range(2)]
             for i in range(len(stakes))]
    for j in range(2):
        total = sum(row[j] for row in bonds)
        if total:
            for row in bonds:
                row[j] /= total
    dividends = [sum(row[j] * incentive[j] for j in range(2)) for row in bonds]
    total_d = sum(dividends)
    dividends = [v / total_d for v in dividends]
    return dividends[0] / 2, incentive[0] / 2, incentive[0]


def conditional(stakes, precision, alpha, signal, report):
    val, miner, loss = F(0), F(0), F(0)
    for theta in (0, 1):
        # Prior is uniform and the focal signal is symmetric, so P(signal)=1/2.
        posterior = precision if theta == signal else 1 - precision
        quality = Q_HIGH if theta else Q_LOW
        for others in product((0, 1), repeat=len(stakes) - 1):
            prob = posterior
            for other in others:
                prob *= precision if other == theta else 1 - precision
            reports = [report] + [Q_HIGH if other else Q_LOW for other in others]
            d, r, allocation = epoch(stakes, reports, alpha)
            val += prob * d
            miner += prob * r
            loss += prob * (allocation - quality) ** 2
    return val, miner, loss


def sympy_reference(stakes, precision, alpha, signal, report):
    """Separate symbolic rational replay via the trust formula at this B state."""
    rat = lambda x: sp.Rational(x.numerator, x.denominator)
    s, p, a, x = list(map(rat, stakes)), rat(precision), rat(alpha), rat(report)
    value = [sp.S.Zero, sp.S.Zero, sp.S.Zero]
    for theta in (0, 1):
        posterior = p if theta == signal else 1 - p
        quality = rat(Q_HIGH if theta else Q_LOW)
        for others in product((0, 1), repeat=len(stakes) - 1):
            prob = posterior
            rows = [(x, 1 - x)]
            for other in others:
                prob *= p if other == theta else 1 - p
                y = rat(Q_HIGH if other else Q_LOW)
                rows.append((y, 1 - y))
            caps = [max(v for v in {row[j] for row in rows}
                        if sum(s[k] for k, row in enumerate(rows) if row[j] >= v)
                        >= rat(KAPPA)) for j in range(2)]
            clips = [[min(row[j], caps[j]) for j in range(2)] for row in rows]
            ranks = [sum(s[k] * row[j] for k, row in enumerate(clips)) for j in range(2)]
            allocation = ranks[0] / sum(ranks)
            # All signal-following outsiders report strictly positive columns here.
            assert all(rank > 0 for rank in ranks)
            d = ((1 - a) * s[0] + a * s[0] * sum(clips[0]) / sum(ranks)) / 2
            for k, term in enumerate((d, allocation / 2, (allocation - quality) ** 2)):
                value[k] += prob * term
    return tuple(sp.cancel(v) for v in value)


def best_reports(payoffs, score):
    best = max(score(payoffs[x]) for x in GRID)
    return [x for x in GRID if score(payoffs[x]) == best]


def probe(name, stakes, precision, alpha):
    pay = [{x: conditional(stakes, precision, alpha, z, x) for x in GRID}
           for z in (0, 1)]
    informed = [best_reports(pay[z], lambda v: v[0]) for z in (0, 1)]
    uninformed = max(GRID, key=lambda x: (pay[0][x][0] + pay[1][x][0]) / 2)
    truthful = (pay[0][Q_LOW][0] + pay[1][Q_HIGH][0]) / 2
    informed_value = sum(pay[z][informed[z][0]][0] for z in (0, 1)) / 2
    uninformed_value = (pay[0][uninformed][0] + pay[1][uninformed][0]) / 2
    # Owner has all of miner 1's income; own stake is the first component.
    # Among equal-profit maximizers choose the LEAST damaging action.
    owner = [min(best_reports(pay[z], lambda v: v[0] + v[1]),
                 key=lambda x: (pay[z][x][2], x)) for z in (0, 1)]
    owner_value = sum(pay[z][owner[z]][0] + pay[z][owner[z]][1] for z in (0, 1)) / 2
    initial_owner = sum(pay[z][x][0] + pay[z][x][1]
                        for z, x in ((0, Q_LOW), (1, Q_HIGH))) / 2
    initial_loss = (pay[0][Q_LOW][2] + pay[1][Q_HIGH][2]) / 2
    owner_loss = sum(pay[z][owner[z]][2] for z in (0, 1)) / 2
    # Replay each action used in the reported finite comparisons independently.
    replays = 0
    for z in (0, 1):
        selected = set(informed[z]) | {uninformed, owner[z], Q_LOW, Q_HIGH}
        for x in selected:
            exact = sympy_reference(stakes, precision, alpha, z, x)
            target = tuple(sp.Rational(v.numerator, v.denominator) for v in pay[z][x])
            assert exact == target, (name, precision, alpha, z, x, exact, target)
            replays += 1
    return dict(name=name, stakes=stakes, p=precision, alpha=alpha,
                truthful_gap=informed_value - truthful,
                truthful_rent=truthful - uninformed_value,
                information_value=informed_value - uninformed_value,
                informed=informed, uninformed=uninformed, owner=owner,
                owner_gain=owner_value - initial_owner,
                extra_loss=owner_loss - initial_loss, replays=replays)


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    cases = [('equal3', (F(1, 3),) * 3),
             ('small20', (F(1, 5), F(2, 5), F(2, 5))),
             ('equal5', (F(1, 5),) * 5)]
    rows = [probe(name, stakes, p, alpha)
            for name, stakes in cases
            for p in (F(3, 5), F(3, 4), F(9, 10))
            for alpha in (F(1, 10), F(1))]
    lines = ['# 单轮信息生产与 miner 所有权探针', '',
             '日期：2026-09-29。研究计算记录，不是论文正文。', '',
             '## 问题与范围', '',
             '先问：给定其他验证者按私有信号报告，普通验证者是否有付费获取信息的收益空间？同一个验证者持有 miner 后，报告激励如何变化？', '',
             '源码参照：opentensor/subtensor c004cebf，run_epoch.rs 默认分支 403–426 行及 compute_ema_bonds_normal。只实现理想实数/有理数算术的局部分支，未完成固定点逐位对齐或仓库单元测试对齐。', '',
             '设置：两个 miner，质量目标为 (4/5,1/5) 或 (1/5,4/5)，先验各半；条件于质量，各 validator 信号独立，准确率 p。其他验证者报信号对应的质量向量。初始 bonds 各列为 stake 向量。beta=1，kappa=32767/65535，miner/validator 各取本模型奖励池的 1/2。所有报告均保留行和为 1，全部奖励做实际归一化。', '',
             '每种信号下报告枚举 {0,1/20,...,1}。无信息者在同一集合中选固定报告。表中“信息价值”是最优信号条件报告相对最优无信息报告的毛收益差；只有成本低于该值才可能值得评估。未计未来继续价值、commit-reveal 延迟或质量转移，因此不是动态信息均衡。', '',
             '所有权列假设焦点 validator 还拥有 miner 1 的全部收入，但其余人策略仍固定。信号条件下选总收益最高报告；收益平局时选失真最小者。失真为 E[(I_1-q_1)^2]；正的增量不等于已经证明可达或持续的动态捕获。', '',
             '## 有限探针结果', '',
             '| stake 情形 | p | alpha | 信号跟随相对网格最优的损失 | 信息价值（约值） | owner 报告 (低信号,高信号) | owner 净收益增量（约值） | 额外分配失真（约值） |',
             '|---|---:|---:|---:|---:|---|---:|---:|']
    for r in rows:
        owner = ', '.join(map(str, r['owner']))
        lines.append(f"| {r['name']} | {r['p']} | {r['alpha']} | {float(r['truthful_gap']):.8f} | {float(r['information_value']):.8f} | ({owner}) | {float(r['owner_gain']):.8f} | {float(r['extra_loss']):.8f} |")
    lines += ['', '## 精确数值与复算范围', '',
              '下列数值为有理数精确枚举；表中小数仅用于阅读。所有进入比较的最终候选动作另以 SymPy 从不同收益表达式回代。网格穷尽只覆盖该有限集合，不证明连续报告空间最优，也不证明任何动态均衡。', '']
    for r in rows:
        lines += [f"- {r['name']}, p={r['p']}, alpha={r['alpha']}: information_value={r['information_value']}; truthful_rent={r['truthful_rent']}; truthful_gap={r['truthful_gap']}; owner_gain={r['owner_gain']}; extra_loss={r['extra_loss']}; informed best={r['informed']}; uninformed best={r['uninformed']}; symbolic action replays={r['replays']}."]
    lines += ['', '## 下一步问题', '',
              '1. 将连续报告最优反应和真正的动态继续价值纳入，确认信息均衡而非单轮候选策略。',
              '2. 对一般机制建立同信息、同预算的设计问题；本探针没有计算该机制类的下界或匹配构造。',
              '3. 所有权带来的单轮偏离是需要纳入的约束，不能直接归因于 bonds 动态放大。', '',
              'This file records model calculations; finite numerical results are not universal proof certificates.', '']
    OUT.write_text('\n'.join(lines), encoding='utf-8')
    print(f'Wrote {OUT}; {len(rows)} cases; {sum(r["replays"] for r in rows)} symbolic action replays.')
    for r in rows:
        if r['p'] == F(3, 4) and r['alpha'] == F(1, 10):
            print({k: str(r[k]) for k in ('name', 'information_value', 'truthful_gap', 'owner', 'owner_gain', 'extra_loss')})


if __name__ == '__main__':
    main()
