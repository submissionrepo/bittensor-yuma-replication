"""Exact rational interval certificate for a default-alpha information equilibrium.

All arithmetic in the certificate is rational. No numerical optimizer is used.
Shared ledger and factgraph are written by the coordinator, not this script.
"""
from pathlib import Path
from itertools import product
from fractions import Fraction as F
from math import comb
import json
import sympy as s
from default_dynamic_probe import profiles,e,x,D,score,r,alpha,delta,z,w
from yuma_endpoint_probe import step

R=s.Rational
ELL=R(49,100)
H=R(1,20)
K=R(1,20)
MARGIN=R(1,1000)

def bernstein(poly,lo,hi):
    y=s.Symbol('y')
    pp=s.Poly(poly.as_expr().subs(x,lo+(hi-lo)*y),y)
    n=pp.degree()
    if n == -s.oo:
        return [R(0)]
    aa=[pp.nth(i) for i in range(n+1)]
    return [sum(aa[i]*R(comb(j,i),comb(n,i)) for i in range(j+1)) for j in range(n+1)]

def certify_poly(poly,lo,hi,depth=0):
    coeff=bernstein(poly,lo,hi)
    if min(coeff)>=0:
        return [{'lo':str(lo),'hi':str(hi),'bernstein':[str(t) for t in coeff]}]
    if depth>=14:
        raise ArithmeticError(f'No positive Bernstein cover at depth {depth}: interval={lo,hi}; coeff={coeff}')
    mid=(lo+hi)/2
    if poly.eval(mid)<0:
        raise ArithmeticError(f'Negative exact witness: x={mid}, value={poly.eval(mid)}')
    return certify_poly(poly,lo,mid,depth+1)+certify_poly(poly,mid,hi,depth+1)

def rational_certificate(expr,lo,hi):
    num,den=s.fraction(s.cancel(expr))
    num=s.Poly(num,x);den=s.Poly(den,x)
    if den.eval((lo+hi)/2)<0:
        num=-num;den=-den
    dn=certify_poly(den,lo,hi)
    assert all(min(R(a) for a in b['bernstein'])>0 for b in dn)
    nn=certify_poly(num,lo,hi)
    return {'numerator':[str(a) for a in num.all_coeffs()],
            'denominator':[str(a) for a in den.all_coeffs()],
            'numerator_cover':nn,'denominator_cover':dn}

def main():
    certs=[]
    corners=(-R(1,2),-H,H,R(1,2))
    intervals={'L':(R(0),ELL),'C':(ELL,1-ELL),'R':(1-ELL,R(1))}
    for dd in corners:
      for key,(lo,hi) in intervals.items():
        rows=[tuple(s.cancel(a.subs(e,ELL)) if hasattr(a,'subs') else a for a in row) for row in profiles[key]]
        base=s.cancel((score['C'].subs({e:ELL,x:ELL,D:dd})-score[key].subs({e:ELL,D:dd}))+K*max(abs(dd)-H,0))
        distance=ELL-x if key=='L' else x-ELL
        nextds=[r*dd+alpha*(b1-b0) for inc,b1,b0 in rows]
        # max(0,D'-H,-D'-H) is bounded exactly by enumerating all
        # independent affine branches in the three outsider profiles.
        choices=[(R(0),ddn-H,-ddn-H) for ddn in nextds]
        for branches in product(range(3),repeat=3):
            residual=base-delta*K*sum(ww*cc[ii] for ww,cc,ii in zip(w,choices,branches))-MARGIN*distance
            cert=rational_certificate(residual,lo,hi)
            certs.append({'D':str(dd),'report_branch':key,'positive_part_branches':branches,**cert})
      print('completed D =',dd,flush=True)
    # Independent exact epoch replay of every profile family and boundary.
    replay=0
    for aa in (R(0),ELL/2,ELL,R(1,2),1-ELL,1-ELL/2,R(1)):
      key='L' if aa<ELL else ('C' if aa<=1-ELL else 'R')
      for kk in range(3):
        tail=[ELL]*(2-kk)+[1-ELL]*kk
        ir,b1,b0=[s.cancel(expr.subs({e:ELL,x:aa})) if hasattr(expr,'subs') else expr for expr in profiles[key][kk]]
        for dd in corners:
            own=[F((1+dd)/2),F((1-dd)/2)]
            old=[own,[(1-own[0])/2,(1-own[1])/2],[(1-own[0])/2,(1-own[1])/2]]
            inc,pay,bonds=step([F(1,3)]*3,[F(aa),*map(F,tail)],old,F(alpha))
            assert R(inc[0])==ir
            assert R(bonds[0][0])==r*R(own[0])+alpha*b1
            assert R(bonds[0][1])==r*R(own[1])+alpha*b0
            assert R(bonds[0][0]-bonds[0][1])==r*dd+alpha*(b1-b0)
            assert 0<=b1<=R(1,2) and 0<=b0<=R(1,2)
            replay+=1
    # Truthful fresh bond expectations and transformed payoff constant.
    tr=profiles['C']
    sumfresh=s.cancel(sum(ww*(b1+b0) for ww,(inc,b1,b0) in zip(w,tr)).subs({e:ELL,x:ELL}))
    payfresh=s.cancel(sum(ww*(inc*b1+(1-inc)*b0) for ww,(inc,b1,b0) in zip(w,tr)).subs({e:ELL,x:ELL}))
    assert sumfresh==R(2,3) and payfresh==R(1,3)
    aa,rr,dd,SS=s.symbols('a r d S')
    coeff=rr/(2*(1-dd*rr))
    assert s.cancel(rr*SS/2+dd*coeff*rr*SS-coeff*SS)==0
    eta=R(1,2)*MARGIN*(1-2*ELL)/2
    quality=s.factor(R(1,2)+R(1,2)*(R(1,2)-ELL)*(1-R(3,16)+R(9,16)/(1+ELL)))
    payload={'ell':str(ELL),'h':str(H),'K':str(K),'margin':str(MARGIN),
             'eta_max':str(eta),'quality':str(quality),'certificates':certs,'profile_replays':replay}
    Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    leaves=sum(len(c['numerator_cover']) for c in certs)
    lines=['# Default-alpha Yuma: exact potential certificate','','2026-09-30. Rational algebra, no optimizer.',
           '',f'- ell={ELL}, alpha={alpha}, delta={delta}, p=3/4, V=M=1/2, ownership=0.',
           f'- Potential H(D)={K} max(|D|-{H},0). Uniform conditional report margin={MARGIN}.',
           f'- {len(certs)} exact rational inequalities, each denominator strictly positive; numerator Bernstein covers have {leaves} leaves.',
           f'- {replay} independent exact epoch comparisons, including all three outsider profiles, report boundaries and four bond-difference corners.',
           '- The expectation identities E[v_fresh|signal]=1/3 and E[Delta_1+Delta_0|signal]=2/3 hold exactly.',
           f'- Positive information costs eta <= {eta}; quality Q={quality}.',
           '', 'These certificates cover the algebraic Bellman inequalities. The state reduction, convexity in D, and infinite-horizon comparison are supplied by the paper proof and are not established by these algebraic certificates.','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print('\n'.join(lines),flush=True)

if __name__=='__main__': main()
