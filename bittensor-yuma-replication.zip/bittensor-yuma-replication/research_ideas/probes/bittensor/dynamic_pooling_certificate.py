"""A potential certificate against arbitrary multi-period Yuma deviations."""
from pathlib import Path
import sys
import sympy as sp
from fractions import Fraction as F
from itertools import product
from yuma_endpoint_probe import step

R=sp.Rational


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    n,alpha,delta,V,M,beta,D,u=sp.symbols('n alpha delta V M beta D u',positive=True)
    r=1-alpha;umax=1/(4*n-2);c=4*(n-1)/n
    Imin=R(1,2)-umax;pot=V*r*Imin/(1-delta*r)
    costate=r*D+alpha*c*u/(1-2*u)
    gain=(beta*M-alpha*V*c/2)*u-V*r*D*(R(1,2)-u)
    cap=sp.factor(alpha*V*c/2+delta*alpha*pot*c)
    residual=sp.cancel(gain-delta*pot*costate+pot*D)
    certificate=-V*r*D*(umax-u)-(cap-beta*M)*u-2*delta*alpha*pot*c*u**2/(1-2*u)
    assert sp.cancel(residual-certificate)==0
    stated=2*alpha*V*(n-1)/n*(1-delta*r/(2*n-1))/(1-delta*r)
    assert sp.cancel(cap-stated)==0
    special=sp.factor((cap/M).subs({n:3,alpha:R(1,10),delta:R(99,100),V:R(1,2),M:R(1,2)}))
    assert special==R(8218,8175)
    critical=sp.solve(sp.Eq((cap/M).subs({n:3,alpha:R(1,10),V:R(1,2),M:R(1,2)}),1),delta)
    assert critical==[R(650,657)]
    # Independently replay different report orientations in the actual epoch
    # map; replacing all deviations by the owned side preserves total bond
    # deficit and weakly increases discounted utility, path by path.
    count=0
    for size in (3,5):
        stakes=[F(1,size)]*size
        for a,disc in ((F(1,10),F(99,100)),(F(2,5),F(4,5))):
            for reports in product((F(0),F(1,4),F(3,4),F(1)),repeat=3):
                old=[[F(1,size)]*2 for _ in range(size)];fav=[row[:] for row in old]
                original=F(0);reflected=F(0)
                for tt,xx in enumerate(reports):
                    oi,op,old=step(stakes,[xx]+[F(1,2)]*(size-1),old,a)
                    fi,fp,fav=step(stakes,[F(1,2)+abs(xx-F(1,2))]+[F(1,2)]*(size-1),fav,a)
                    assert sum(old[0])==sum(fav[0])
                    assert fp[0]+F(1,2)*fi[0]>=op[0]+F(1,2)*oi[0]
                    original+=disc**tt*(op[0]+F(1,2)*oi[0])
                    reflected+=disc**tt*(fp[0]+F(1,2)*fi[0])
                assert reflected>=original
                count+=1
    lines=['# bonds 动态恒报均衡：任意多期偏离的势函数证书','',
           '2026-09-29。条件：n>=3等stake，经典Yuma，0<alpha<=1，delta<1，初始每列bond=1/n，其他人永远报1/2。','',
           '取r=1-alpha、u=h/[2(n-h)]∈[0,1/(4n-2)]、c=4(n-1)/n；偏好miner相反一列的bond缺口为D。',
           '缺口下一期D_next=rD+alpha*c*u/(1-2u)。当前偏离收益g=(beta*M-alpha*V*c/2)u - V*r*D(1/2-u)。',
           '取势函数Phi(D)=-kD，k=V*r*(1/2-1/(4n-2))/(1-delta*r)。','',
           f'- ownership money cap = `{cap}`.',
           '- 精确恒等式：g+delta Phi(D_next)-Phi(D) = -V*r*D*(u_max-u) -(cap-beta*M)*u -2*delta*alpha*k*c*u^2/(1-2u)。',
           '- 在全部声明域上右侧逐项非正；有界势函数的折现末项趋于0，所以任意长、随机、历史依赖偏离的总收益不正。',
           f'- n3,alpha1/10,delta99/100,V=M时，持股上限证书为{special}>1；覆盖全部omega∈[0,1]。',
           '- 该参数下覆盖omega=1所需delta>=650/657。','',
           f'另有{count}条三期有理报告路径与实际epoch精确回放：把每次偏离反射到持有miner方向，保留两列bond缺口之和并逐期弱增收益。有限回放不代替一般反射归约，通用结论见研究证明。','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Potential identity and cap exact;',count,'exact oriented-path comparisons; cap=',special)


if __name__=='__main__':main()
