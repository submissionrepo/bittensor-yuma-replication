"""Discovery for full dynamic default-alpha Yuma candidate information policies.

Own files only. Does not modify the shared ledger or factgraph.
"""
from pathlib import Path
import json
import sympy as s

R=s.Rational
e,x,D=s.symbols('ell x D',real=True)
w=(R(7,16),R(6,16),R(3,16))
alpha=R(1,10);delta=R(99,100);r=1-alpha;z=delta*r
profiles={
 'L':[( (x+2*e)/(3-e+x), x/(x+2*e), R(1,3)),
      ( (x+2*e)/(2+e+x), x/(x+2*e), (1-e)/(2-e)),
      ( (x+2-2*e)/(2+e+x), x/(x+2-2*e), R(1,3))],
 'C':[( 3*e/(3+e-x),R(1,3),(1-x)/(3-2*e-x)),
      ( (2*x+e)/(2+2*e),x/(2*x+e),(1-x)/(2-2*x+e)),
      ( (x+2-2*e)/(2+e+x),x/(x+2-2*e),R(1,3))],
 'R':[( 3*e/(3+e-x),R(1,3),(1-x)/(3-2*e-x)),
      ( (2-e)/(3+e-x),(1-e)/(2-e),(1-x)/(1-x+2*e)),
      ( 3*(1-e)/(4-e-x),R(1,3),(1-x)/(1-x+2*e))]
}
I={key:s.factor(sum(ww*row[0] for ww,row in zip(w,rows))) for key,rows in profiles.items()}
v={key:s.factor(sum(ww*(ii*b1+(1-ii)*b0) for ww,(ii,b1,b0) in zip(w,rows))) for key,rows in profiles.items()}
f={key:s.factor(sum(ww*(b1+b0) for ww,(ii,b1,b0) in zip(w,rows))) for key,rows in profiles.items()}
score={key:s.factor(r*D*I[key]+alpha*(v[key]+z/(2*(1-z))*f[key])) for key in profiles}

def main():
    lines=['# Default-alpha dynamic information discovery','','2026-09-30. Exact symbolic expressions, followed by a floating grid discovery. No ledger credential for the grid.','']
    derivatives={key:s.factor(s.diff(score[key],x).subs(x,e)) for key in ('L','C')}
    extreme=2*(1-2*e)/(3*(2-e))
    for key in derivatives:
        lines.append(f'- {key} derivative: `{derivatives[key]}`')
    lines.append(f'- Honest reachable old-bond difference extrema approach `+-{extreme}`.')
    for key in derivatives:
        for sg in (-1,0,1):
            lines.append(f'- {key} at D={sg}Dmax: `{s.factor(derivatives[key].subs(D,sg*extreme))}`')
    rows=[]
    for ee in [R(k,200) for k in range(1,100)]:
        vals={f'{key}{sg}':float(expr.subs({e:ee,D:sg*extreme.subs(e,ee)})) for key,expr in derivatives.items() for sg in (-1,0,1)}
        rows.append({'ell':str(ee),**vals})
    lines += ['',f'- Grid points: {len(rows)}.',f'- No right-improvement at Dmax and no left-improvement at Dmin: {[row for row in rows if row["C1"]<=0 and row["L-1"]>=0]}','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    print('\n'.join(lines))

if __name__=='__main__': main()
