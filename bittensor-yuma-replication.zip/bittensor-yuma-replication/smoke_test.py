"""Check package completeness and replay saved protocol fixtures, without Rust."""
from pathlib import Path
import ast
import csv
import json
import sys

ROOT = Path(__file__).resolve().parent
PROTOCOL = ROOT / "research_ideas/probes/bittensor/protocol"
sys.path.insert(0, str(PROTOCOL))
from python_epoch import epoch
from differential import first_difference


def main():
    sources = list(ROOT.rglob("*.py"))
    sources = [p for p in sources if not {"vendor", "target", ".venv"}.intersection(p.parts)]
    for path in sources:
        ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    count = 0
    for scenario in json.loads((PROTOCOL / "official_scenarios.json").read_text(encoding="utf-8")):
        for fixture in scenario["fixtures"]:
            # JSON round-trip gives the same integer-key representation as the Rust fixture.
            actual = json.loads(json.dumps(epoch(fixture["input"])))
            difference = first_difference(actual, fixture["output"])
            if difference:
                raise AssertionError((scenario["name"], difference))
            count += 1
    data = ROOT / "research_ideas/probes/bittensor/numerics/single_hedge_results.csv"
    with data.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 36 and {r["samples"] for r in rows} == {"2048"}
    assert sum(r["policy"] == "softmax" for r in rows) == 32
    print(f"Parsed {len(sources)} Python sources; replayed {count} official epoch fixtures.")
    print("Loaded all 36 published experiment comparisons (2048 paired draws each).")
    print("This package smoke test does not re-verify the mathematical theorems.")


if __name__ == "__main__":
    main()
