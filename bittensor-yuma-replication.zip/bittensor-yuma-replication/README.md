# Why Hedging Breaks Yuma: replication materials

Computational materials for **Why Hedging Breaks Yuma: Report-Only Rewards for
Decentralized AI Evaluation**. The directory structure is retained so that
imports, saved data, and table generators work from a fresh checkout.

The package contains the fixed-point Python epoch implementation, the extracted
Rust reference and its source-extraction scripts, official test fixtures,
reported experimental data, exact-arithmetic certificate scripts and outputs,
and generators for the paper's numerical tables and two data figures.

The [verification index](certificates/README.md) gives the scope of the
first-layer exact/symbolic records and the second-layer independent LLM proof
audits. It includes the original audit verdicts and the manuscript text they
reviewed. A second-layer pass is not a formal machine proof.

## Quick start

Python 3.11 was used for the reported computations. Run these commands from the
repository root. The smoke test uses only the Python standard library.

```sh
python smoke_test.py
python -m pip install -r requirements.txt
python research_ideas/bittensor_paper_a/check_numbers.py
python research_ideas/bittensor_paper_a/make_single_hedge_tables.py
python research_ideas/bittensor_paper_a/threshold_table.py
python research_ideas/bittensor_paper_a/tex/figures/make_frontier.py
python research_ideas/bittensor_paper_a/tex/figures/make_influence.py
```

The first command replays the 36 saved official epoch fixtures and checks that
all 36 experiment comparisons are present. It does not build Rust or rerun the
Monte Carlo experiment. The table generator reads the saved 2048-draw results.
Generated tables and figures are written beside their scripts.

## Where to find each result

All paths below are relative to the repository root.

| Paper result | Scripts and saved material |
|---|---|
| Quoted fractions and ownership thresholds | `research_ideas/bittensor_paper_a/check_numbers.py`, `threshold_table.py`, `threshold_table.csv` |
| Static frontier and continuous-weight formulas | `research_ideas/probes/bittensor/symbolic_frontier_checks.py`, `yuma_continuous_theory.py`, `theory_completion_checks.py` |
| Unequal-stake premium capacity | `research_ideas/probes/bittensor/rent_capacity_probe.py` and its local helper imports |
| Persistence calculations | `research_ideas/probes/bittensor/dynamic_memoryless_probe.py`, `dynamic_frontier_general_probe.py`, and their saved outputs |
| Default-memory informative equilibrium: 324 rational inequalities | `research_ideas/probes/bittensor/default_dynamic_certificate.py` and `.json` |
| Derivative bounds and profitable deviations under default memory | `research_ideas/probes/bittensor/default_dynamic_extensions_certificate.py` and `.json` |
| Uninformative pooling equilibrium | `research_ideas/probes/bittensor/dynamic_pooling_certificate.py` and `.md` |
| Fixed-point implementation and Rust comparison | `research_ideas/probes/bittensor/protocol/` |
| Sampled 16-bit ownership caps | `research_ideas/probes/bittensor/numerics/source_branch_probe.py`, `.csv`, `.json` |
| Single-validator, multiple-miner experiment | `research_ideas/probes/bittensor/numerics/single_hedge_probe.py`, `single_hedge_2048.csv`, `single_hedge_fixtures.json`, `single_hedge_summary.json` |

Exact certificate scripts can be run directly, for example:

```sh
python research_ideas/probes/bittensor/default_dynamic_certificate.py
python research_ideas/probes/bittensor/default_dynamic_extensions_certificate.py
python research_ideas/probes/bittensor/dynamic_pooling_certificate.py
```

These commands write their computational outputs next to the corresponding
script. Saved outputs are included; certificate generation is not part of the
quick smoke test. Supporting modules retain their original names, including
some modules with `probe` or `coalition` in the name that supply shared routines.

## Rebuild the Rust reference and rerun experiments

See [the protocol instructions](research_ideas/probes/bittensor/protocol/README.md)
for source downloads and the Rust 1.89.0 build. Once the debug executable has
been built:

```sh
python research_ideas/probes/bittensor/protocol/differential.py
python research_ideas/probes/bittensor/protocol/official_classic.py
python research_ideas/probes/bittensor/protocol/official_extra.py
python research_ideas/probes/bittensor/numerics/source_branch_probe.py
python research_ideas/probes/bittensor/numerics/single_hedge_probe.py --samples 2048
python research_ideas/bittensor_paper_a/make_single_hedge_tables.py
```

The full single-validator experiment uses 2048 paired draws per environment,
produces 36 comparisons, and performs 110,610 Python epoch evaluations including
the 18 inputs compared with Rust. Its recorded runtime was approximately
316 seconds; machine-dependent runtimes and Rust build times will differ.
The included 512-draw pilot is a prefix of the final sample, not an independent
replication. Intervals are paired, pointwise 95% Monte Carlo intervals.

## Interpretation and scope

- The mathematical results concern the assumptions stated in the paper.
  Finite numerical checks do not prove their universal statements.
- The multi-miner experiment uses the legacy source branch with bond memory
  off, zero ownership, and specified Gaussian-score/softmax policies. It is not
  a classification of repeated-game equilibria under default bond memory.
- The ownership-cap grid samples about 1040 fixed-sum 16-bit reports per
  softening level. Its caps do not certify every possible integer report.
- The Rust reference adapts resolved epoch state to the upstream arithmetic.
  It is not a full Subtensor node and does not reproduce FRAME storage,
  registration, transaction permissions, or dTAO stake conversion.
- Recorded differential tests establish agreement on their listed inputs,
  not formal equivalence on all inputs. Official test coverage and exclusions
  are described in the protocol directory.

## Source versions and export adaptations

The protocol source is Subtensor commit
`c004cebf360f4088187ee49d851dfb1a1eaaf710`; substrate-fixed is commit
`d5f70362f2e05b5f33fb51cd7baa825323e4e6c5`. The Rust dependency versions are
recorded in the included `Cargo.lock`.

The submission export replaces workstation-specific figure paths with paths
relative to this checkout and removes local author/workstation details from
plotting documentation. The quoted-number script exits unsuccessfully if a
check fails. Numerical formulas and saved data are unchanged. Project notes,
unrelated verification records, account credentials, private histories,
downloaded toolchains, and compiled executables are not included. The
`certificates/` directory is a publication export of the relevant verification
records, not a separate verification ledger.

Upstream license texts and attribution are preserved in
[protocol/NOTICE.md](research_ideas/probes/bittensor/protocol/NOTICE.md).
